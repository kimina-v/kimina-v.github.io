<template>
  <div class="wrap">
    <Header/>
    <section id="content" class="content">
      <div class="w_cnt_box">
        <!--
          1. 팝업 종료 시 팝업 오픈시킨 이벤트 엘리먼트로 포커스 돌아감
          $commonLib.layerOpen.show($event,'팝업id');
          예) 팝업 종료 시 버튼으로 포커스 돌아옴
          <button @click="$commonLib.layerOpen.show($event,'alertTextBase')">얼럿 열기</button>
          

          2. 팝업 종료 시 지정 대상으로 포커스 이동
          $commonLib.layerOpen.show('포커스 갈 엘리먼트 id','팝업id');
          예) 팝업 종료 시 <input id="input00">으로 포커스 이동
          $commonLib.layerOpen.show('input00','alertTextBase');

          3) 팝업 종료 시 <div class="wrap"> 으로 포커스 이동
          $commonLib.layerOpen.show(null,'팝업id');
          예) $commonLib.layerOpen.show(null,'alertTextBase');

          ==========================

          팝업 닫기
          $commonLib.layerOpen.hide()

          ==========================

          얼럿 기본 텍스트 형 일때
          $store.state.alertText에 문구 담기
          예) @click="[$store.state.alertText='필수항목을 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]"
        -->
        <div class="popup_mockup">
          <h3 class="tit">로그인 회원가입</h3>
          <table class="table0">
            <colgroup>
              <col>
              <col>
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>팝업 보기</th>
                <th>수정</th>
              </tr>
            </thead>
            <tbody>
              <!-- 로그인 -->
              <!-- 아이디,비밀번호 -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_01</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='아이디 또는 비밀번호를 확인해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_02</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='보안문자가 일치하지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_03</td>
                <td>
                   <button class="btn" @click="$commonLib.layerOpen.show($event,'alertDormantMember')">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_04</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertPwFind')">화면보기</button>
                </td>
                <td>20210903수정완료</td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_05</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='회원정보가 없습니다.<br>정확한 정보를 입력하신 후 다시 시도해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_06</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='입력한 아이디 정보와 본인인증 정보가 일치하지 않습니다.<br>정확한 정보를 입력하신 후 다시 시도해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_07</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호가 변경되었습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_08</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호가 일치하지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_09</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호는 동일문자를 연속3회이상 반복 하실 수 없습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_10</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호 형식이 올바르지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line --> 
              <!-- line -->
              <tr>
                <td>Alert_g_login_11</td>
                <td>
                   <button class="btn" @click="$commonLib.layerOpen.show($event,'alertImportMemberInfo')">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->          
              <!-- line -->
             <tr>
              <td>Alert_g_login_12</td>
              <td>
                <button class="btn" @click="[$store.state.alertText='필수항목을 체크해주시기 바랍니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
              </td>
              <td></td>
             </tr>           
             <!-- //line -->
             <!-- line -->
             <tr>
               <td>Alert_g_login_13</td>
              <td>
                <button class="btn" @click="$commonLib.layerOpen.show($event,'alertUseAgreeGuide')">화면보기</button>
              </td>
              <td></td>
             </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_14</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='필수항목을 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_15</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='이메일 주소를 확인해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
               <!-- line -->
              <tr>
                <td>Alert_g_login_16</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='아이디 중복확인을 해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_13</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertUseAgreeGuide')">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_17</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='필수약관에 동의해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_18</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertAgreeUncheck')">화면보기</button>
                </td>
                <td>20210909수정완료</td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_19</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertAgreeUncheck2')">화면보기</button>
                </td>
                <td>20210909수정완료</td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_20</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='정보를 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_21</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='맞춤혜택 서비스 이용 동의를 해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button><!--b20210827 띄어쓰기수정 -->
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_22</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertAccountRestore')">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_23</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='저장이 완료되었습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->            
              <!-- line -->
              <tr>
                <td>Alert_g_login_24</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='14세 미만은 회원가입이 불가능합니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_25</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='자녀 정보를 정확하게 입력해주세요.<br>맘키즈 클럽은 만 7세 이하 자녀를 둔 고객 대상으로 가입이 가능합니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
            </tbody>
          </table>

          <h3 class="tit">회원정보 수정</h3>
          <table class="table0">
            <colgroup>
              <col>
              <col>
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>팝업 보기</th>
                <th>수정</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Alert_g_login_15</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='이메일 주소를 확인해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_13</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertUseAgreeGuide')">화면보기</button>
                </td>
                <td>20210909수정완료</td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_01</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alerAdvertisingInfo')">화면보기</button>
                </td>
                <td>20210903수정완료</td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_02</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alerWithdrawalConsent')">화면보기</button>
                </td>
                <td>20210903수정완료</td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_03</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='현재 비밀번호가 일치하지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_04</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='신규 비밀번호가 일치하지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_05</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='신규 비밀번호를 입력해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_06</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='신규 비밀번호 확인을 입력해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_09</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호는 동일문자를 연속3회이상 반복 하실 수 없습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_login_10</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호 형식이 올바르지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line --> 
              <!-- line -->
              <tr>
                <td>Alert_g_login_08</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호가 일치하지 않습니다.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_08</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='비밀번호를 입력해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_myinfo_09</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='탈퇴 유의사항을 확인해주시고, 회원탈퇴에 동의해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>           
              <!-- //line -->
            </tbody>
          </table>
          <h3 class="tit">푸터</h3>
          <table class="table0">
            <colgroup>
              <col>
              <col>
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>팝업 보기</th>
                <th>수정</th>
              </tr>
            </thead>
            <tbody>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_footer_01</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'alertCustomerTel')">화면보기</button>
                </td>
                <td>20210901수정완료</td>
              </tr>
              <!-- line -->
            </tbody>
          </table>
          <h3 class="tit">본인인증</h3>
          <table class="table0">
            <colgroup>
              <col>
              <col>
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>팝업 보기</th>
                <th>수정</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Alert_g_certified_01</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='약관에 동의해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- line -->
              <!-- line -->
              <tr>
                <td>Alert_g_certified_02</td>
                <td>
                  <button class="btn" @click="[$store.state.alertText='인증 번호를 입력해주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">화면보기</button>
                </td>
                <td></td>
              </tr>
              <!-- //line -->
              <!-- line -->
              <tr>
                <td>Alert_g_certified_03</td>
                <td>
                   <button class="btn" @click="$commonLib.layerOpen.show($event,'alertAuthCount')">화면보기</button>
                </td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>


        <div style="padding:40px;">
          <p style="font-size:20px;padding-bottom:20px;">테스트</p>
          <div class="btn_box col2" style="padding-bottom:20px;">
            <button class="test_btn" @click="$commonLib.layerOpen.show($event,'alertAgreeUncheck')">열기(포커스 버튼)</button>
            <button class="test_btn" @click="$commonLib.layerOpen.show('input00','alertAgreeUncheck')">열기(포커스 인풋)</button>
            <button class="test_btn" @click="$commonLib.layerOpen.show(null,'alertAgreeUncheck')">열기(포커스 wrap)</button>
          </div>
          <div class="form_box">
            <p class="tit">이름</p>
            <div class="input_box">
              <input id="input00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
              <label for="input00">
                <span class="in_box">이름 입력</span>
              </label>
            </div>
          </div>
        </div>
        <!-- ====== alert popup start ====== -->
        <!-- 휴면회원 본인인증 페이지 랜딩 -->
        <alertDormantMember></alertDormantMember>
        <!-- 기존회원정보 불러오기 -->
        <alertImportMemberInfo></alertImportMemberInfo>
        <!-- 휴면회원 계정 복원 -->
        <alertAccountRestore></alertAccountRestore>
        <!-- 광고정보 수신동의 -->
        <alerAdvertisingInfo></alerAdvertisingInfo>
        <!-- 광고정보 수신동의 -->
        <alerWithdrawalConsent></alerWithdrawalConsent>
        <!-- 휴대폰 인증 -->
        <alertAuthCount></alertAuthCount>
        <!-- 맞춤혜택 체크 활성화 후 비활성화 시 얼럿 -->
        <alert-agree-uncheck2 />
        <!-- 푸터 고객선터 전화걸기 -->
        <alert-customer-tel></alert-customer-tel>

        <!-- 기본 텍스트형 얼럿 팝업 -->
        <alert-text-base :alert-text="$store.state.alertText" />

        <!-- 로그인/회원가입 비밀번호 오류 10회 이상 시 얼럿 -->
        <alert-pw-find />

        <!-- 로그인/회원가입 오프라인 회원정보 가져오기 얼럿 -->
        <alert-offline-member />

        <!-- 로그인/회원가입 체크 활성화 후 비활성화 시 얼럿 -->
        <alert-agree-uncheck />


        <!-- 마이회원정보 : 온라인 회원 완전 탈퇴 얼럿 -->
        <alert-online-secession />

        <!-- 회원가입 약관동의 : 이용동의 안내 문구 노출 얼럿 -->
        <alert-use-agree-guide />
        <!-- ====== alert popup End ====== -->
      </div>
    </section>
    <Footer/>
  </div>
</template>

<style>
  /* 목업 화면 용 css(개발 반영X) */
  body{background:#f8f8f8;}
  .popup_mockup{min-height:100vh;box-sizing:border-box;padding:0 5px 100px 5px;}
  .popup_mockup .tit{font-size:18px;padding:30px 20px 15px 20px;}
  .popup_mockup .txt{font-size:15px;padding:0 0 10px 0;}
  .popup_mockup .btn{border:1px solid #555;font-size:12px;padding:4px 10px;background:#fff;margin-right:10px;}
  .test_btn{border:1px solid #555;font-size:12px;padding:4px 10px;background:#fff;margin-right:10px;}
  .popup_mockup .table0{width:100%;table-layout:fixed;box-sizing:border-box;border-top:2px solid #333;}
  .popup_mockup .table0 tr:hover td{background:#efefef}
  .popup_mockup .table0 td{text-align:center;border-bottom:1px solid #333;border-right:1px dotted #333;font-size:14px;vertical-align:middle;padding:5px 5px;word-break:break-all;}
  .popup_mockup .table0 td:last-child{border-right:0;}
  .popup_mockup .table0 td.td0{text-align:left;font-size:12px;}
  .popup_mockup .table0 th{border-bottom:2px solid #222;text-align:center;padding:8px 0;font-size:14px;font-weight:500;vertical-align:middle;}
  .popup_mockup .table0 th.th0{border-bottom:none;}
  .popup_mockup .table0 td button{margin:0;}
</style>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

import AlertTextBase from '@/containers/alert/AlertTextBase.vue'//기본 얼럿
import AlertAgreeUncheck from '@/containers/alert/AlertAgreeUncheck.vue'
import AlertOfflineMember from '@/containers/alert/AlertOfflineMember.vue'
import AlertOnlineSecession from '@/containers/alert/AlertOnlineSecession.vue'
import AlertPwFind from '@/containers/alert/AlertPwFind.vue'
import AlertUseAgreeGuide from '@/containers/alert/AlertUseAgreeGuide.vue'
import AlertDormantMember from '@/containers/alert/AlertDormantMember.vue'
import AlertImportMemberInfo from '@/containers/alert/AlertImportMemberInfo.vue'
import AlertAccountRestore from '@/containers/alert/AlertAccountRestore.vue'
import AlerAdvertisingInfo from '@/containers/alert/AlerAdvertisingInfo.vue'
import AlerWithdrawalConsent from '@/containers/alert/AlerWithdrawalConsent.vue'
import AlertAuthCount from '@/containers/alert/AlertAuthCount.vue'
import AlertAgreeUncheck2 from '@/containers/alert/AlertAgreeUncheck2.vue'
import AlertCustomerTel from '@/containers/alert/AlertCustomerTel.vue'

export default {
  components: {
    Header,
    Footer,
    AlertTextBase,
    AlertAgreeUncheck,
    AlertOfflineMember,
    AlertOnlineSecession,
    AlertPwFind,
    AlertUseAgreeGuide,
    AlertDormantMember,
    AlertImportMemberInfo,
    AlertAccountRestore,
    AlerAdvertisingInfo,
    AlerWithdrawalConsent,
    AlertAuthCount,
    AlertAgreeUncheck2,
    AlertCustomerTel,
  },
  props: {
    
  },
  mounted() {
    /*
      1. 팝업 종료 시 팝업 오픈시킨 이벤트 엘리먼트로 포커스 돌아감
      $commonLib.layerOpen.show($event,'팝업id');
      예) 팝업 종료 시 버튼으로 포커스 돌아옴
      <button @click="$commonLib.layerOpen.show($event,'alertTextBase')">얼럿 열기</button>
      

      2. 팝업 종료 시 지정 대상으로 포커스 이동
      $commonLib.layerOpen.show('포커스 갈 엘리먼트 id','팝업id');
      예) 팝업 종료 시 <input id="input00">으로 포커스 이동
      $commonLib.layerOpen.show('input00','alertTextBase');

      3) 팝업 종료 시 <div class="wrap"> 으로 포커스 이동
      $commonLib.layerOpen.show(null,'팝업id');
      예) $commonLib.layerOpen.show(null,'alertTextBase');

      ==========================

      팝업 닫기
      $commonLib.layerOpen.hide()

      ==========================

      얼럿 기본 텍스트 형 일때
      $store.state.alertText에 문구 담기
      예) @click="[$store.state.alertText='필수항목을 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]"
    */
  },
  methods: {
    
  }

}
</script>
