<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="logo_tit">
            <logo-box></logo-box>
          </h2>
          <p class="txt al_c">현재 가입되어 있는 신세계포인트 통합ID로 <br>이마트 회원가입 후 서비스를 이용하실 수 있습니다.</p>
        </div>
        
        <dl class="id_info_gray_box mg_b40">
          <dt>아이디</dt>
          <dd>shinsegae12</dd>
        </dl>
        
        <div class="join_cnt0">
          <div class="join_agree_box">
            <div class="chk_box2">
              <input id="termsAllChk" type="checkbox">
              <label for="termsAllChk">필수항목 전체 선택</label>
            </div>
            <p class="tit">신세계포인트 통합회원</p>
            <p class="txt">㈜이마트, ㈜신세계, ㈜광주신세계, ㈜신세계동대구복합환승센터 귀중</p><!--b20210827 문구 및 태그 수정-->
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms03" type="checkbox">
                  <label for="terms03"><span class="in_box">[필수] 통합회원 서비스 제공을 위한 개인정보 제3자 제공 동의</span></label>
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
            </ul>
            <p class="tit">신세계아울렛<!--관계사--></p>
            <p class="txt">㈜신세계사이먼 귀중</p><!--b20210827 문구 및 태그 수정-->
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms10" type="checkbox">
                  <label for="terms10"><span class="in_box">[필수] 신세계아울렛 회원 이용약관<!--관계사--></span></label>
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms11" type="checkbox">
                  <label for="terms11"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms12" type="checkbox">
                  <label for="terms12"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
            </ul>
            <div class="add_info_agree_cnt">
              <div class="chk_box">
                <input id="receveAll2" type="checkbox">
                <label for="receveAll2">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve10" type="checkbox">
                  <label for="receve10">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve11" type="checkbox">
                  <label for="receve11">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve12" type="checkbox">
                  <label for="receve12">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve13" type="checkbox">
                  <label for="receve13">TM</label>
                </div>
              </div>
            </div>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">다음</a>
          </div>
          <ul class="list_cnt space0 pd_t40"><!-- Y20210801  star 클래스 삭제 -->
            <!-- Y20210801 문구수정 --><!--b20210827 띄어쓰기수정 -->
            <li>선택항목 수집 및 이용 동의를 거부하시더라도 기본 서비스는 이용하실 수 있습니다.</li>
            <li>이미 신세계포인트 회원이신 경우 신세계포인트 온라인 통합ID 가입 시 입력한 정보로 회원정보가 변경됩니다.</li>
            <!-- //Y20210801 문구수정 -->
          </ul>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import LogoBox  from "@/components/common/LogoBox.vue"

export default {
  components: {
    Header,
    Footer,
    LogoBox
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
