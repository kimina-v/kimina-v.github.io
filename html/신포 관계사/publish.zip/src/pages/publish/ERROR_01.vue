<template>
  <div class="wrap">
    <div class="error_page">
      <h1 class="blind">에러페이지</h1>
      <div class="error_page_con error1">
        <p class="tit">
          죄송합니다.<br>서비스에 <span class="txt_line0">일시적인 오류</span>가 있습니다.
        </p>
        <p class="txt">
          이용에 불편을 드려 죄송합니다.<br>가능한 빠르게 복구하여 서비스를 제공할 수 있도록 최선을 다하겠습니다.
        </p>
      </div>
      <div class="btn_box">
        <a href="javascript:void(0)" class="btn1">메인 페이지</a>
        <a href="javascript:void(0)" class="btn0">이전 페이지</a>
      </div>
    </div>
  </div>
</template>

<script>


export default {
  components: {
  },
  props: {
    
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
