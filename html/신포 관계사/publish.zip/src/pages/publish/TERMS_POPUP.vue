<template>
  <div class="wrap">
    <Header/>
    <section id="content" class="content">
      <div class="w_cnt_box">
        <!--
          1. 팝업 종료 시 팝업 오픈시킨 이벤트 엘리먼트로 포커스 돌아감
          $commonLib.layerOpen.show($event,'팝업id');
          예) 팝업 종료 시 버튼으로 포커스 돌아옴
          <button @click="$commonLib.layerOpen.show($event,'alertTextBase')">얼럿 열기</button>
          

          2. 팝업 종료 시 지정 대상으로 포커스 이동
          $commonLib.layerOpen.show('포커스 갈 엘리먼트 id','팝업id');
          예) 팝업 종료 시 <input id="input00">으로 포커스 이동
          $commonLib.layerOpen.show('input00','alertTextBase');

          3) 팝업 종료 시 <div class="wrap"> 으로 포커스 이동
          $commonLib.layerOpen.show(null,'팝업id');
          예) $commonLib.layerOpen.show(null,'alertTextBase');

          ==========================

          팝업 닫기
          $commonLib.layerOpen.hide()

          ==========================

          얼럿 기본 텍스트 형 일때
          $store.state.alertText에 문구 담기
          예) @click="[$store.state.alertText='필수항목을 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]"
        -->
        <div class="popup_mockup">
          <h3 class="tit">약관 팝업</h3>
                   
          <table class="table0">
            <colgroup>
              <col>
              <col>
              <col>
              <col style="width:80px;">
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>설명</th>
                <th>상태</th>
                <th>수정</th>
                <th>팝업 보기</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>휴대폰 본인인증 약관</td>
                <td class="td0">혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'privacyAgreeDetailPopup')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td rowspan="6">화원가입 신세계포인트 통합ID 서비스 약관</td>
                <td class="td0">[필수] 신세계포인트 회원 이용약관</td>
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 개인정보 수집 및 이용동의</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointRequired02')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 이마트/신세계 공동 개인정보 수집 및 이용 동의</td><!--b20210827 띄어쓰기수정 -->
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointRequired03')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 통합회원 서비스 제공 개인정보 제3자 제공 동의</td>
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointRequired04')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</td><!--b20210827 띄어쓰기수정 -->
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointSelection01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[선택] 이마트/신세계 공동 개인정보 수집 및 이용 동의</td><!--b20210827 띄어쓰기수정 -->
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210831수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaePointSelection02')">화면보기</button>
                </td>
              </tr>    
              <tr>
                <td>관계사 약관(이마트)</td>
                <td class="td0">[필수] 이마트 필수약관</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'EmartRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td>관계사 약관(신세계백화점)</td>
                <td class="td0">[필수] 신세계백화점 필수약관</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ShinsegaeDepartmentRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td rowspan="3">관계사 약관(사이먼)</td>
                <td class="td0">[필수] 신세계사이먼 회원 이용약관</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'OutletsRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 개인정보 수집 및 이용에 대한 동의</td>
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0">20210903수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'OutletsRequired02')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[선택] 서비스·이벤트정보 제공을 위한 개인정보 수집 및 이용 동의</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0">20210903수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'OutletsSelection01')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td rowspan="3">관계사 약관(시코르)</td>
                <td class="td0">[필수] 시코르 회원 이용약관</td>
                <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ChicorRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 개인정보 수집 및 이용동의</td><!--b20210827 띄어쓰기수정 -->
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ChicorRequired02')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[선택] 이벤트 정보 제공을 위한 개인정보 수집 및 이용 동의</td><!--b20210827 띄어쓰기수정 -->
                 <td class="td0">퍼블완료(2021-07-01)<br>검수완료(2021-07-08)</td>
                 <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'ChicorSelection01')">화면보기</button>
                </td>
              </tr>
              <!--b20210908 추가-->
              <tr>
                <td rowspan="3">맞춤혜택</td>
                <td class="td0">[선택] 맞춤혜택 부가정보 수집 및 이용동의</td>
                 <td class="td0">퍼블완료(2021-09-08)<br></td>
                 <td class="td0">20210909수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'benefitsAdditionalConsent')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td class="td0">[선택] 이마트/신세계 공동 부가정보 수집 및 이용동의</td>
                 <td class="td0">퍼블완료(2021-09-08)<br></td>
                 <td class="td0">20210909수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'emartShinsegaeAdditionalAgr')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td class="td0">[선택] 신세계포인트 ↔ SSG.COM 개인정보 제공 동의</td>
                 <td class="td0">퍼블완료(2021-09-08)<br></td>
                 <td class="td0">20210908수정완료</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'shinsegaeSsgAdditionalAgr')">화면보기</button>
                </td>
              </tr>
              <!--//b20210908 추가--> 
                <!--b20210916 추가-->
              <tr>
                <td rowspan="3">관계사 약관(이마트에브리데이)</td>
                <td class="td0">[필수] 이마트에브리데이 회원 이용약관</td>
                <td class="td0">퍼블완료(2021-09-16)</td>
                <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'everydayRequired01')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[필수] 개인정보 수집 및 이용 동의</td>
                 <td class="td0">퍼블완료(2021-09-16)</td>
                 <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'everydayRequired02')">화면보기</button>
                </td>
              </tr>  
              <tr>
                <td class="td0">[선택] 이벤트 정보 제공을 위한 개인정보 수집 및 이용동의</td>
                 <td class="td0">퍼블완료(2021-09-16)</td>
                 <td class="td0"></td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'everydayRequired03')">화면보기</button>
                </td>
              </tr>
              <!--//b20210916 추가-->
            </tbody>
          </table>
        </div>
        <!-- ====== terms popup start ====== -->
        <!-- 푸터 고객선터 전화걸기 -->
        <shinsegae-point-required01></shinsegae-point-required01>
        <shinsegae-point-required02></shinsegae-point-required02>
        <shinsegae-point-required03></shinsegae-point-required03>
        <shinsegae-point-required04></shinsegae-point-required04>
        <shinsegae-point-selection01></shinsegae-point-selection01>
        <shinsegae-point-selection02></shinsegae-point-selection02>
        <chicor-required01></chicor-required01>
        <chicor-required02></chicor-required02>
        <chicor-selection01></chicor-selection01>
        <emart-required01></emart-required01>
        <shinsegae-departmentRequired01></shinsegae-departmentRequired01>
        <outlets-required01></outlets-required01>
        <outlets-required02></outlets-required02>
        <outlets-selection-01></outlets-selection-01>
        <privacy-agreeDetail-popup></privacy-agreeDetail-popup>
        <!--b20210908 추가-->
        <benefits-additional-consent></benefits-additional-consent>
        <emart-shinsegae-additional-agr></emart-shinsegae-additional-agr>
        <shinsegae-ssg-additional-agr></shinsegae-ssg-additional-agr>
        <!--//b20210908 추가-->
        <!--b20210916 추가-->
        <everyday-required01></everyday-required01>
        <everyday-required02></everyday-required02>
        <everyday-required03></everyday-required03>
        <!--//b20210916 추가-->
     
        <!-- ====== terms popup End ====== -->
      </div>
    </section>
    <Footer/>
  </div>
</template>

<style>
  /* 목업 화면 용 css(개발 반영X) */
  body{background:#f8f8f8;}
  .popup_mockup{min-height:100vh;box-sizing:border-box;padding:0 5px 100px 5px;}
  .popup_mockup .tit{font-size:18px;padding:30px 20px 15px 20px;}
  .popup_mockup .txt{font-size:15px;padding:0 0 10px 0;}
  .popup_mockup .btn{border:1px solid #555;font-size:12px;padding:4px 10px;background:#fff;margin-right:10px;}
  .test_btn{border:1px solid #555;font-size:12px;padding:4px 10px;background:#fff;margin-right:10px;}
  .popup_mockup .table0{width:100%;table-layout:fixed;box-sizing:border-box;border-top:2px solid #333;}
  .popup_mockup .table0 tr:hover td{background:#efefef}
  .popup_mockup .table0 td{text-align:center;border-bottom:1px solid #333;border-right:1px dotted #333;font-size:14px;vertical-align:middle;padding:5px 5px;word-break:break-all;}
  .popup_mockup .table0 td:last-child{border-right:0;}
  .popup_mockup .table0 td.td0{text-align:left;font-size:12px;}
  .popup_mockup .table0 th{border-bottom:2px solid #222;text-align:center;padding:8px 0;font-size:14px;font-weight:500;vertical-align:middle;}
  .popup_mockup .table0 th.th0{border-bottom:none;}
  .popup_mockup .table0 td button{margin:0;}
</style>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

import ShinsegaePointRequired01 from '@/containers/terms/ShinsegaePointRequired01.vue'
import ShinsegaePointRequired02 from '@/containers/terms/ShinsegaePointRequired02.vue'
import ShinsegaePointRequired03 from '@/containers/terms/ShinsegaePointRequired03.vue'
import ShinsegaePointRequired04 from '@/containers/terms/ShinsegaePointRequired04.vue'
import ShinsegaePointSelection01 from '@/containers/terms/ShinsegaePointSelection01.vue'
import ShinsegaePointSelection02 from '@/containers/terms/ShinsegaePointSelection02.vue'
import ChicorRequired01 from '@/containers/terms/ChicorRequired01.vue'
import ChicorRequired02 from '@/containers/terms/ChicorRequired02.vue'
import ChicorSelection01 from '@/containers/terms/ChicorSelection01.vue'
import EmartRequired01 from '@/containers/terms/EmartRequired01.vue'
import ShinsegaeDepartmentRequired01 from '@/containers/terms/ShinsegaeDepartmentRequired01.vue'
import OutletsRequired01 from '@/containers/terms/OutletsRequired01.vue'
import OutletsRequired02 from '@/containers/terms/OutletsRequired02.vue'
import OutletsSelection01 from '@/containers/terms/OutletsSelection01.vue'
import PrivacyAgreeDetailPopup from '@/containers/terms/PrivacyAgreeDetailPopup'
// b20210908 추가
import BenefitsAdditionalConsent from '@/containers/terms/BenefitsAdditionalConsent.vue'
import EmartShinsegaeAdditionalAgr from '@/containers/terms/EmartShinsegaeAdditionalAgr.vue'
import ShinsegaeSsgAdditionalAgr from '@/containers/terms/ShinsegaeSsgAdditionalAgr.vue'
// //b20210908 추가
// b20210916 추가
import EverydayRequired01 from '@/containers/terms/EverydayRequired01.vue'
import EverydayRequired02 from '@/containers/terms/EverydayRequired02.vue'
import EverydayRequired03 from '@/containers/terms/EverydayRequired03.vue'
// //b20210916 추가

export default {
  components: {
    Header,
    Footer,
    ShinsegaePointRequired01,
    ShinsegaePointRequired02,
    ShinsegaePointRequired03,
    ShinsegaePointRequired04,
    ShinsegaePointSelection01,
    ShinsegaePointSelection02,
    ChicorRequired01,
    ChicorRequired02,
    ChicorSelection01,
    EmartRequired01,
    ShinsegaeDepartmentRequired01,
    OutletsRequired01,
    OutletsRequired02,
    OutletsSelection01,
    PrivacyAgreeDetailPopup,
        // b20210908 추가
    BenefitsAdditionalConsent,
    EmartShinsegaeAdditionalAgr,
    ShinsegaeSsgAdditionalAgr,
    // //b20210908 추가
    //b20210916 추가
    EverydayRequired01,
    EverydayRequired02,
    EverydayRequired03
    ////b20210916 추가
  },
  props: {
    
  },
  mounted() {
    /*
      1. 팝업 종료 시 팝업 오픈시킨 이벤트 엘리먼트로 포커스 돌아감
      $commonLib.layerOpen.show($event,'팝업id');
      예) 팝업 종료 시 버튼으로 포커스 돌아옴
      <button @click="$commonLib.layerOpen.show($event,'alertTextBase')">얼럿 열기</button>
      

      2. 팝업 종료 시 지정 대상으로 포커스 이동
      $commonLib.layerOpen.show('포커스 갈 엘리먼트 id','팝업id');
      예) 팝업 종료 시 <input id="input00">으로 포커스 이동
      $commonLib.layerOpen.show('input00','alertTextBase');

      3) 팝업 종료 시 <div class="wrap"> 으로 포커스 이동
      $commonLib.layerOpen.show(null,'팝업id');
      예) $commonLib.layerOpen.show(null,'alertTextBase');

      ==========================

      팝업 닫기
      $commonLib.layerOpen.hide()

      ==========================

      얼럿 기본 텍스트 형 일때
      $store.state.alertText에 문구 담기
      예) @click="[$store.state.alertText='필수항목을 입력해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]"
    */
  },
  methods: {
    
  }

}
</script>
