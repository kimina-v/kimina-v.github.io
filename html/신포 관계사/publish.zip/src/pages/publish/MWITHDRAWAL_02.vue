<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">회원 탈퇴</h2>
          <p class="txt">탈퇴 유의사항을 확인하신 후 회원 탈퇴를 진행해주세요.</p>
        </div>
      </div>
      <div class="w_cnt_full bg0">
        <div class="w_cnt_box">
          <div class="logo_box2">
            <img class="group_logo" src="~@/assets/images/common/logo_emart.png" alt="emart logo">
          </div>
        </div>
      </div>
      <div class="w_cnt_box">
        <div class="leave_cnt0">
          <div class="notice_box">
            <!-- Y20210801 유의사항 수정 Start -->
            <div class="notice_box pd_type2">
              <h3 class="tit">[유의사항]</h3>
              <ul class="list_cnt">
                <li class="str">이마트<!--관계사명--> 정책에 따라 회원탈퇴 후 5일<!--관계사별 날짜--> 동안 재가입이 불가합니다.</li>
                <li class="str">주문 및 배송 진행건이 있는 경우 회원 탈퇴 불가능합니다.</li><!-- (시코르만 노출) -->
                <li>회원 탈퇴 시 보유하고 계신 포인트, 쿠폰, 적립금 등 모든 혜택은 자동 소멸되며 복구 불가합니다.</li>
                <li>회원 탈퇴 시 신세계 아카데미 및 이마트 문화센터 수강 신청 및 변경이 불가할 수 있습니다.</li><!-- (이마트, 신세계만 노출) -->
                <li>회원 탈퇴 후 재가입 시 신규 회원으로 가입되며, 탈퇴 전의 회원정보 및 혜택은 복원되지 않습니다.</li>
                <li>회원 탈퇴 전 예약 발송된 광고 메시지가 있는 경우 약 1-2일 동안 발송될 수 있습니다.</li>
                <li>회원 탈퇴 시 이마트<!--관계사명--> 회원 탈퇴가 되며, 신세계포인트 오프라인 및 통합ID 서비스는 계속 이용 가능합니다.</li>
              </ul>
            </div>
            <!-- //Y20210801 유의사항 수정 End -->
          </div>
          <div class="chk_box">
            <input id="agree00" type="checkbox">
            <label for="agree00" class="chk_label"><span class="in_cnt">탈퇴 유의사항을 모두 확인하였으며, 이마트<!--관계사--> 회원 탈퇴에 동의합니다.</span></label>
          </div>
          <div class="btn_box"><button class="btn0 sdw big">탈퇴하기</button></div>
          <a href="javascript:void(0)" class="btn_arr0 fl_r">신세계포인트 통합ID 탈퇴하기</a>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
