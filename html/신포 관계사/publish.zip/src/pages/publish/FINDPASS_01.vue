<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">비밀번호 찾기</h2>
          <!--b20210906문구수정-->
          <p class="txt">비밀번호가 기억나지 않으시나요?<br>본인인증 후 비밀번호를 변경하실 수 있습니다.</p>
        </div>
        <id-pw-find-tab :id-input-show="idInputShow" /><!-- idInputShow : 퍼블 확인 용 -->
        <!-- Y20210801 유의사항 추가 Start -->
        <div class="notice_box pd_type2">
          <ul class="list_cnt">
            <li>본인 명의의 인증 수단 정보를 정확히 입력해 주시기 바랍니다.</li>
            <li>본인 인증을 위해 입력한 정보는 본인인증 용도 외 다른 용도로 이용되지 않습니다.</li>
            <li>법인폰 사용자는 법인폰 개인인증 서비스 신청 후 휴대폰 인증을 하실 수 있습니다.</li>
            <li>인증 오류 시 코리아크레딧뷰로 고객센터 02-708-1000에 문의해 주시기 바랍니다.</li>
          </ul>
        </div>
        <!-- //Y20210801 유의사항 추가 End -->
      </div>
      
      <div class="w_cnt_full bg0">
        <div class="w_cnt_box">
          <find-id-btn-box></find-id-btn-box>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import IdPwFindTab  from "@/components/member/IdPwFindTab.vue"
import FindIdBtnBox from "@/components/member/FindIdBtnBox.vue"

export default {
  components: {
    Header,
    Footer,
    IdPwFindTab,
    FindIdBtnBox
  },
  pros: {
    
  },
  data : function(){
    return{
      idInputShow : true
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
