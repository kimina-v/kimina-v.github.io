<template>
  <div id="datepickertest">
    <div>DatePicker 예</div>
    <date-picker
      v-model="testDate"
      valueType="format"
      placeholder="20190602"
    ></date-picker>
  </div>
</template>

<script>
export default {
  data() {
    return {
      testDate: this.$moment().add(-7, "days").format("YYYY-MM-DD")
    };
  },
};
</script>
