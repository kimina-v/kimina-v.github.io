<template>
  <div id="test">
    <!-- <div>DatePicker 예</div>
    <date-picker
      v-model="testDate"
      valueType="format"
      placeholder="20190602"
    ></date-picker>

    <div>vue Barcode 예</div>
    <barcode :value="barcodeValue"> 바코드 생성실패시 보여지는 텍스트 </barcode> -->
    <div></div>
    <!-- 충돌테스트 주석 -->
    <!-- 주석테스트 -->
    <!-- 주석테스트 변경 -->
  </div>
</template>

<script>
export default {
  // data() {
  //   return {
  //     testDate: this.$moment().add(-7, "days").format("YYYY-MM-DD"),
  //     barcodeValue: "test",
  //   };
  // },
};
</script>
