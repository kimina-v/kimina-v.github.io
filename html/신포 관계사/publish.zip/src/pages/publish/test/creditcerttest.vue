<template>
  <div id="creditcerttemplate">
    신용카드 인증 테스트
    <li>
      <a href="#" @click.prevent="cert('creditCert')">
        <div class="sb_area clearfix">
          <div class="symbol_wrap"><div class="symbol">신용카드인증이미지</div></div>
          <dl>
            <dt>신용카드인증(인증내용 : CREDIT_CARD_CRTFC)</dt>
            <dd>
              회원님 명의의 카드(신용,체크) 정보로 (신용카드인증코멘트 : SVCWEB_CRTFC_CARD_CMNT1)
              <br class="pc_br" />본인인증을 진행합니다.(인증코멘트 : SVCWEB_CRTFC_PROC_CMNT)
            </dd>
          </dl>
        </div>
      </a>
    </li>
  </div>
</template>

<script>
export default {
  data() {
    return {
      popupStyle: "height=640,width=430,toolbar=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no, modal=yes"
    }
  },
  methods:{
    cert(certType) {      
      const routeData = this.$router.resolve({
        name: certType
      });
      window.name = "base"
      window.open(routeData.href, certType, this.popupStyle);

    }
  }
}
</script>

<style>

</style>