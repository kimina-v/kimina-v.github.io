<template>
  <div id="barcodetest">
    <div>vue Barcode 예</div>
    <barcode :value="barcodeValue"> 바코드 생성실패시 보여지는 텍스트 </barcode>
  </div>
</template>

<script>
export default {
  data() {
    return {
      barcodeValue: "test"
    };
  }
};
</script>
