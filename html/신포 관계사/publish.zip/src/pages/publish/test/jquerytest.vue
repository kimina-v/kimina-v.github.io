<template>
  <div id="jquerytest">
    <div>jqueryTest 예</div>
    <button @click=fnTest>id jquerytest console log</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      testDate: this.$moment().add(-7, "days").format("YYYY-MM-DD")
    };
  },
  methods: {
      fnTest(){
          console.log($("#jquerytest"));
      }
  }
};
</script>
