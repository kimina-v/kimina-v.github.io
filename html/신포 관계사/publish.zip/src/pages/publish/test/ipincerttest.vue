<template>
  <div id="ipincerttemplate">
    아이핀 인증 테스트
    <li>
      <a href="#" @click.prevent="cert('ipinCert')">
        <div class="sb_area clearfix">
          <div class="symbol_wrap"><div class="symbol">아이핀인증이미지</div></div>
          <dl>
            <dt>아이핀인증</dt><!-- {{ $t('label.IPIN_CRTFC') }} -->
            <dd>
              인증기관을 통해 발급받은 아이핀 정보로 (아이핀인증코멘트1)<!-- {{ $t('label.SVCWEB_CRTFC_IPIN_CMNT1') }} -->
              <br class="pc_br" />본인인증을 진행합니다.(아이핀인증코멘트2)<!-- {{ $t('label.SVCWEB_CRTFC_PROC_CMNT') }} -->
            </dd>
          </dl>
        </div>
      </a>
    </li>
  </div>
</template>

<script>
export default {
  data() {
    return {
      popupStyle: "height=640,width=430,toolbar=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no, modal=yes"
    }
  },
  methods:{
    cert(certType) {      
      const routeData = this.$router.resolve({
        name: certType
      });
      window.name = "base"
      window.open(routeData.href, certType, this.popupStyle);

    }
  }
}
</script>

<style>

</style>