<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
     <div class="list_wrap">
		<section class="list_layout">
			<h3>폰트</h3>
			<p class="font_noto_normal">Noto Sans KR normal</p>
			<p class="font_noto_500">Noto Sans KR 500</p>
			<p class="font_noto_bold">Noto Sans KR bold</p>
			<p class="font_lato_normal">Lato narmal</p>
			<p class="font_lato_500">Lato 500</p>
			<p class="font_lato_bold">Lato bold</p>
			<p class="font_lato_900">Lato 900</p>
		</section>
        <section class="list_layout">
           <h3>색상</h3>
           <p class="g_list_p">기본 폰트 색상 (#222)</p>
           <p class="g_list_p" style="color:#666">서브 폰트(#666)</p>
           <p class="g_list_p" style="color:#ff8022;">강조 (#ff8022)</p>
           <p class="g_list_p" style="color:#999">place holder (#999)</p>
		</section>
		<section class="list_layout">
			<h3>z-index</h3>
			<table>
				<colgroup>
					<col style="width: 30%" />
					<col />
				</colgroup>
				<tbody>
					<tr>
						<th>gnb</th>
						<td>100</td>
					</tr>
					<tr>
						<th>lnb</th>
						<td>102</td>
					</tr>
					<tr>
						<th>menu_bar</th>
						<td>100</td>
					</tr>
					<tr>
						<th>point_barcode</th>
						<td>90</td>
					</tr>
					<tr>
						<th>popup</th>
						<td>500</td>
					</tr>
				</tbody>
			</table>
		</section>
		<section class="list_layout">
			<h3>버튼</h3>
			<h4>높이60</h4>
			<div class="btn_box">
				<button class="btn0 big sdw">인증번호 요청</button>
			</div>
			<h4>높이50</h4>
			<div class="btn_box">
				<a href="javascript:void(0)" class="btn2 large">비밀번호 찾기</a>
			</div>
		</section>
		<section class="list_layout">
			<h3>탭1</h3>
			<div class="auth_tab">
				<ul class="auth_tab_menu">
					<li :class="{ on: authTabIdx === 0 }" @click="authTabIdx = 0">
						<a href="javascript:void(0)" class="phone">휴대폰인증</a>
					</li>
					<li :class="{ on: authTabIdx === 1 }" @click="authTabIdx = 1">
						<a href="javascript:void(0)" class="card">카드인증</a>
					</li>
					<li :class="{ on: authTabIdx === 2 }" @click="authTabIdx = 2">
						<a href="javascript:void(0)" class="ipin">아이핀인증</a>
					</li>
				</ul>
				<!-- 탭 컨텐츠 -->
				<div class="auth_tab_content">
					<div v-show="authTabIdx == 0" class="tab_cnt">컨텐츠1</div>
					<div v-show="authTabIdx == 1" class="tab_cnt">컨텐츠2</div>
					<div v-show="authTabIdx == 2" class="tab_cnt">컨텐츠3</div>
				</div>
			</div>
		</section>
		<section class="list_layout">
			<h3>폼</h3>

			<form>
				<div class="tab_box0">
					<!---->
					<div class="form_box">
						<!-- 에러 시 error 클래스 추가 -->
						<p class="tit">이름을 입력해주세요.</p>
						<div class="input_box">
							<input
								id="name00"
								type="text"
								value=""
								@input="$commonLib.inputLabelSet($event)"
								@keypress="nextPass($event)"
							/>
							<label for="name00"><span class="in_box">이름 입력</span></label>
						</div>
					</div>
					<div class="form_box required">
						<!-- 필수 입력 항목  required 클래스 추가 -->
						<p class="tit">아이디</p>
						<div class="input_btn_box">
							<div class="input_box">
								<input
									id="id00"
									type="text"
									value=""
									@input="$commonLib.inputLabelSet($event)"
								/>
								<label for="id00"
									><span class="in_box"
										>영문,숫자 6~20자리 입력해주세요.</span
									></label
								>
							</div>
							<div class="btn_box">
								<button class="btn2">중복확인</button>
							</div>
						</div>
						<!-- validation 문구 -->
						<p class="error_txt">아이디 형식에 맞게 입력해주세요.</p>
					</div>
					<div class="form_box required">
						<!-- 필수 입력 항목  required 클래스 추가 -->
						<p class="tit">이름</p>
						<div class="input_box">
							<input
								id="name00"
								class="readonly_bg"
								type="text"
								value="신세계"
								readonly
							/>
							<label for="name00"><span class="in_box">이름 입력</span></label>
						</div>
					</div>

					<div class="form_box">
						<p class="tit">성별을 선택해주세요.</p>
						<div class="radio_group_box col2">
							<div class="radio_box">
								<input
									id="radio00"
									type="radio"
									name="radioName00"
									checked="checked"
								/><label for="radio00">남자</label>
							</div>
							<div class="radio_box">
								<input id="radio01" type="radio" name="radioName00" /><label
									for="radio01"
									>여자</label
								>
							</div>
						</div>
					</div>
					<div class="form_box">
						<p class="tit">본인명의의 휴대전화번호를 입력해주세요.</p>
						<div class="phone_select_box">
							<div class="select_box">
								<select id="" title="통신사 선택">
									<option val="">SKT</option>
								</select>
							</div>
							<div class="input_box">
								<input id="phone00" type="tel" value="" /><label for="phone00"
									><span class="in_box">-없이 휴대폰 번호 입력</span></label
								>
							</div>
						</div>
						<p class="error_txt">휴대전화번호를 입력해주세요.</p>
					</div>
				</div>
				<div class="input_btn_box">
					<div class="input_box">
                        <input id="certification00"
                        type="tel" value=""
                        @input="$commonLib.inputLabelSet($event)"
                        @keypress="nextPass($event)"
                        >
                        <label for="certification00"><span class="in_box">인증번호 입력</span></label>
                    </div>
					<div class="btn_box"><button class="btn2">확인</button></div>
				</div>
			</form>
		</section>
		<section class="list_layout">
			<h3>라디오버튼</h3>
			<div class="terms_agree_box">
				<div class="agree_form_box">
					<ul class="agree_list btn_type0 txt_type0">
						<li class="agree_form">
							<div class="chk_box">
								<input id="terms00" type="checkbox" />
								<label for="terms00"
									><span class="in_box"
										>[선택] 혜택제공 및 분석을 위한 개인정보 수집 및
										이용동의</span
									></label
								>
							</div>
							<button class="agree_show">
								<span>내용보기</span>
							</button>
						</li>
						<li class="agree_form">
							<div class="chk_box">
								<input id="terms01" type="checkbox" />
								<label for="terms01"
									><span class="in_box"
										>[선택] 이마트/신세계 공동 개인정보 수집 및 이용동의</span
									></label
								>
							</div>
							<button class="agree_show">
								<span>내용보기</span>
							</button>
						</li>
					</ul>
					<div class="add_info_agree_cnt">
						<p class="add_info_agree_tit">신세계포인트 광고정보 수신동의</p>
						<div class="chk_box">
							<input id="receveAll" type="checkbox" />
							<label for="receveAll">전체동의</label>
						</div>
						<div class="chk_group_box col_f">
							<div class="chk_box">
								<input id="receve00" type="checkbox" />
								<label for="receve00">이메일</label>
							</div>
							<div class="chk_box">
								<input id="receve01" type="checkbox" />
								<label for="receve01">문자</label>
							</div>
							<div class="chk_box">
								<input id="receve02" type="checkbox" />
								<label for="receve02">DM</label>
							</div>
							<div class="chk_box">
								<input id="receve03" type="checkbox" />
								<label for="receve03">TM</label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="terms_agree_box">
				<div class="agree_form_box">
					<div class="agree_all_chk">
						<div class="chk_box">
							<input id="agreeAllChk" type="checkbox" /><label for="agreeAllChk"
								>모든 약관에 동의합니다.</label
							>
						</div>
					</div>
					<ul class="agree_list">
						<li class="agree_form">
							<div class="chk_box">
								<input id="agree05" type="checkbox" /><label for="agree05"
									><span class="in_box"
										>휴대전화 인증 서비스 이용약관 (필수)</span
									></label
								>
							</div>
							<button class="agree_show"><span>내용보기</span></button>
						</li>
					</ul>
				</div>
			</div>
		</section>
		<section class="list_layout">
			<h3>상단 타이틀</h3>
			<div class="top_cnt0">
				<p class="sp_tit2">
					<strong class="txt_line0">아이디</strong>가 <br />기억나지 않으시나요?
				</p>
				<p class="sp_txt6">본인인증을 통해 아이디를 확인하실 수 있습니다.</p>
			</div>
			<div class="top_cnt1">
				<p class="sp_tit2">
					신세계포인트<br />
					<strong class="fnt_color">통합ID 회원가입</strong>으로<br />
					다양한 혜택을 누리세요!<br />
				</p>
			</div>
		</section>
		<section class="list_layout">
			<h3>리스트</h3>
			<div class="notice_box">
				<h4>[유의사항]</h4>
				<ul class="list_cnt">
					<li>
						영문과 숫자, 특수문자를 조합하여 8-20자리로 입력해 주시기 바랍니다.
					</li>
					<li>
						3글자 이상의 동일한 숫자/문자 또는 연속된 숫자/문자는 입력하실 수
						없습니다.
					</li>
					<li>
						비밀번호 변경 시 신세계포인트 통합ID로 로그인하는 모든 신세계 그룹사
						사이트의 비밀번호가 동일하게 변경됩니다. (최대 10분 소요)
					</li>
				</ul>
				<h4>[약관]</h4>
				<ul class="list_cnt dash">
					<li>
						담배 상품, 대여용 장바구니, 서비스 제공 (배송료, 수선비 등), 임대
						매장(병원, 약국, 안경점 등 각 가맹점/매장별 상이)
					</li>
					<li>
						각 제휴사별/매장별 제휴 정책이 상이하므로 자세한 사항은 해당
						제휴사에 문의해 주시기 바랍니다.
					</li>
				</ul>
			</div>
		</section>
		<section class="list_layout">
			<h3>단계표시</h3>
			<div class="top_cnt1">
				<div class="join_step step2">
					<ol>
						<li><span>1</span></li>
						<li><span>2</span></li>
						<li><span>3</span></li>
						<li><span>4</span></li>
					</ol>
					<p class="tit">약관동의</p>
				</div>
			</div>
		</section>
		<section class="list_layout">
			<h3>탭</h3>
			<div class="top_cnt1">
              <group-join-tab></group-join-tab>
			</div>
		</section>
		<section class="list_layout">
			<h3>팝업</h3>
			<button class="btn" @click="$commonLib.layerOpen.show($event, 'emartShinsegaeAdditionalAgr')">약관팝업</button><br>
            <button class="btn" @click="$commonLib.layerOpen.show($event,'alertImportMemberInfo')">comfirm팝업</button><br>
            <button class="btn" @click="[$store.state.alertText='아이디 또는 비밀번호를 확인해 주세요.',$commonLib.layerOpen.show($event,'alertTextBase')]">alert팝업</button>
		</section>
        <alert-text-base :alert-text="$store.state.alertText" />
		<emart-shinsegae-additional-agr></emart-shinsegae-additional-agr>
        <alertImportMemberInfo></alertImportMemberInfo>
	</div>
    </section>
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import EmartShinsegaeAdditionalAgr from '@/containers/terms/EmartShinsegaeAdditionalAgr.vue'
import AlertImportMemberInfo from '@/containers/alert/AlertImportMemberInfo.vue'
import AlertTextBase from '@/containers/alert/AlertTextBase.vue'//기본 얼럿
import GroupJoinTab from '@/components/member/GroupJoinTab.vue'

export default {
  components: {
    Header,
    EmartShinsegaeAdditionalAgr,
    AlertImportMemberInfo,
    AlertTextBase,
    GroupJoinTab

  },
  pros: {
    
  },
  data : function(){
    return{
        authTabIdx: 0,
    }
  },
  mounted() {
    
  },
  methods: {
        nextPass(event){
        var fb= document.querySelectorAll('.form_box input')
        var fbl= document.querySelectorAll('.form_box input').length
        const idx = Array.from(document.querySelectorAll('.form_box input')).indexOf(event.target);
        if(event.charCode == 13 && /Android/.test(navigator.userAgent)){
                if(idx==(fbl-1)){
                }else{
                fb[idx+1].focus();
                }
            }
        }
    },

}
</script>
<style scoped>
.list_wrap{padding: 0 15px;}
section.list_layout{padding: 15px 0 40px;}
section.list_layout h3{font-size: 30px;margin: 15px 0;}
section.list_layout h4{font-size: 15px;margin: 15px 0 5px;}
section.list_layout table{width: 100%;}
section.list_layout table th{text-align: center;background: gray;color: #fff;}
section.list_layout table td{padding: 10px;}
.font_noto_normal{font-weight: normal;}
.font_noto_500{font-weight: 500;}
.font_noto_bold{font-weight: bold;}
.font_lato_normal{font-weight: bold;font-family:'Lato', sans-serif !important;;}
.font_lato_500{font-weight: 500;font-family:'Lato', sans-serif !important;;}
.font_lato_bold{font-weight: bold;font-family:'Lato', sans-serif !important;;}
.font_lato_900{font-weight: 900;font-family:'Lato', sans-serif !important;;}

.btn{padding: 5px;background: salmon;color: #fff;margin: 2px 0;}
</style>