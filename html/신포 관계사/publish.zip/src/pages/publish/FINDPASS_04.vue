<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">비밀번호 입력</h2>
        </div>
        <div class="bd_cnt_box type2">
          <p class="top_tit">비밀번호 입력 시 유의사항을 확인하신 후<br> <strong class="txt_line0">새로운 비밀번호</strong>를 <span class="wp">입력해주세요.</span></p>
          <div class="form_container">
            <div class="form_box">
              <p class="tit">비밀번호</p>
              <div class="input_box">
                <input id="pw00" type="password" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="pw00"><span class="in_box">비밀번호를 입력해주세요.</span></label>
              </div>
            </div>
            <div class="form_box">
              <p class="tit">비밀번호 확인</p>
              <div class="input_box">
                <input id="pw01" type="password" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="pw01"><span class="in_box">입력하신 비밀번호를 다시 한번 입력해주세요.</span></label>
              </div>
            </div>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">확인</a>
          </div>
        </div>
        <div class="notice_box pd_type1">
          <!-- Y20210801 유의사항 수정 Start -->
          <h3 class="tit">[유의사항]</h3>
          <ul class="list_cnt">
            <li>영문과 숫자, 특수문자를 조합하여 8-20자리로 입력해 주시기 바랍니다.</li>
            <li>3글자 이상의 동일한 숫자/문자 또는 연속된 숫자/문자는 입력하실 수 없습니다.</li>
            <li>비밀번호 변경 시 신세계포인트 통합ID로 로그인하는 모든 신세계 그룹사 사이트의 비밀번호가 동일하게 변경됩니다. (최대 10분 소요)</li>
          </ul>
          <!-- //Y20210801 유의사항 수정 End -->
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
