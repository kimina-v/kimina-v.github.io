<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="page_tit_cnt login">
        <h2 class="tit">로그인</h2>
      </div>
      <div class="login_cnt">
        <h3 class="login_tit">
          <logo-box></logo-box>
        </h3>
        <LoginFormArea :login-save-auto="loginSaveAuto" /><!-- loginSaveAuto : 퍼블 화면 확인 용 -->
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import LogoBox from '@/components/common/LogoBox.vue'
import LoginFormArea  from "@/components/member/LoginFormArea.vue"


export default {
  components: {
    Header,
    Footer,
    LogoBox,
    LoginFormArea
  },
  pros: {
    
  },
  data : function(){
    return{
      loginSaveAuto : true,//captchaShow : 퍼블 화면 확인 용
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
