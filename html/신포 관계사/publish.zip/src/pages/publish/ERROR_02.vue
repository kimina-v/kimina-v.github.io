<template>
  <div class="wrap">
    <div class="error_page">
      <h1 class="blind">에러페이지</h1>
      <div class="error_page_con error2">
        <p class="tit">페이지를 찾을 수 없습니다.</p>
        <p class="txt">
           <!--b20210907 문구,태그 수정-->
          <span class="wp">페이지 주소가 잘못 입력되었거나 삭제되어</span>
           요청한 페이지를 찾을 수 없습니다.
          <br>다시 확인해 주시기 바랍니다.
          <!--//b20210907 문구,태그 수정-->
        </p>
      </div>
      <div class="btn_box">
        <a href="javascript:void(0)" class="btn1">메인 페이지</a>
        <a href="javascript:void(0)" class="btn0">이전 페이지</a>
      </div>
    </div>
  </div>
</template>

<script>


export default {
  components: {
  },
  props: {
    
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
