<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">회원가입</h2>
          <p class="txt2">
            신세계포인트 <br v-if="this.$root.isMobile">
            <strong class="fnt_color">통합ID 회원가입</strong>으로 <br v-if="this.$root.isMobile">
            다양한 혜택을 누리세요!
          </p>
        </div>
      </div>
      <div class="step_list">
        <ol>
          <li class="step1">
            <span class="txt0">STEP. 1</span>
            <span class="txt1">본인인증</span>
          </li>
          <li class="step2">
            <span class="txt0">STEP. 2</span>
            <span class="txt1">약관동의</span>
          </li>
          <li class="step3">
            <span class="txt0">STEP. 3</span>
            <span class="txt1">정보입력</span>
          </li>
          <li class="step4">
            <span class="txt0">STEP. 4</span>
            <span class="txt1">가입완료</span>
          </li>
        </ol>
      </div>
      <div class="w_cnt_box">
        <div class="join_cnt1">
          <div class="btn_box">
           <a href="javascript:void(0)" class="btn0 big sdw">회원가입</a>
           <p class="sub_txt0">만 14세 미만 아동은 회원가입이 불가합니다.</p><!-- Y20210801 문구 추가 -->
          </div>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
