<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">회원정보 수정</h2>
        </div>
        <div class="info_change_cnt">
          <p class="info_change_tit">정보 수정</p>
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">아이디</p>
            <div class="input_box">
              <input id="id00" type="text" class="readonly_bg" value="asdf1234" disabled><!-- b20210813 readonly -> disabled로 수정 -->
              <label for="id00"><span class="in_box">아이디 입력</span></label>
            </div>
          </div>
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">이름</p>
            <div class="input_box">
              <input id="name00" type="text" value="신세계" disabled class="readonly_bg"><!-- b20210813 readonly -> disabled로 수정 -->
              <label for="name00"><span class="in_box">이름 입력</span></label>
            </div>
          </div>
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">휴대폰번호</p>
            <div class="input_box">
              <input id="phone00" type="tel" class="readonly_bg" value="010-1234-1234" disabled><!-- b20210813 readonly -> disabled로 수정 -->
              <label for="phone00"><span class="in_box">휴대폰번호 입력</span></label>
            </div>
          </div>
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">이메일</p>
            <div class="input_mail_box">
              <div class="input_box">
                <input id="mail00" type="text" value="asdf1234" @input="$commonLib.inputLabelSet($event)">
                <label for="mail00"><span class="in_box">이메일을 입력해주세요.</span></label>
              </div>
              <div class="col2_box">
                <div class="input_box">
                  <input id="mail01" type="text" value="naver.com" @input="$commonLib.inputLabelSet($event)">
                  <label for="mail01" class="unuse"><span class="in_box">이메일 도메인</span></label>
                </div>
                <div class="select_box">
                  <select id="" title="이메일 선택">
                    <option val="">선택해주세요.</option>
                    <option val="">직접입력</option>
                    <option val="" selected>naver.com</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">자택주소</p>
            <div class="input_address_box">
              <div class="input_btn_box w_type2">
                <div class="input_box">
                  <input id="address00" type="text" value="04529" @input="$commonLib.inputLabelSet($event)" disabled><!-- b20210813 readonly -> disabled로 수정 -->
                  <label for="address00" class="hide"><span class="in_box">우편번호</span></label>
                </div>
                <div class="btn_box">
                  <button class="btn2">우편번호 찾기</button>
                </div>
              </div>
              <div class="address_result_item">
                <dl>
                  <dt>도로명</dt>
                  <dd><span>경기 성남시 분당구 판교역로 235<br v-if="this.$root.isMobile"> (삼평동, 에이치스퀘어)</span></dd>
                </dl>
                <dl>
                  <dt>지번</dt>
                  <dd><span>경기 성남시 분당구 삼평동 681</span></dd>
                </dl>
              </div>
              <!--<div class="input_box">
                <input type="text" id="address01" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="address01" class="hide"><span class="in_box">주소</span></label>
              </div>-->
              <div class="input_box">
                <input id="address02" type="text" value="1층" @input="$commonLib.inputLabelSet($event)">
                <label for="address02"><span class="in_box">상세주소</span></label>
              </div>
            </div>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">확인</a>
          </div>
        </div>
        <!-- Y20210801 유의사항 추가 Start -->
        <div class="notice_box pd_type2">
          <h3 class="tit">[유의사항]</h3>
          <ul class="list_cnt">
            <li>본인인증을 통해 확인된 정보는 수정이 불가합니다.</li>
            <!--b20210907 문구수정 b20210908 (최대 10분 소요)앞 .사이 띄어쓰기수정-->
            <li>회원정보 수정 시 신세계포인트 오프라인 및 통합ID로 로그인하는 모든 신세계 그룹사 사이트의 회원정보가 동일하게 변경됩니다. (최대 10분 소요)</li>
          </ul>
        </div>
        <!-- //Y20210801 유의사항 추가 End -->
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    //페이지 로드 후 input label세팅
    this.$commonLib.inputLabelSet($('.input_box input'));
  },
  methods: {
    
  }

}
</script>
