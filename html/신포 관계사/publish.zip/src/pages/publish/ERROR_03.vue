<template>
  <div class="wrap">
    <div class="error_page">
      <h1 class="blind">에러페이지</h1>
      <div class="error_page_con error3">
        <p class="tit fw_b">
          <span class="txt_line0">서비스 점검 중</span> 입니다.<br>
          <span class="wp">서비스 이용에 불편을 드려</span> 죄송합니다.
        </p>
        <p class="txt">
          <span class="wp">보다 편리한 서비스 이용을 위해</span> 최선을 다하겠습니다.
        </p>
      </div>
    </div>
  </div>
</template>

<script>


export default {
  components: {
  },
  props: {
    
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
