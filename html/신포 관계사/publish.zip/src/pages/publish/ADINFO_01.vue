<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">광고정보 수신관리</h2>
          <p class="txt">광고정보 수신동의를 하시면 신세계포인트의 다양한 소식과 혜택 정보를 받으실 수 있습니다.</p>
        </div>
        <!---->
        <div class="user_info_cnt">
          <p class="tit">연락처 정보</p>
          <div class="user_info">
            <dl>
              <dt>휴대폰 번호</dt>
              <dd>010-9876-5432</dd>
            </dl>
            <dl>
              <dt>이메일</dt>
              <dd>asdf1234@asdf.com</dd>
            </dl>
            <dl>
              <dt>주소</dt>
              <dd>04529<br>도로명: 서울 중구 남대문시장 10길2, 1(회현동1가)<br>지번: 서울 중구 회현동1가 204번지 MESA 1</dd>
            </dl>
          </div>
        </div>
        <div class="txt_btn_box">
          <p class="tit">
            <!--b20210831 문구수정-->
            <strong>연락처 정보 변경이 필요하시나요?</strong><br>
            회원정보 수정 메뉴에서 변경하실 수 있습니다.
          </p>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn2 large">회원정보 수정</a>
          </div>
        </div>
        <!---->
        <!-- 약관, 광고정보 수신 동의 -->
        <div class="terms_agree_box">
          <!-- 신세계포인트 -->
          <div class="agree_form_box">
            <h3 class="tit2">신세계포인트</h3>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms00" type="checkbox">
                  <label for="terms00"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show" @click="$commonLib.layerOpen.show($event,'privacyAgreeDetailPopup')"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms01" type="checkbox">
                  <label for="terms01"><span class="in_box">[선택] 이마트/신세계 공동 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt">
              <p class="add_info_agree_tit">신세계포인트 광고정보 수신동의</p>
              <div class="chk_box">
                <input id="receveAll" type="checkbox">
                <label for="receveAll">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve00" type="checkbox">
                  <label for="receve00">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve01" type="checkbox">
                  <label for="receve01">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve02" type="checkbox">
                  <label for="receve02">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve03" type="checkbox">
                  <label for="receve03">TM</label>
                </div>
              </div>
            </div>
          </div>
          <!-- //신세계포인트 -->
          <!-- 관계사 -->
          <div class="agree_form_box" :class="{w_bar:!this.$root.isMobile}">
            <h3 class="tit2 pd_t40">시코르<!--관계사--></h3>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms10" type="checkbox">
                  <label for="terms10"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt">
              <p class="add_info_agree_tit">시코르<!--관계사--> 광고정보 수신동의</p>
              <div class="chk_box">
                <input id="receveAll2" type="checkbox">
                <label for="receveAll2">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve10" type="checkbox">
                  <label for="receve10">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve11" type="checkbox">
                  <label for="receve11">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve12" type="checkbox">
                  <label for="receve12">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve13" type="checkbox">
                  <label for="receve13">TM</label>
                </div>
              </div>
            </div>
          </div>
          <!-- //관계사 -->
        </div>
        <!-- //약관, 광고정보 수신 동의 -->

        <div class="adinfo_cnt0">
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">확인</a>
          </div>
        </div>
        <!---->
        <div class="notice_box pd_type1" :class="{bdt1:!this.$root.isMobile}">
          <!-- Y20210801 문구 수정 -->
          <h3 class="tit">[유의사항]</h3>
          <ul class="list_cnt">
            <li>광고정보 수신거부와 관계없이 회원 및 서비스 정책 변경, 주문/배송 안내,  법적 의무사항 등 안내성 고지 사항은 정상 발송됩니다.</li>
            <li>광고정보 수신거부 전 예약 발송된 광고 메시지가 있는 경우 약 1-2일 동안 발송될 수 있습니다.</li>
          </ul>
          <!-- //Y20210801 문구 수정 -->
        </div>
      </div>
    </section>
    <Footer />
  <privacy-agree-detail-popup></privacy-agree-detail-popup>
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import PrivacyAgreeDetailPopup from '@/containers/terms/PrivacyAgreeDetailPopup'

export default {
  components: {
    Header,
    Footer,
    PrivacyAgreeDetailPopup
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
  },
  methods: {
   
  }

}
</script>
