<template>
  <div class="wrap">
    <Header/>
    <section id="content" class="content">
      <div class="w_cnt_box">
        <!--
          
        -->
        <div class="popup_mockup">
          <h3 class="tit">레이어팝업</h3>
          <table class="table0">
            <colgroup>
              <col>
              <col>
              <col>
              <col style="width:80px;">
            </colgroup>
            <thead>
              <tr>
                <th>해당 화면</th>
                <th>설명</th>
                <th>상태</th>
                <th>보기</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>공통</td>
                <td class="td0">우편번호찾기</td>
                <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'findPostalCodePopup')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td>공통</td>
                <td class="td0">우편번호찾기(검색결과 없음)</td>
                <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'findPostalCodeNonPopup')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td>회원가입 완료</td>
                <td class="td0">맞춤혜택 서비스 팝업</td>
                <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'personalizedBenefitsPopup')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td>회원 탈퇴</td>
                <td class="td0">회원 탈퇴 재확인 팝업</td>
                <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
                <td>
                  <button class="btn" @click="$commonLib.layerOpen.show($event,'withdrawalReconfirmPopup')">화면보기</button>
                </td>
              </tr>
              <tr>
                <td>로딩스피너</td>
                <td class="td0">로딩중</td>
                <td>퍼블완료(2021-10-07)</td>
                <td>
                  <button class="btn" @click="loadingStart()">화면보기</button>
                </td>
              </tr>
            </tbody>
          </table>


          
        </div>

        <!-- 테스트용 -->
        <a href="#n">테스트 포커스</a><br>
        <a href="#n">테스트 포커스2</a><br>
        <a href="#n">테스트 포커스3</a><br>
        <!-- //테스트용 -->

        <!-- 주소 검색 팝업(공통) -->
        <find-postal-code-popup></find-postal-code-popup>
        <find-postal-code-non-popup></find-postal-code-non-popup>


        <!-- 맞춤혜택 서비스 팝업(회원가입 완료) -->
        <personalized-benefits-popup></personalized-benefits-popup>

        <!-- 회원 탈퇴 재확인 팝업창(회원 탈퇴) -->
        <withdrawal-reconfirm-popup></withdrawal-reconfirm-popup>

        <loading-spinner v-if="$store.state.loading" />

        <!-- 테스트용 -->
        <a href="#n">테스트 포커스</a><br>
        <a href="#n">테스트 포커스2</a><br>
        <a href="#n">테스트 포커스3</a><br>
        <!-- //테스트용 -->
      </div>
    </section>
    <Footer/>
  </div>
</template>

<style>
  /* 목업 화면 용 css(개발 반영X) */
  body{background:#f8f8f8;}
  .popup_mockup{min-height:100vh;box-sizing:border-box;padding:0 5px;}
  .popup_mockup .tit{font-size:18px;padding:30px 20px 15px 20px;}
  .popup_mockup .txt{font-size:15px;padding:0 0 10px 0;}
  .popup_mockup .btn{border:1px solid #555;font-size:12px;padding:4px 10px;background:#fff;margin-right:10px;}
  .popup_mockup .table0{width:100%;table-layout:fixed;box-sizing:border-box;border-top:2px solid #333;}
  .popup_mockup .table0 td{text-align:center;border-bottom:1px solid #333;border-right:1px dotted #333;font-size:14px;vertical-align:middle;padding:5px 5px;word-break:break-all;}
  .popup_mockup .table0 td:last-child{border-right:0;}
  .popup_mockup .table0 td.td0{text-align:left;font-size:12px;}
  .popup_mockup .table0 th{border-bottom:2px solid #222;text-align:center;padding:8px 0;font-size:14px;font-weight:500;vertical-align:middle;}
  .popup_mockup .table0 td button{margin:0;}
  .popup_mockup .table0 tr td:nth-child(3){font-size:13px;}
  .popup_mockup .table0 th.th0{border-bottom:none;}
  .popup_mockup .table0 tr:hover td{background:#efefef;}
</style>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

import FindPostalCodePopup from '@/containers/popup/FindPostalCodePopup.vue'
import FindPostalCodeNonPopup from '@/containers/popup/FindPostalCodeNonPopup.vue'
import WithdrawalReconfirmPopup from '@/containers/popup/WithdrawalReconfirmPopup'

import PersonalizedBenefitsPopup from '@/containers/popup/PersonalizedBenefitsPopup.vue'
import LoadingSpinner from '@/components/loading/loadingSpinner.vue'


export default {
  components: {
    Header,
    Footer,
    FindPostalCodePopup,
    FindPostalCodeNonPopup,
    WithdrawalReconfirmPopup,
    PersonalizedBenefitsPopup,
    LoadingSpinner
  },
  props: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    //this.$commonLib.layerOpen.show(null,'personalizedBenefitsPopup')
  },
  methods: {
    loadingStart(){
      this.$store.state.loading = true
    }
  }

}
</script>
