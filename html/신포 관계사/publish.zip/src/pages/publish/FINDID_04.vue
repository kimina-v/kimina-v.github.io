<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">아이디 찾기</h2>
        </div>
        <div class="bd_cnt_box" :class="{mg_b150:!this.$root.isMobile}">
          <p class="top_tit">입력하신 정보로 가입된<br v-if="this.$root.isMobile"> <strong class="txt_line0">아이디</strong>는 아래와 같습니다. </p>
          <div class="info">
            <dl class="cnt">
              <dt class="tit">아이디</dt>
              <dd class="txt">shinsegae12</dd>
            </dl>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">로그인</a>
          </div>
        </div>
      </div>
      <div class="w_cnt_full bg0">
        <div class="w_cnt_box">
          <find-pw-btn-box></find-pw-btn-box>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import FindPwBtnBox from "@/components/member/FindPwBtnBox.vue"

export default {
  components: {
    Header,
    Footer,
    FindPwBtnBox
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
