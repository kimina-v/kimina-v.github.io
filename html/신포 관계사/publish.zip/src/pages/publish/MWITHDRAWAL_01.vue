<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">회원 탈퇴</h2>
        </div>
        <div class="bd_cnt_box type3">
          <p class="top_tit">개인정보 보호를 위해<br> <strong class="txt_line0">비밀번호를 확인</strong>하고 있습니다.</p>
          <p class="top_txt">현재 사용중인 비밀번호를 입력해주세요.</p>
          <div class="form_container">
            <div class="form_box">
              <p class="tit">비밀번호</p>
              <div class="input_box">
                <input id="pw00" type="password" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="pw00"><span class="in_box">비밀번호를 입력해주세요.</span></label>
              </div>
            </div>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">확인</a>
          </div>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
