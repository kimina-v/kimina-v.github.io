<template>
  <div id="wrap" class="wrap">
      <div class="page_tit">
        <h2>화면 리스트</h2>
      </div>
      <!-- 수정이력 -->
      <div class="con_tit">
        <h3>수정 이력</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="width:150px;">
            <col style="width:100px;">
            <col style="width:100px;">
            <col style="width:150px;">
          </colgroup>
          <thead>
            <tr>
              <th>수정 요청 파일명<br>(경로 : /90.디나인컴즈(2차)/03_구현/02_퍼블/퍼블 요청사항)</th>
              <th>수정 위치 표시</th>
              <th>image 수정</th>
              <th>css 수정</th>
              <th>상태</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>'2021.06.22 퍼블 수정요청.xlsx' (관계사 참고)<br>주소검색팝업 수정</td>
              <td>Y20210623</td>
              <td>O</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>유의사항 추가 및 수정사항</td>
              <td>Y20210801</td>
              <td>X</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>푸터 수정</td>
              <td>Y20210802</td>
              <td>X</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>문구, readonly->disabled로 수정</td>
              <td>b20210813</td>
              <td>X</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>약관 수정,포커스 outline 수정</td>
              <td>b20210823,b20210824</td>
              <td>X</td>
              <td>X</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>띄어쓰기 수정,class 수정,태그수정</td>
              <td>b20210825</td>
              <td>O</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>띄어쓰기 수정,class 수정,태그수정</td>
              <td>b20210826</td>
              <td>O</td>
              <td>O</td>
              <td>완료</td>
            </tr>
            <tr>
              <td>띄어쓰기 수정,class 수정,태그수정</td>
              <td>b20210827</td>
              <td>O</td>
              <td>O</td>
              <td>완료</td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- //수정이력 -->
      <!-- 로그인  -->
      <div class="con_tit">
        <h3>메인</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">메인</td>
              <td>P_MAIN_01</td>
              <td>M_MAIN_01</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td></td>
              <td>
                <router-link to="/publish/MAIN_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //로그인  -->

      <!-- 로그인  -->
      <div class="con_tit">
        <h3>로그인</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">로그인 페이지</td>
              <td>P_LOGIN_01</td>
              <td>M_LOGIN_01</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td>20210903수정완료</td>
              <td>
                <router-link to="/publish/LOGIN_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">로그인 페이지(캡챠)</td>
              <td>P_LOGIN_02</td>
              <td>M_LOGIN_02</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td>20210903수정완료</td>
              <td>
                <router-link to="/publish/LOGIN_02" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //로그인  -->

      <!-- 아이디/패스워드 찾기 -->
      <div class="con_tit">
        <h3>아이디/패스워드 찾기</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">아이디찾기 인증 페이지</td>
              <td>P_FINDID_01,<br> P_FINDID_02,<br> P_FINDID_04</td>
              <td>M_FINDID_01,<br> M_FINDID_02,<br> M_FINDID_04</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td></td>
              <td>
                <router-link to="/publish/FINDID_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">아이디 노출 페이지</td>
              <td>P_FINDID_04</td>
              <td>M_FINDID_06</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td>
              <td>
                <router-link to="/publish/FINDID_04" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">비밀번호 찾기 인증 페이지</td>
              <td>P_FINDPASS_01,<br> P_FINDPASS_02,<br> P_FINDPASS_04</td>
              <td>M_FINDPASS_01,<br> M_FINDPASS_02,<br> M_FINDPASS_04</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td>
              <td>
                <router-link to="/publish/FINDPASS_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">비밀번호 찾기 비밀번호 입력</td>
              <td>P_FINDPASS_04</td>
              <td>M_FINDPASS_06</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td>
              <td>
                <router-link to="/publish/FINDPASS_04" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //아이디/패스워드 찾기 -->

      <!-- 회원가입 -->
      <div class="con_tit">
        <h3>회원가입</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">회원가입 페이지</td>
              <td>P_JOINMEMBER_01</td>
              <td>M_JOINMEMBER_01</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td>
              <td>
                <router-link to="/publish/JOINMEMBER_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 본인인증 페이지</td>
              <td>P_JOINMEMBER_02,<br> P_JOINMEMBER_04,<br> P_JOINMEMBER_05</td>
              <td>M_JOINMEMBER_02,<br> M_JOINMEMBER_04,<br> M_JOINMEMBER_06</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td>20210901 수정완료</td>
              <td>
                <router-link to="/publish/JOINMEMBER_02" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 아이디 노출 페이지</td>
              <td>P_JOINMEMBER_06</td>
              <td>M_JOINMEMBER_08</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td>20210901 수정완료</td>
              <td>
                <router-link to="/publish/JOINMEMBER_06" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 약관 동의</td>
              <td>P_JOINMEMBER_07</td>
              <td>M_JOINMEMBER_09</td>
              <td>퍼블완료(2021-05-31)<br>검수완료(2021-06-07)</td>
              <td></td>
              <td>
                <router-link to="/publish/JOINMEMBER_07" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 정보 입력</td>
              <td>P_JOINMEMBER_10</td>
              <td>M_JOINMEMBER_12</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/JOINMEMBER_10" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 가입 완료</td>
              <td>P_JOINMEMBER_11</td>
              <td>M_JOINMEMBER_13</td>
              <td>퍼블완료(2021-06-11)<br>검수완료(2021-06-14)</td>
              <td>20210901 수정완료</td>
              <td>
                <router-link to="/publish/JOINMEMBER_11" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원가입 가입 완료(관계사 PC 슬라이드)</td>
              <td>P_JOINMEMBER_11</td>
              <td>M_JOINMEMBER_13</td>
              <td>퍼블완료(2021-06-11)<br>검수완료(2021-06-14)</td>
              <td>20210901 수정완료</td>
              <td>
                <router-link to="/publish/JOINMEMBER_11_2" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">기존 통합ID 회원 추가 가입 페이지</td>
              <td>P_JOINMEMBER_12</td>
              <td>M_JOINMEMBER_14</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/JOINMEMBER_12" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">기존 통합ID 회원 가입 완료 페이지</td>
              <td>P_JOINMEMBER_13</td>
              <td>M_JOINMEMBER_15</td>
              <td>퍼블완료(2021-06-11)<br>검수완료(2021-06-14)</td>
              <td>20210901 수정완료</td>
              <td>
                <router-link to="/publish/JOINMEMBER_13" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //회원가입 -->

      <!-- 회원정보 수정 -->
      <div class="con_tit">
        <h3>회원정보 수정</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">회원정보 수정 본인인증 페이지</td>
              <td>P_PRIVACY_01,<br>P_PRIVACY_02,<br>P_PRIVACY_03</td>
              <td>M_PRIVACY_01,<br>M_PRIVACY_02,<br>M_PRIVACY_04</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/PRIVACY_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원정보 수정 페이지</td>
              <td>P_PRIVACY_04</td>
              <td>M_PRIVACY_06</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/PRIVACY_04" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //회원정보 수정 -->

      <!-- 광고정보 수신관리 -->
      <div class="con_tit">
        <h3>광고정보 수신관리</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">광고정보수신관리 페이지</td>
              <td>P_ADINFO_01</td>
              <td>M_ADINFO_01</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td>202100901수정완료</td>
              <td>
                <router-link to="/publish/ADINFO_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- //광고정보 수신관리 -->

      <!-- 비밀번호 변경 -->
      <div class="con_tit">
        <h3>비밀번호 변경</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">비밀번호 변경 본인인증</td>
              <td>P_CHANGEPASS_01,<br>P_CHANGEPASS_02,<br>P_CHANGEPASS_03</td>
              <td>M_CHANGEPASS_01,<br>M_CHANGEPASS_02,<br>M_CHANGEPASS_04</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/CHANGEPASS_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">비밀번호 변경 페이지</td>
              <td>P_CHANGEPASS_04</td>
              <td>M_CHANGEPASS_06</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/CHANGEPASS_04" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- //비밀번호 변경 -->

      <!-- 회원 탈퇴 -->
      <div class="con_tit">
        <h3>회원 탈퇴</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">회원 탈퇴 비밀번호 입력 페이지</td>
              <td>P_MWITHDRAWAL_01</td>
              <td>M_MWITHDRAWAL_01</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/MWITHDRAWAL_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">회원 탈퇴 상세 안내 페이지</td>
              <td>P_MWITHDRAWAL_02</td>
              <td>M_MWITHDRAWAL_02</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/MWITHDRAWAL_02" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //회원 탈퇴 -->

      <!-- 휴면회원 본인인증 -->
      <div class="con_tit">
        <h3>휴면회원 본인인증</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">휴면회원 본인인증 페이지</td>
              <td>P_INACTIVEMEMBER_01,<br>P_INACTIVEMEMBER_02,<br>P_INACTIVEMEMBER_03</td>
              <td>M_INACTIVEMEMBER_01,<br>M_INACTIVEMEMBER_02,<br>M_INACTIVEMEMBER_04</td>
              <td>퍼블완료(2021-06-08)<br>검수완료(2021-06-08)</td>
              <td></td>
              <td>
                <router-link to="/publish/INACTIVEMEMBER_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //휴면회원 본인인증 -->

      <!-- 푸터 -->
      <div class="con_tit">
        <h3>푸터</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">화면명</th>
              <th colspan="2" class="th0">화면 ID</th>
              <th rowspan="2">상태</th>
              <th rowspan="2">수정사항</th>
              <th rowspan="2">바로가기</th>
            </tr>
            <tr>
              <th>PC</th>
              <th class="th1">Mobile</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">개인정보 처리방침</td>
              <td>P_POLICY_01</td>
              <td>M_POLICY_01</td>
              <td>퍼블완료(2021-06-08 / 약관내용 제외)<br>검수완료(2021-06-08)</td>
              <td>20210909수정완료</td>
              <td>
                <router-link to="/publish/POLICY_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">서비스 이용약관</td><!--b20210826문구수정-->
              <td>P_TERMS_01</td>
              <td>M_TERMS_01</td>
              <td>퍼블완료(2021-06-08 / 약관내용 제외)<br>검수완료(2021-06-08)</td>
              <td>20210831수정완료</td>
              <td>
                <router-link to="/publish/TERMS_01" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //푸터 -->

      <!-- 팝업 -->
      <div class="con_tit">
        <h3>팝업</h3>
      </div>
      <div class="form_table list">
        <!-- form_table -->
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th>화면명</th>
              <th></th>
              <th></th>
              <th>바로가기</th>
            </tr>
          </thead>
          <tbody>
            <!-- <tr>
              <td class="left">얼럿 팝업모음</td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/ALERT_GROUP" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr> -->
            <tr>
              <td class="left">얼럿 팝업</td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/ALERT_GROUP" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">레이어 팝업</td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/LAYER_POPUP" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
            <tr>
              <td class="left">약관 팝업</td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/TERMS_POPUP" target="_blank">
                  <button class="s_btn">화면보기</button>
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- //팝업 -->

      <!-- 에러페이지 -->
      <div class="con_tit">
        <h3>에러페이지</h3>
      </div>
      <div class="form_table list">
        <table>
          <caption />
          <colgroup>
            <col style="">
            <col style="">
            <col style="">
            <col style="">
          </colgroup>
          <thead>
            <tr>
              <th>화면명</th>
              <th>화면 ID</th>
              <th>상태</th>
              <th>바로가기</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">서비스 일시 오류</td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/ERROR_01" target="_blank">
                  <button class="s_btn">vue 화면보기</button>
                </router-link>
                <br>
                <a href="/error/error1.html" target="_blank">html 화면보기</a>
              </td>
            </tr>
            <tr>
              <td class="left">
                페이지 찾기 오류
              </td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/ERROR_02" target="_blank">
                  <button class="s_btn">vue 화면보기</button>
                </router-link>
                <br>
                <a href="/error/error2.html" target="_blank">html 화면보기</a>
              </td>
            </tr>
            <tr>
              <td class="left">
                서비스 점검 안내
              </td>
              <td></td>
              <td></td>
              <td>
                <router-link to="/publish/ERROR_03" target="_blank">
                  <button class="s_btn">vue 화면보기</button>
                </router-link>
                <br>
                <a href="/error/error3.html" target="_blank">html 화면보기</a>
              </td>
            </tr>
          </tbody>
        </table>
      </div><!-- form_table -->
      <!-- //에러페이지 -->

      <!-- 가이드 -->
        <div class="con_tit">
          <h3>가이드</h3>
        </div>
        <div class="form_table list">
          <table>
            <caption />
            <colgroup>
              <col style="">
              <col style="">
              <col style="">
              <col style="">
            </colgroup>
            <thead>
              <tr>
                <th>화면명</th>
                <th>화면 ID</th>
                <th>상태</th>
                <th>바로가기</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="left">가이드</td>
                <td></td>
                <td></td>
                <td>
                  <router-link to="/publish/guide_01" target="_blank">
                    <button class="s_btn">화면보기</button>
                  </router-link>
                </td>
              </tr>
            </tbody>
          </table>
        </div><!-- form_table -->
        <!-- //가이드 -->
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
body {
  width:100%;
  background: #7c6e66;
  overflow: auto;
}
#app {
  width: 100%;
}
#app th.left,
#app td.left {
  text-align: left;
  padding-left: 10px;
}
#app .wrap {
  padding:30px;
  box-sizing:border-box;
  width: 640px;
  margin:0 auto;
}

@media (min-width: 640px) {
  #app .wrap {
    width: 100%;
  }
}

header {
  position: fixed;
  width: 100%;
  left: 0;
  top: 0;
  background: #7c6e66;
  z-index: 999;
}

header a {
  background: url(/assets/images/logo_home.png) no-repeat;
  width: 170px;
  height: 28px;
  display: block;
  text-indent: -9999px;
  margin: 10px 10px 20px;
}

main {
  position: relative;  z-index: 1;
  margin: 0 10px;
  padding: 0 20px;
  background: #fff;
  border-radius: 5px;
  transition: all 0.5s ease-in-out;
  box-sizing: border-box;
  overflow: hidden;
}

.page_tit {
  position: relative;
  top: 0;
  left: 0;
  margin-bottom: 30px;
  border-bottom: 1px solid #e3dcd7;
  padding: 50px 0 15px 0;
}
.page_tit h2 {
  font-size: 26px;
  color: #424242;
}
.page_tit ul {
  position: absolute;
  left: 0;
  top: 25px;
}
.page_tit ul li {
  display: inline-block;
  background: url(/assets/images/ioc_tit_arr.png) right center no-repeat;
  padding-right: 20px;
  margin-right: 10px;
  font-size: 12px;
}
.page_tit ul li:last-child {
  background: none;
}

.con_tit {
  position: relative;
  margin-bottom: 15px;
  height: 19px;
}
.con_tit.top_ma {
  margin-top: 20px;
}
.con_tit h3 {
  font-size: 18px;
  background: url(/assets/images/ioc_con_tit.png) left center no-repeat;
  padding-left: 10px;
  display: inline-block;
  vertical-align: middle;
  margin-right: 10px;
}
.con_tit p.num {
  display: inline-block;
  vertical-align: middle;
  font-size: 13px;
}
.con_tit .btn {
  position: absolute;
  right: 0;
  top: -5px;
  font-size: 0;
}
.con_tit .btn button {
  margin-left: 5px;
}
.con_tit .btn span {
  font-size: 14px;
  line-height: 28px;
  vertical-align: middle;
  margin-right: 10px;
}

.form_table {
  margin-bottom: 30px;
}
.form_table.ma_10 {
  margin-bottom: 10px;
}
.form_table.ma_20 {
  margin-bottom: 20px;
}
.form_table > table {
  border-collapse: collapse;
  border-spacing: 0px;
  font-size: 14px;
  text-align: center;
  width: 100%;
  table-layout: fixed;
  border-top: 1px solid #827269;
}
.form_table > table > thead > tr > th {
  background: #f7f4f3;
  border-bottom: 1px solid #d0c1b6;
  padding:  0;
  line-height: 26px;
  vertical-align:middle;
  border-right:1px dashed #e3dcd7;
}
.form_table > table > thead > tr > th:last-child{
  border-right:none;
}
.form_table > table > thead > tr > th.th0{
  border-bottom:1px dashed #e3dcd7
}
.form_table > table > thead > tr > th.th1{
  border-right:1px dashed #e3dcd7;
}
.form_table > table > tbody > tr > th {
  background: #f7f4f3;
  height: 26px;
  border-bottom: 1px solid #e3dcd7;
  text-align: center;
  padding: 7px 0;
  line-height: 18px;
  text-align: left;
  padding-left: 10px;
}
.form_table > table > tbody > tr > th + th {
  border-left: 1px solid #e3dcd7;
}
.form_table > table > tbody > tr > th.e {
  background: #f7f4f3 url(/assets/images/th_e.png) left top no-repeat;
}
.form_table > table > tbody > tr > td {
  height: 26px;
  border-bottom: 1px solid #d0c1b6;
  text-align: left;
  padding: 7px 10px;
  vertical-align: top;
  line-height: 24px;
  border-right:1px dashed #e3dcd7;
}
.form_table > table > tbody > tr > td:nth-child(4){font-size:12px;}
.form_table > table > tbody > tr > td:last-child{
  border-right:none;
  font-size:14px;
}
.form_table > table > tbody > tr > td.line {
  border-right: 1px solid #e3dcd7;
}
.form_table > table > tbody > tr.line > td {
  border-right: 1px solid #e3dcd7;
}
.form_table > table > tbody > tr.line > td:last-child {
  border-right: none;
}
.form_table > table > tbody > tr > td input[type="text"] {
  width: 100%;
}
.form_table > table > tbody > tr > td input[type="password"] {
  width: 100%;
}
.form_table > table > tbody > tr > td select {
  max-width: 100%;
}
.form_table > table > tbody > tr > td > span {
  display: inline-block;
  vertical-align: middle;
  line-height: 18px;
}
.form_table > table > tbody > tr > td > span.sms_byte {
  margin-top: 10px;
}
.form_table > table > tbody > tr > td > .con_tit {
  margin-top: 10px;
}
.form_table.list > table > tbody > tr > td {
  text-align: center;
  vertical-align: middle;
}
.form_table.list > table > tbody > tr:hover > td {
  background: #f6f6f6;
}
.form_table p.txt {
  display: block;
  line-height: 30px;
}

.form_table.progress > table > tbody > tr > td {
  text-align: center;
  vertical-align: middle;
  border: 1px solid #827269;
  font-weight: bold;
}
.form_table.progress > table > tbody > tr > td.active {
  background: #e8f2fe;
}

.ftclr_red {
  color: red;
}
.ftclr_blue {
  color: blue;
}
.endlist {
  border: 1px solid #888;
  background-color: #f5f5f5;
  padding: 10px 20px 20px;
  margin-bottom: 50px;
}
.endlist * {
  font-size: 12px;
  line-height: 1.4;
}
.endlist dl:after,
.endlist dl dd {
  content: " ";
  display: table;
  clear: both;
}
.endlist dl {
  display: table;
  width: 100%;
  margin-top: 8px;
}
.endlist dl dt {
  display: table-cell;
  width: 120px;
  font-size: 12px;
  font-weight: bold;
  vertical-align: top;
}
.endlist dl dd {
  display: table-cell;
  width: calc(100% - 120px);
}
.endlist dl dd > b {
  float: left;
  width: 8%;
  min-width: 70px;
  font-size: 12px;
  font-weight: bold;
}
.endlist dl dd > ul {
  float: left;
  width: 92%;
  max-width: 800px;
}
.endlist dl dd > ul li {
  margin-top: 4px;
}
.endlist dl dd > ul li:first-child {
  margin-top: 0;
}
</style>
