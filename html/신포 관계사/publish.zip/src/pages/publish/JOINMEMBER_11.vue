<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt bdb0">
          <h2 class="tit">회원가입</h2>
        </div>
        <div class="join_step step4">
          <ol>
            <li><span>1</span></li>
            <li><span>2</span></li>
            <li><span>3</span></li>
            <li><span>4</span></li>
          </ol>
          <p class="tit">가입완료</p>
        </div>
        <div class="join_cnt2">
          <p class="sp_tit1">
            <strong class="txt_line0">신세계</strong> 님,
            <span class="user_underline">shinsegae12</span> ID로
            <br>신세계포인트 통합 회원 가입이 완료되었습니다.
          </p>
        </div>
        <user-info-box></user-info-box>
        <group-join-tab></group-join-tab>
        <div class="join_cnt4">
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">로그인하기</a>
          </div>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import UserInfoBox from '@/components/member/userInfoBox.vue'
import GroupJoinTab from '@/components/member/GroupJoinTab.vue'

export default {
  components: {
    Header,
    Footer,
    UserInfoBox,
    GroupJoinTab
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
