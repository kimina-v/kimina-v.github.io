<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box2">
        <div class="main_top_box" :class="{login:$store.state.loginSuccess}"><!-- 로그인 시 login 클래스 추가 -->
          <h2 class="tit"><strong>신세계포인트 통합ID</strong> 하나면 <br v-if="!this.$root.isMobile">신세계가 한손안에 쓱 -</h2>
          <p class="txt">차별화된 서비스를 누리는 스마트한 방법!<br>신세계포인트 통합ID로 다양한 온라인 서비스와 특별한 혜택을 만나보실 수 있습니다. </p>
          <div class="main_btn_box" v-if="!$store.state.loginSuccess">
            <a href="javascript:void(0)" class="btn0" @click="loginTry">로그인</a>
            <a href="javascript:void(0)" class="btn1">회원가입</a>
          </div>
        </div>
      </div>
      <div class="w_cnt_full bg0">
        <div class="w_cnt_box2">
          <div class="main_mymember_box" :class="{login:$store.state.loginSuccess}"><!-- 로그인 시 login 클래스 추가 -->
            <h3 class="tit">마이 회원정보</h3>
            <p class="txt">신세계포인트 회원정보를 변경하시면 <br v-if="this.$root.isMobile">통합ID에 가입되어 있는 신세계 그룹사 회원정보가 함께 변경됩니다.</p>
            <ul class="list">
              <li class="my0"><a href="javascript:void(0)">회원정보 수정</a></li>
              <li class="my1"><a href="javascript:void(0)">광고정보 수신관리</a></li>
              <li class="my2"><a href="javascript:void(0)">비밀번호 변경</a></li>
              <li class="my3"><a href="javascript:void(0)">회원 탈퇴</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="w_cnt_box2">
        <div class="main_info_box">
          <div class="info_cnt info0">
            <h4 class="tit">통합 ID 하나로 <br v-if="!this.$root.isMobile">누리는 혜택</h4>
            <p class="txt">신세계포인트 통합ID 하나로 이마트, <br v-if="!this.$root.isMobile">신세계백화점, SSG.COM 등 다양한 온라인 / <br v-if="!this.$root.isMobile">모바일 서비스를 이용할 수 있습니다.</p>
          </div>
          <div class="info_cnt info1">
            <h4 class="tit">더욱 다양해진 <br v-if="!this.$root.isMobile">신세계포인트 제휴사</h4>
            <p class="txt">생활에서 취향까지, 일상에 신세계를 <br v-if="!this.$root.isMobile">더합니다. 포인트 이용과 다양한 제휴사의 <br v-if="!this.$root.isMobile">혜택을 동시에 누려보세요!</p>
          </div>
          <div class="info_cnt info2">
            <h4 class="tit">풍성한 포인트 <br v-if="!this.$root.isMobile">서비스</h4>
            <p class="txt">매일매일 쏟아지는 포인트와 쿠폰을 통한 <br v-if="!this.$root.isMobile">기분 좋은 쇼핑! 차곡차곡 쌓은 포인트, <br v-if="!this.$root.isMobile">선물하기로 마음을 전하세요.</p>
          </div>
        </div>
      </div>
      <div class="main_group_btn_box">
        <a href="javascript:void(0)">신세계포인트 제휴사 보기</a>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    loginTry(){//퍼블 확인 용
      this.$store.state.loginSuccess = true
    }
  }

}
</script>
