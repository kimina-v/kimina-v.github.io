<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt bdb0">
          <h2 class="tit">회원가입</h2>
        </div>
        <div class="join_step step2">
          <ol>
            <li><span>1</span></li>
            <li><span>2</span></li>
            <li><span>3</span></li>
            <li><span>4</span></li>
          </ol>
          <p class="tit">약관동의</p>
        </div>
        <div class="join_cnt0">
          <div class="join_agree_box">
            <div class="chk_box2">
              <input id="termsAllChk" type="checkbox">
              <label for="termsAllChk">필수항목 전체 선택</label>
            </div>
            <p class="tit">신세계포인트 통합회원</p><!--b20210826 문구 및 태그 수정-->
            <p class="txt">㈜이마트, ㈜신세계, ㈜광주신세계, ㈜신세계동대구복합환승센터 귀중</p><!--b20210826 문구 및 태그 수정-->
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms00" type="checkbox">
                  <label for="terms00"><span class="in_box">[필수] 신세계포인트 회원 이용약관</span></label>
                </div>
                <button class="agree_show" @click="$commonLib.layerOpen.show($event,'ShinsegaePointRequired01')">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms01" type="checkbox">
                  <label for="terms01"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label><!--b20210827 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms02" type="checkbox">
                  <label for="terms02"><span class="in_box">[필수] 이마트/신세계 공동 개인정보 수집 및 이용 동의</span></label><!--b20210825 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms03" type="checkbox">
                  <label for="terms03"><span class="in_box">[필수] 통합회원 서비스 제공 개인정보 제3자 제공 동의</span></label>
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms04" type="checkbox">
                  <label for="terms04"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210825 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms05" type="checkbox">
                  <label for="terms05"><span class="in_box">[선택] 이마트/신세계 공동 개인정보 수집 및 이용 동의</span></label><!--b20210825 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
            </ul>
            <p class="tit">신세계아울렛<!--관계사--></p><!--b20210825 문구 수정-->
            <p class="txt">㈜신세계사이먼 귀중</p><!--b20210826 문구 및 태그 수정-->
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms10" type="checkbox">
                  <label for="terms10"><span class="in_box">[필수] 신세계아울렛 회원 이용약관<!--관계사--></span></label><!--b20210825 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms11" type="checkbox">
                  <label for="terms11"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms12" type="checkbox">
                  <label for="terms12"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210825 문구 수정-->
                </div>
                <button class="agree_show">
                  <span>내용보기</span>
                </button>
              </li>
            </ul>
          </div>
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">다음</a>
          </div>
          <ul class="list_cnt space0 pd_t40"><!-- Y20210801  star 클래스 삭제 -->
            <!-- Y20210801 문구수정 ,b20210831 문구 수정 -->
            <li>선택항목 수집 및 이용동의를 거부하시더라도 기본 서비스는 이용하실 수 있습니다.</li>
            <li>이미 신세계포인트 회원이신 경우 신세계포인트 온라인 통합ID 가입 시 입력한 정보로 회원정보가 변경됩니다.</li>
            <!-- //Y20210801 문구수정 -->
          </ul>
        </div>
      </div>
    </section>
    <Footer />
    <shinsegae-point-required01></shinsegae-point-required01>
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import ShinsegaePointRequired01 from '@/containers/terms/ShinsegaePointRequired01.vue'


export default {
  components: {
    ShinsegaePointRequired01,
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
