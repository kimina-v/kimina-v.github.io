<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt bdb0">
          <h2 class="tit">회원가입</h2>
        </div>
        <div class="join_step step3">
          <ol>
            <li><span>1</span></li>
            <li><span>2</span></li>
            <li><span>3</span></li>
            <li><span>4</span></li>
          </ol>
          <p class="tit">정보입력</p>
          <p class="txt">필수 정보를 정확하게 입력해주세요.</p>
        </div>
        <div class="join_cnt2">
          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">아이디</p>
            <div class="input_btn_box">
              <div class="input_box">
                <input id="id00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="id00"><span class="in_box">영문,숫자 6~20자리 입력해주세요.</span></label><!--b20210825 문구 수정-->
              </div>
              <div class="btn_box">
                <button class="btn2">중복확인</button>
              </div>
            </div>
            <!-- validation 문구 -->
            <p class="error_txt">아이디 형식에 맞게 입력해주세요.</p>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">비밀번호</p>
            <div class="input_box">
              <input id="pw00" type="password" value="" @input="$commonLib.inputLabelSet($event)">
              <label for="pw00"><span class="in_box">숫자, 영문자 조합으로 8~20자리 입력해주세요.</span></label>
            </div>
            <!-- validation 문구 -->
            <p class="error_txt">비밀번호 형식에 맞게 입력해주세요.</p>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">비밀번호 확인</p>
            <div class="input_box">
              <input id="pw01" type="password" value="" @input="$commonLib.inputLabelSet($event)">
              <label for="pw01"><span class="in_box">입력하신 비밀번호를 다시 한번 입력해주세요.</span></label>
            </div>
            <!-- validation 문구 -->
            <p class="error_txt">비밀번호가 일치하지 않습니다.</p>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">이름</p>
            <div class="input_box">
              <input id="name00"  type="text" class="readonly_bg" value="신세계" disabled ><!-- b20210813 readonly -> disabled로 수정 -->
              <!-- Y20210801 클래스 수정 -->
              <label for="name00" class="unuse"><span class="in_box">이름 입력</span></label>
            </div>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">휴대폰번호</p>
            <div class="input_box">
              <input id="phone00" class="readonly_bg" type="tel" value="010-1234-1234" disabled ><!-- b20210813 readonly -> disabled로 수정 -->
              <!-- Y20210801 클래스 수정 -->
              <label for="phone00" class="unuse"><span class="in_box">휴대폰 번호 입력</span></label>
            </div>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">이메일</p>
            <div class="input_mail_box">
              <div class="input_box">
                <input id="mail00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="mail00"><span class="in_box">이메일을 입력해주세요.</span></label>
              </div>
              <div class="col2_box">
                <div class="input_box">
                  <input id="mail01" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                  <label for="mail01" class="unuse"><span class="in_box">이메일 도메인</span></label>
                </div>
                <div class="select_box">
                  <select id="" title="이메일 선택">
                    <option val="">선택해주세요.</option>
                    <option val="">직접입력</option>
                    <option val="">naver.com</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div class="form_box required"><!-- 필수 입력 항목  required 클래스 추가 -->
            <p class="tit">자택주소</p>
            <div class="input_address_box">
              <div class="input_btn_box w_type2">
                <div class="input_box">
                  <input id="address00" type="text" value="" @input="$commonLib.inputLabelSet($event)" disabled><!-- b20210813 readonly -> disabled로 수정 -->
                  <label for="address00"><span class="in_box">우편번호</span></label>
                </div>
                <div class="btn_box">
                  <button class="btn2">우편번호 찾기</button>
                </div>
              </div>
              <div class="input_box">
                <input id="address01" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="address01" class="hide"><span class="in_box">주소</span></label>
              </div>
              <div class="input_box">
                <input id="address02" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                <label for="address02"><span class="in_box">상세주소</span></label>
              </div>
            </div>
          </div>
        </div>

        <!-- 약관, 광고정보 수신 동의 -->
        <div class="terms_agree_box">
          <div class="agree_form_box">
            <!-- 신세계포인트 -->
            <h3 class="tit2">신세계포인트</h3>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms00" type="checkbox">
                  <label for="terms00"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms01" type="checkbox">
                  <label for="terms01"><span class="in_box">[선택] 이마트/신세계 공동 개인정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt">
              <p class="add_info_agree_tit">신세계포인트 광고정보 수신동의</p>
              <div class="chk_box">
                <input id="receveAll" type="checkbox">
                <label for="receveAll">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve00" type="checkbox">
                  <label for="receve00">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve01" type="checkbox">
                  <label for="receve01">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve02" type="checkbox">
                  <label for="receve02">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve03" type="checkbox">
                  <label for="receve03">TM</label>
                </div>
              </div>
            </div>
            <!-- //신세계포인트 -->
          </div>
          <div class="agree_form_box" :class="{w_bar:!this.$root.isMobile}">
            <!-- 관계사 -->
            <h3 class="tit2 pd_t40">이마트</h3>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="terms10" type="checkbox">
                  <label for="terms10"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 문구 수정-->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt">
              <p class="add_info_agree_tit">이마트 광고정보 수신동의</p>
              <div class="chk_box">
                <input id="receveAll2" type="checkbox">
                <label for="receveAll2">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve10" type="checkbox">
                  <label for="receve10">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve11" type="checkbox">
                  <label for="receve11">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve12" type="checkbox">
                  <label for="receve12">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve13" type="checkbox">
                  <label for="receve13">TM</label>
                </div>
              </div>
            </div>
            <!-- //관계사 -->
          </div>
        </div>
        <!-- //약관, 광고정보 수신 동의 -->

        <div class="join_cnt1">
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">확인</a>
          </div>
        </div>
        
        <!-- Y20210801 유의사항 추가 Start -->
        <div class="notice_box pd_type2">
          <h3 class="tit">[유의사항]</h3>
          <ul class="list_cnt">
            <li>아이디는 영문 소문자, 숫자를 조합하여 6~20자리로 입력해 주시기 바랍니다.</li><!--b20210907 문구추가-->
            <li>비밀번호 입력 시 영문과 숫자, 특수문자를 조합하여 8-20자리로 입력해 주시기 바랍니다.</li>
            <li>비밀번호는 3글자 이상의 동일한 숫자/문자 또는 연속된 숫자/문자는 입력하실 수 없습니다.</li>
            <li>본인인증을 통해 확인된 정보는 수정이 불가합니다. </li>
          </ul>
        </div>
        <!-- //Y20210801 유의사항 추가 End -->
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"

export default {
  components: {
    Header,
    Footer
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
