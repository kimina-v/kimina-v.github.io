<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt">
          <h2 class="tit">회원정보 수정</h2>
          <p class="txt">개인정보 보호를 위해 <span class="wp">본인인증을 진행하고 있습니다.</span> <br>자주 사용하시는 인증수단을 선택해주세요.</p>
        </div>
        <id-pw-find-tab :id-input-show="idInputShow" /><!-- idInputShow : 퍼블 확인 용 -->
        <!-- Y20210801 유의사항 수정 Start -->
        <div class="notice_box pd_type2">
          <ul class="list_cnt">
            <li>본인 명의의 인증 수단 정보를 정확히 입력해 주시기 바랍니다.</li>
            <li>본인 인증을 위해 입력한 정보는 본인인증 용도 외 다른 용도로 이용되지 않습니다.</li>
            <li>법인폰 사용자는 법인폰 개인인증 서비스 신청 후 휴대폰 인증을 하실 수 있습니다.</li>
            <li>개명하신 회원님은 본인인증정보로 회원명이 변경됩니다.</li>
            <li>인증 오류 시 코리아크레딧뷰로 고객센터 02-708-1000에 문의해 주시기 바랍니다.</li>
          </ul>
        </div>
        <!-- //Y20210801 유의사항 수정 End -->
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import IdPwFindTab  from "@/components/member/IdPwFindTab.vue"

export default {
  components: {
    Header,
    Footer,
    IdPwFindTab
  },
  pros: {
    
  },
  data : function(){
    return{
      idInputShow : false
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
