<template>
  <div id="wrap" class="wrap">
    <Header />
    <section id="content" class="content">
      <div class="w_cnt_box">
        <div class="page_tit_cnt bdb0">
          <h2 class="logo_tit">
            <logo-box></logo-box>
          </h2>
        </div>
        <div class="join_cnt3">
          <p class="sp_tit1">
            <strong class="txt_line0">신세계</strong> 님,<br>
            신세계포인트 통합ID로 시코르<!--관계사--> <span class="wp">회원 가입이</span> 완료되었습니다.
          </p>
        </div>
        <user-info-box></user-info-box>
        <group-join-tab></group-join-tab>
        <div class="join_cnt4">
          <div class="btn_box">
            <a href="javascript:void(0)" class="btn0 big sdw">로그인하기</a>
          </div>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header  from "@/components/common/Header.vue"
import Footer  from "@/components/common/Footer.vue"
import LogoBox  from "@/components/common/LogoBox.vue"
import UserInfoBox from '@/components/member/userInfoBox.vue'
import GroupJoinTab from '@/components/member/GroupJoinTab.vue'

export default {
  components: {
    Header,
    Footer,
    LogoBox,
    UserInfoBox,
    GroupJoinTab
  },
  pros: {
    
  },
  data : function(){
    return{
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>
