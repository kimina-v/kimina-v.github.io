import Vue from 'vue'
import App from './App.vue'
import router from "./router"
import axios from "@/plugins/ssgpAxios";
import store from '@/store'

import VueMoment from "vue-moment";
import DatePicker from "vue2-datepicker";
import VueBarcode from "vue-barcode";
import "vue2-datepicker/index.css";
import "vue2-datepicker/locale/ko";

import VueAwesomeSwiper from "vue-awesome-swiper/dist/ssr";
import "swiper/dist/css/swiper.css";

import commonLib from './plugins/commonLib'

Vue.use(DatePicker);
Vue.use(VueMoment);
Vue.use(VueBarcode);
Vue.component("Barcode", VueBarcode);
Vue.use(VueAwesomeSwiper);


Vue.config.productionTip = false

Vue.prototype.$axios = axios;

Vue.prototype.$commonLib = commonLib;

new Vue({
  router,
  store,
  data(){
    return {
      isMobile : false,
      window : { width: 0, height:0 },
      defaultWidth : 1097 // 모바일 , PC 화면 분기 기준
    }
  },
  mounted() {
    this.ieCheck();
    this.mobileCheck();
    this.agentCheck();//20210726 추가
    window.addEventListener("resize", this.mobileCheck);
  },
  methods: {
    mobileCheck() {
      this.isMobile = window.innerWidth < this.defaultWidth ? true : false;
      this.window.width = window.innerWidth;
      this.window.height = window.innerHeight;
    },
    ieCheck() {
      var agent = navigator.userAgent.toLowerCase();
      if ((navigator.appName == 'Netscape' && agent.indexOf('trident') != -1) || (agent.indexOf("msie") != -1)) {
        //document.getElementById('app').className += 'ie_browser';//20210726 아래 소스로 변경
        store.state.browser = "IE";
      }
    },
    agentCheck() {//20210726추가
      let userAgent = navigator.userAgent
      if(/Android/i.test(userAgent)){
        store.state.device = "MOBILE"
        store.state.agent = "ANDROID"
      }
      else if(/iOS/i.test(userAgent) || /iPhone/i.test(userAgent)){
        store.state.device = "MOBILE"
        store.state.agent = "iOS"
      }
      else{
        store.state.device = "PC"
      }
    },
  },
  render: h => h(App),
}).$mount('#app')
