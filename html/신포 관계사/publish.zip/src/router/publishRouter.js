export default [
    { 
      // dashboard
      path: "dashboard",
      component: () => import("@/pages/publish/index.vue")
    },
    { 
      // 레이어팝업
      path: "LAYER_POPUP",
      component: () => import("@/pages/publish/LAYER_POPUP.vue")
    },
    { 
      // 얼럿팝업 모음
      path: "ALERT_GROUP",
      component: () => import("@/pages/publish/ALERT_GROUP.vue")
    },
    { 
      // 약관
      path: "TERMS_01",
      component: () => import("@/pages/publish/TERMS_01.vue")
    },
    { 
      // 약관
      path: "TERMS_POPUP",
      component: () => import("@/pages/publish/TERMS_POPUP.vue")
    },
    { 
      // 약관
      path: "POLICY_01",
      component: () => import("@/pages/publish/POLICY_01.vue")
    },
    { 
      // 에러페이지
      path: "ERROR_01",
      component: () => import("@/pages/publish/ERROR_01.vue")
    },
    { 
      // 에러페이지
      path: "ERROR_02",
      component: () => import("@/pages/publish/ERROR_02.vue")
    },
    { 
      // 에러페이지
      path: "ERROR_03",
      component: () => import("@/pages/publish/ERROR_03.vue")
    },
    { 
      // 로그인페이지
      path: "LOGIN_01",
      component: () => import("@/pages/publish/LOGIN_01.vue")
    },
    { 
      // 로그인페이지 캡챠
      path: "LOGIN_02",
      component: () => import("@/pages/publish/LOGIN_02.vue")
    },
    { 
      // 아이디 찾기 인증 페이지
      path: "FINDID_01",
      component: () => import("@/pages/publish/FINDID_01.vue")
  },
  { 
    // 아이디 찾기 아이디 노출 페이지
    path: "FINDID_04",
    component: () => import("@/pages/publish/FINDID_04.vue")
  },
  { 
    // 비밀번호 찾기 인증 페이지
    path: "FINDPASS_01",
    component: () => import("@/pages/publish/FINDPASS_01.vue")
  },
  { 
    // 비밀번호 찾기 인증 페이지
    path: "FINDPASS_04",
    component: () => import("@/pages/publish/FINDPASS_04.vue")
  },
  { 
    // 회원가입 페이지
    path: "JOINMEMBER_01",
    component: () => import("@/pages/publish/JOINMEMBER_01.vue")
  },
  { 
    // 회원가입 본인 인증
    path: "JOINMEMBER_02",
    component: () => import("@/pages/publish/JOINMEMBER_02.vue")
  },
  { 
    // 회원가입 아이디노출
    path: "JOINMEMBER_06",
    component: () => import("@/pages/publish/JOINMEMBER_06.vue")
  },
  { 
    // 회원가입 약관 동의
    path: "JOINMEMBER_07",
    component: () => import("@/pages/publish/JOINMEMBER_07.vue")
  },
  { 
    // 회원가입 정보 입력
    path: "JOINMEMBER_10",
    component: () => import("@/pages/publish/JOINMEMBER_10.vue")
  },
  { 
    // 회원가입 가입 완료
    path: "JOINMEMBER_11",
    component: () => import("@/pages/publish/JOINMEMBER_11.vue")
  },
  { 
    // 회원가입 가입 완료
    path: "JOINMEMBER_11_2",
    component: () => import("@/pages/publish/JOINMEMBER_11_2.vue")
  },
  { 
    // 기존 통합ID 회원 추가 가입 페이지
    path: "JOINMEMBER_12",
    component: () => import("@/pages/publish/JOINMEMBER_12.vue")
  },
  { 
    // 기존 통합ID 회원 추가 가입 페이지
    path: "JOINMEMBER_13",
    component: () => import("@/pages/publish/JOINMEMBER_13.vue")
  },
  { 
    // 휴면회원 본인인증
    path: "INACTIVEMEMBER_01",
    component: () => import("@/pages/publish/INACTIVEMEMBER_01.vue")
  },
  { 
    // 회원정보 수정 본인인증
    path: "PRIVACY_01",
    component: () => import("@/pages/publish/PRIVACY_01.vue")
  },
  { 
    // 회원정보 수정 페이지
    path: "PRIVACY_04",
    component: () => import("@/pages/publish/PRIVACY_04.vue")
  },
  { 
    // 광고정보 수신관리 페이지
    path: "ADINFO_01",
    component: () => import("@/pages/publish/ADINFO_01.vue")
  },
  { 
    // 비밀번호 변경 본인인증
    path: "CHANGEPASS_01",
    component: () => import("@/pages/publish/CHANGEPASS_01.vue")
  },
  { 
    // 비밀번호 변경 페이지
    path: "CHANGEPASS_04",
    component: () => import("@/pages/publish/CHANGEPASS_04.vue")
  },
  { 
    // 회원 탈퇴 비밀번호 입력 페이지
    path: "MWITHDRAWAL_01",
    component: () => import("@/pages/publish/MWITHDRAWAL_01.vue")
  },
  { 
    // 회원 탈퇴 상세 안내 페이지
    path: "MWITHDRAWAL_02",
    component: () => import("@/pages/publish/MWITHDRAWAL_02.vue")
  },
  { 
    // 메인
    path: "MAIN_01",
    component: () => import("@/pages/publish/MAIN_01.vue")
  },
  { 
    // 가이드
    path: "guide_01",
    component: () => import("@/pages/publish/guide_01.vue")
  }
  ];