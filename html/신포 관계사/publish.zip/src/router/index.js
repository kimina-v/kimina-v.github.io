import Vue from "vue";
import VueRouter from "vue-router";
import routerPublish from "@/router/publishRouter"
import routerTest from "@/router/testRouter"

Vue.use(VueRouter);

const routes = new VueRouter({
    base: "/",
    mode: "history",
    scrollBehavior: () => ({ x: 0, y: 0 }),
    routes: [
        {
            path: "/publish/test",
            component: () => import("@/containers/blank"),
            children: [
                ...routerTest
            ]
        },
        {
            path: "/publish",
            component: () => import("@/containers/blank"),
            children: [
                ...routerPublish
            ]
        }
    ]
});

export default routes;