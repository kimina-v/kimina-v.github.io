export default [
    { 
      // datepicker
      path: "datepicker",
      component: () => import("@/pages/publish/test/datepickertest.vue")
  },
    { 
      // datepicker
      path: "barcode",
      component: () => import("@/pages/publish/test/barcodetest.vue")
    },
    {
      // jquery
      path: "jquery",
      component: () => import("@/pages/publish/test/jquerytest.vue")
    }
    ,{
      // 아이핀 인증 팝업 테스트 (권태현추가)
      path: "ipincert",
      component: () => import("@/pages/publish/test/ipincerttest.vue")
    },
    // IPIN인증 call window popup (권태현추가)
    {
      path: "/comm/commIpinCert",
      name: "ipinCert",
      component: () => import("@/containers/popup/CertIpinHtmlPopup")
    },
    {
      // 아이핀 인증 팝업 테스트 (권태현추가)
      path: "creditcert",
      component: () => import("@/pages/publish/test/creditcerttest.vue")
    },
      // 신용카드 인증 팝업 테스트 (권태현추가)
    {
      path: "/comm/commCreditCert",
      name: "creditCert",
      component: () => import("@/containers/popup/CertCreditHtmlPopup"),
    }
  ];

