<template>
  <header class="layout">
    <div class="skip">
      <a href="#content">본문 바로가기</a>
    </div>
    <!-- GNB 영역 -->
    
    <div class="gnb">
        <h1>
          <logo-box></logo-box>
        </h1>
        <!-- PC 전용 -->
        <div class="gnb_btn" v-if="!this.$root.isMobile">
          <div v-if="!$store.state.loginSuccess">
            <a href="javascript:void(0)" @click="loginTry">로그인</a>
            <a href="javascript:void(0)">회원가입</a>
          </div>
          <div v-else>
            <p class="name"><strong class="txt_line0">신세계</strong> 님</p>
          </div>
        </div>
        <!-- //PC 전용 -->

        <button class="all_menu_btn" @click="$commonLib.layerOpen.show($event,'lnb')">
          <span class="btn_bar">전체메뉴 보기</span>
        </button>
      
    </div>
    <!-- //상세타입 gnb -->
    <Lnb />
  </header>
</template>

<script>
import LogoBox  from "@/components/common/LogoBox.vue"
import Lnb  from "@/components/common/Lnb.vue"
export default {
    components: {
      Lnb,
      LogoBox
    },
    props:{
    },
    data : function(){
      return{
        lnbShow : false
      }
    },
  created() {
  },
  mounted() {

  },
  methods: {
    loginTry(){//퍼블 확인 용
      this.$store.state.loginSuccess = true
    }
  }

}
</script>