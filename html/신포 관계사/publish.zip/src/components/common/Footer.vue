<template>
  <footer>
    <div class="footer_box">
      <div class="footer_box_in">
        <!-- Y20210803 수정 Start -->
        <h2 class="logo" v-if="!this.$root.isMobile">
          <img
            src="@/assets/images/common/footer_logo.png"
            alt="SHISEGAE POINT"
          />
        </h2>
        <ul class="terms">
          <li><a href="javascript:void(0)">서비스 이용약관</a></li>
          <li>
            <a href="javascript:void(0)" class="fnt_color"
              >개인정보 처리방침</a><!--b20210825 개인정보 처리방침으로 띄어쓰기수정-->
          </li>
        </ul>
        <div class="info">
          <p class="tit">신세계포인트 고객센터</p>
          <!--고객센터 전화번호 -->
          <button class="tel" v-if="this.$root.isMobile">1899-4349</button>
          <p class="tel" v-else>1899-4349</p>
          <!--//고객센터 전화번호 -->
          <p class="txt0">
            운영시간 <span>:</span> <em>09</em>시 - <em>18</em>시<br />
            점심시간 <span>:</span> <em>12</em>시 - <em>13</em>시<br />
            (주말,공휴일 제외)
          </p>
        </div>
        <div class="txt_cnt">
          <p class="txt">
            <span class="txt0"
              >㈜이마트 서울시 성동구 뚝섬로377(성수동2가)</span
            >
            <span class="txt1">대표자 : 강희석</span>
            <span class="txt2">사업자등록번호 : 206-86-50913</span>
          </p>
          <p class="copyright">COPYRIGHT (c) EMART INC. ALL RIGHTS RESERVED.</p>
        </div>
        <!-- //Y20210803 수정 End -->
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  created() {},
  methods: {},
};
</script>