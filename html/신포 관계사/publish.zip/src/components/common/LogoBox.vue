<template>
  <span class="logo_box">
    <!-- 신세계포인트 로고 Mobile 이미지 -->
    <img class="logo" src="~@/assets/images/common/logo_sinsegaepoint.png" alt="SINSEGAE POINT" v-if="this.$root.isMobile">
    <!-- 신세계포인트 로고 PC 이미지 -->
    <img class="logo" src="~@/assets/images/common/logo_sinsegaepoint.png" alt="SINSEGAE POINT" v-else>

    <span class="ico_x">X</span>
    
    <!-- 관계사 로고 Mobile 이미지 -->
    <img class="group_logo" src="~@/assets/images/common/logo_emart.png" alt="emart logo" v-if="this.$root.isMobile">
    <!-- 관계사 로고 PC 이미지 -->
    <img class="group_logo" src="~@/assets/images/common/logo_emart.png" alt="emart logo" v-else>
  </span>
</template>

<script>
export default {
    components: {
      
    },
    props:{
    },
    
  created() {
  },
  mounted() {

  },
  methods: {
    
  }

}
</script>