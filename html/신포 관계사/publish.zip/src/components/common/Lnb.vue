<template>
  <nav id="lnb" class="lnb">
    <div class="lnb_cnt" :class="[{m_lnb:this.$root.isMobile},{pc_lnb:!this.$root.isMobile}]">
      <div class="lnb_header">
        <!-- 로그인 전 -->
        <div v-if="!$store.state.loginSuccess" class="lnb_login_b">
          <!-- 로그인 버튼 click event 퍼블 화면 확인 용 -->
          <a href="javascript:void(0)" @click="loginTry" class="btn">로그인</a>
          <a href="javascript:void(0)" class="btn">회원가입</a>
        </div>
        <!-- //로그인 전 -->
        <!-- 로그인 후 -->
        <div v-if="$store.state.loginSuccess" class="lnb_login_a">
          <p class="name"><strong class="txt_line0">신세계</strong> 님</p>
          <button class="btn">로그아웃</button>
        </div>
        <!-- //로그인 후 -->
        <button class="lnb_close" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <ul class="lnb_menu">
        <li><a href="javascript:void(0)">회원정보 수정</a></li>
        <li><a href="javascript:void(0)">광고정보 수신관리</a></li>
        <li><a href="javascript:void(0)">비밀번호 변경</a></li>
        <li><a href="javascript:void(0)">회원 탈퇴</a></li>
      </ul>
    </div>
    <div class="lnb_dimmed" @click="$commonLib.layerOpen.hide()"></div>
  </nav>
</template>

<script>

export default {
  components: {
    
  },
  props:{
    lnbShow : Boolean
  },
  created() {
  },
  mounted() {
    
  },
  methods: {
    loginTry(){//퍼블 확인 용
      this.$store.state.loginSuccess = true
    }
  }
}
</script>