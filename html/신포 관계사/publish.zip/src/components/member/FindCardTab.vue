<template>
  <div class="tab_box2">
    <p class="sp_txt1">
      <!--b20210901 문구 수정-->
      보유하신 <span class="fnt_color">신용/체크카드</span>로<br v-if="this.$root.isMobile"> 본인인증이 가능합니다.
    </p>
    <!-- 비번찾기 id 입력 -->
    <!-- Y20210801수정 Start : .form_box 추가, .tit 추가 .input_box에 .pd_b25 클래스 삭제  -->
    <div v-if="idInputShow" class="form_box pd_b25">
      <p class="tit">아이디를 입력해주세요.</p>
      <div class="input_box">
        <label for="id01"><span class="in_box">아이디 입력</span></label>
        <input id="id01" type="text" value="" @input="$commonLib.inputLabelSet($event)">
      </div>
    </div>
    <!-- //Y20210801수정 End -->
    <!-- //비번찾기 id 입력 -->
    <div class="btn_box">
      <!--b20210901 문구 수정--><!-- 웹접근성 수정 title="새창열림"-->
      <button class="btn0 big sdw" title="새창열림">신용/체크카드 인증</button>
    </div>
  </div>
</template>

<script>

export default {
  components: {
    
  },
    props:{
        idInputShow : {
          type:Boolean
        }
    },
  created() {
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>