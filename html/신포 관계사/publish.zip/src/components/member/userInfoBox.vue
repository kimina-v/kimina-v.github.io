<template>
  <div class="user_info_cnt">
      <p class="tit">회원정보</p>
      <div class="user_info">
        <dl>
          <dt>휴대폰 번호</dt>
          <dd>010-9876-5432</dd>
        </dl>
        <dl>
          <dt>이메일</dt>
          <dd>asdf1234@asdf.com</dd>
        </dl>
        <dl>
          <dt>주소</dt>
          <dd>04529<br>도로명: 서울 중구 남대문시장 10길2, 1(회현동1가)<br>지번: 서울 중구 회현동1가 204번지 MESA 1</dd>
        </dl>
      </div>
      <p class="tit">신세계포인트 광고정보 수신동의 <em>동의일자 2021.02.02</em></p>
      <div class="user_info" :class="{item_col:this.$root.isMobile}">
        <dl>
          <dt>동의</dt>
          <dd>이메일</dd>
        </dl>
        <dl>
          <dt>비동의</dt>
          <dd>문자, DM, TM</dd>
        </dl>
      </div>
      <p class="tit">시코르 광고정보 수신동의 <em>동의일자 2021.02.02</em></p>
      <div class="user_info" :class="{item_col:this.$root.isMobile}">
        <dl>
          <dt>동의</dt>
          <dd>이메일</dd>
        </dl>
        <dl>
          <dt>비동의</dt>
          <dd>문자, DM, TM</dd>
        </dl>
      </div>
    </div>
</template>

<script>

export default {
  props:{
      
  },
  data() {
    return {
      
    }
  },
  created() {
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>