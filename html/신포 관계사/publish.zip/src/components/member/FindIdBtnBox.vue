<template>
  <div class="find_pw_btn_box">
    <p class="sp_txt0">
      <strong>아이디가 기억나지 않으시나요?</strong><br>
      본인인증을 통해<br v-if="this.$root.isMobile"> 가입하신 아이디를 확인하실 수 있습니다.
    </p>
    <div class="btn_box">
      <a href="javascript:void(0)" class="btn2 large">아이디 찾기</a>
    </div>
  </div>
</template>

<script>

export default {
  components: {
    
  },
  props:{
    
  },
  data(){
    return {
      
    }
  },
  created() {
  },
  mounted() {

  },
  methods: {
    
  }

}
</script>