<template>
  <div>
    <!-- 휴대폰인증 정보 입력 -->
    <div class="tab_box0">
      <!-- 비번찾기 id 입력 -->
      <div v-if="idInputShow" class="form_box"><!-- 에러 시 error 클래스 추가 -->
        <p class="tit">아이디를 입력해주세요.</p>
        <div class="input_box">
          <input id="id00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
          <label for="id00"><span class="in_box">아이디 입력</span></label>
        </div>
        <!-- validation 문구 -->
        <p class="error_txt">아이디를 입력해주세요.</p>
      </div>
      <!-- //비번찾기 id 입력 -->

      <div class="form_box"><!-- 에러 시 error 클래스 추가 -->
        <p class="tit">이름을 입력해주세요.</p>
        <div class="input_box">
          <input id="name00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
          <label for="name00"><span class="in_box">이름 입력</span></label>
        </div>
        <!-- validation 문구 -->
        <p class="error_txt">이름을 입력해주세요.</p>
      </div>
      <div class="form_box">
        <p class="tit">성별을 선택해주세요.</p>
        <div class="radio_group_box col2">
          <div class="radio_box">
            <input id="radio00" type="radio" name="radioName00" checked="checked">
            <label for="radio00">남자</label>
          </div>
          <div class="radio_box">
            <input id="radio01" type="radio" name="radioName00">
            <label for="radio01">여자</label>
          </div>
        </div>
      </div>
      <div class="form_box">
        <p class="tit">외국인 이신가요?</p>
        <div class="radio_group_box col2">
          <div class="radio_box">
            <input id="radio10" type="radio" name="radioName10" checked="checked">
            <label for="radio10">내국인</label>
          </div>
          <div class="radio_box">
            <input id="radio11" type="radio" name="radioName10">
            <label for="radio11">외국인</label>
          </div>
        </div>
      </div>
      <div class="form_box"><!-- 에러 시 error 클래스 추가 -->
        <p class="tit">생년월일을 입력해주세요.<em>(예: 19990101)</em></p>
        <div class="input_box">
          <input id="birthday00" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
          <label for="birthday00"><span class="in_box">법정생년월일 8자리</span></label>
        </div>
        <!-- validation 문구 -->
        <p class="error_txt">
          생년월일을 입력해주세요.
          <!-- 생년월일을 정확히 입력해주세요. -->
        </p>
      </div>
      <div class="form_box"><!-- 에러 시 error 클래스 추가 -->
        <p class="tit">본인명의의 휴대전화번호를 입력해주세요.</p>
        <div class="phone_select_box">
          <div class="select_box">
            <select id="" title="통신사 선택">
              <option val="">SKT</option>
            </select>
          </div>
          <div class="input_box">
            <input id="phone00" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
            <label for="phone00"><span class="in_box">-없이 휴대폰 번호 입력</span></label>
          </div>
        </div>
        <!-- validation 문구 -->
        <p class="error_txt">휴대전화번호를 입력해주세요.</p>
      </div>
    </div>
    <!-- //휴대폰인증 정보 입력 -->
    <!-- 휴대폰 인증 약관 -->
    <div class="terms_agree_box">
      <div class="agree_form_box">
        <h3 class="tit">휴대전화 인증 약관</h3>
        <div class="agree_all_chk">
          <div class="chk_box">
            <input id="agreeAllChk" type="checkbox">
            <label for="agreeAllChk"><span class="in_box">모든 약관에 동의합니다.</span></label>
          </div>
        </div>
        <ul class="agree_list">
          <li class="agree_form">
            <div class="chk_box">
              <input id="agree00" type="checkbox">
              <label for="agree00"><span class="in_box">휴대전화 인증 서비스 이용약관 (필수)</span></label><!--b20210826문구수정-->
            </div>
            <button class="agree_show" @click="$commonLib.layerOpen.show($event,'mobileCertAgreePopup'),focusIn()">><span>내용보기</span></button>
          </li>
          <li class="agree_form">
            <div class="chk_box">
              <input id="agree01" type="checkbox">
              <label for="agree01"><span class="in_box">고유식별정보 처리 동의 (필수)</span></label>
            </div>
            <button class="agree_show"><span>내용보기</span></button>
          </li>
          <li class="agree_form">
            <div class="chk_box">
              <input id="agree02" type="checkbox">
              <label for="agree02"><span class="in_box">통신사 이용약관 동의 (필수)</span></label>
            </div>
            <button class="agree_show"><span>내용보기</span></button>
          </li>
          <li class="agree_form">
            <div class="chk_box">
              <input id="agree03" type="checkbox">
              <label for="agree03"><span class="in_box">개인정보 수집/이용동의 (필수)</span></label>
            </div>
            <button class="agree_show"><span>내용보기</span></button>
          </li>
          <li class="agree_form">
            <div class="chk_box">
              <input id="agree04" type="checkbox">
              <label for="agree04"><span class="in_box">제 3자 정보제공동의 (필수)</span></label>
            </div>
            <button class="agree_show"><span>내용보기</span></button>
          </li>
        </ul>
      </div>
    </div>
    <!-- //휴대폰 인증 약관 -->
    <!-- 인증번호 -->
    <div class="tab_box1">
      <div class="btn_box">
        <!--b20210917 $commonLib.scrollUpTo('name00')추가수정-->
        <button class="btn0 big sdw" @click="validTimeShow=true,$commonLib.scrollUpTo('name00')">인증번호 요청</button>
      </div>
      <div class="form_box">
        <p class="tit">인증번호</p>
        <div class="input_btn_box">
          <div class="input_box">
            <input id="certification00" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
            <label for="certification00"><span class="in_box">인증번호 입력</span></label>
          </div>
          <div class="btn_box">
            <button class="btn2">확인</button>
          </div>
        </div>
        <div v-if="validTimeShow" class="valid_time_box">
          <p class="txt">유효시간 03분 00초</p>
          <button class="btn_line0">재전송</button>
        </div>
      </div>
    </div>
    <!-- //인증번호 -->
  <iframe-test-popup></iframe-test-popup>
  </div>
</template>

<script>
import iframeTestPopup from '@/containers/popup/iframeTestPopup'

export default {
  components: {
    iframeTestPopup
  },
    props:{
        idInputShow :{//퍼블 확인 용
          type : Boolean
        }
    },
  data : function(){
    return{
      validTimeShow : false//퍼블 확인 용
    }
  },
  created() {

  },
  mounted() {
    
  },
  methods: {
      focusIn(){
          const el = $(".iframe_layer iframe")
          // const el = document.querySelector('.iframe_layer #agreeTerms')
          
          console.log(el);
          el.attr('tabindex', 0)

          
      }
  }

}
</script>