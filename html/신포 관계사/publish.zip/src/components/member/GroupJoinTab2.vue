<template>  
  <div class="group_join_box">
    <p class="top_tit">
      <strong class="txt_line0">신세계</strong>님,<br>
      통합 ID로 더 다양한 서비스를 
      이용할 수 있습니다!
    </p>
    <!-- Mobile Tab -->
    <div class="group_join_tab">
      <div class="group_join_accodian" v-if="this.$root.isMobile">
        <!-- 이마트 -->
        <div class="group_join_list gray_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#ffd040">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[0].tabOpen}" v-if="!groupTab[0].complete" @click="groupAccodian(0)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_emart.png" alt="logo">
              </span>
              <span class="name"><span>이마트</span></span>
              <span class="arr">
                <span v-if="groupTab[0].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[0].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_emart.png" alt="이마트 logo">
              </span>
              <span class="name"><span>이마트</span></span>
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[0].complete" v-show="groupTab[0].tabOpen">
            <div class="txt_cnt">
              <p class="txt1">㈜이마트 귀중</p><!-- b20210827문구 및 태그수정 -->
            </div>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox01" type="checkbox">
                  <label for="checkbox01"><span class="in_box">[필수] 이마트 필수약관</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[0].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //이마트 -->
        <!-- 신세계백화점 -->
        <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#999999">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[1].tabOpen}" v-if="!groupTab[1].complete" @click="groupAccodian(1)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="logo">
              </span>
              <span class="name"><span>신세계백화점</span></span>
              <span class="arr">
                <span v-if="groupTab[1].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[1].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="신세계백화점 logo">
              </span>
              <span class="name"><span>신세계백화점</span></span>
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[1].complete" v-show="groupTab[1].tabOpen">
            <div class="txt_cnt">
              <p class="txt1">㈜신세계백화점 귀중</p><!-- b20210827문구 및 태그수정 -->
            </div>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox02" type="checkbox">
                  <label for="checkbox02"><span class="in_box">[필수] 신세계백화점 필수약관</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[1].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //신세계백화점 -->
        <!-- 신세계아울렛 -->
        <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#a1005b">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[2].tabOpen}" v-if="!groupTab[2].complete" @click="groupAccodian(2)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_premiumoutlets.png" alt="신세계아울렛 logo"><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
              </span>  
              <span class="name"><span>신세계아울렛</span></span><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
              <span class="arr">
                <span v-if="groupTab[2].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[2].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_premiumoutlets.png" alt="신세계아울렛 logo"><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
              </span>  
              <span class="name"><span>신세계아울렛</span></span><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[2].complete" v-show="groupTab[2].tabOpen">
            <div class="txt_cnt">
              <!--b20210906문구수정 프리미엄삭제-->
              <p class="txt0">신세계아울렛 이용약관 및 개인정보 수집·이용 동의 내용을 확인하였으며, 아래 내용에 동의합니다.</p><!--b20210827 띄어쓰기수정 ,20210901 문구수정-->
              <p class="txt1">㈜신세계사이먼 귀중</p><!-- Y20210801 문구수정 b20210827 문구수정 -->
            </div>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox031" type="checkbox">
                  <label for="checkbox031"><span class="in_box">[필수] 신세계아울렛 필수약관</span></label><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox032" type="checkbox">
                  <label for="checkbox032"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox033" type="checkbox">
                  <label for="checkbox033"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 문구 수정-->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt chk_bg_type2">
              <p class="add_info_agree_tit">신세계아울렛 광고정보 수신동의</p><!--b20210825 신세계아울렛으로 띄어쓰기 수정,b20210902 문구수정 -->
              <div class="chk_box">
                <input id="receveAll" type="checkbox">
                <label for="receveAll">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve00" type="checkbox">
                  <label for="receve00">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve01" type="checkbox">
                  <label for="receve01">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve02" type="checkbox">
                  <label for="receve02">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve03" type="checkbox">
                  <label for="receve03">TM</label>
                </div>
              </div>
            </div>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[2].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //신세계아울렛-->
        <!-- 시코르 -->
        <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#000000">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[3].tabOpen}" v-if="!groupTab[3].complete" @click="groupAccodian(3)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_chicor.png" alt="logo">
              </span>
              <span class="name"><span>시코르</span></span>
              <span class="arr">
                <span v-if="groupTab[3].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[3].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_chicor.png" alt="logo">
              </span>
              <span class="name"><span>시코르</span></span>
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[3].complete" v-show="groupTab[3].tabOpen">
            <div class="txt_cnt">
              <p class="txt0">시코르 이용약관 및 개인정보 수집·이용 동의 내용을 확인하였으며, 아래 내용에 동의합니다.</p><!--b20210827 띄어쓰기수정 -->
              <p class="txt1">㈜신세계 귀중</p><!-- Y20210801 문구 수정 b20210827 문구수정-->
            </div>
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox041" type="checkbox">
                  <label for="checkbox041"><span class="in_box">[필수] 시코르 필수약관</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox042" type="checkbox">
                  <label for="checkbox042"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox043" type="checkbox">
                  <label for="checkbox043"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 문구 수정-->
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="add_info_agree_cnt chk_bg_type2">
              <p class="add_info_agree_tit">시코르 광고정보 수신동의</p><!--b20210902 문구수정 -->
              <div class="chk_box">
                <input id="receveAll2" type="checkbox">
                <label for="receveAll2">전체동의</label>
              </div>
              <div class="chk_group_box col_f">
                <div class="chk_box">
                  <input id="receve10" type="checkbox">
                  <label for="receve10">이메일</label>
                </div>
                <div class="chk_box">
                  <input id="receve11" type="checkbox">
                  <label for="receve11">문자</label>
                </div>
                <div class="chk_box">
                  <input id="receve12" type="checkbox">
                  <label for="receve12">DM</label>
                </div>
                <div class="chk_box">
                  <input id="receve13" type="checkbox">
                  <label for="receve13">TM</label>
                </div>
              </div>
            </div>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[3].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //시코르 -->

        <!-- 슬라이드 테스트용 -->
        <!-- 이마트 -->
        <div class="group_join_list gray_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#ffd040">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[4].tabOpen}" v-if="!groupTab[4].complete" @click="groupAccodian(4)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_emart.png" alt="logo">
              </span>
              <span class="name"><span>이마트</span></span>
              <span class="arr">
                <span v-if="groupTab[4].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[4].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_emart.png" alt="이마트 logo">
              </span>
              <span class="name"><span>이마트</span></span>
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[4].complete" v-show="groupTab[4].tabOpen">
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox01" type="checkbox">
                  <label for="checkbox01"><span class="in_box">[필수] 이마트 필수약관</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[4].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //이마트 -->
        <!-- 신세계백화점 -->
        <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
          <div class="tab" style="background-color:#999999">
            <!-- 가입 전 (탭 버튼) -->
            <button class="link_box" :class="{on:groupTab[5].tabOpen}" v-if="!groupTab[5].complete" @click="groupAccodian(5)">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="logo">
              </span>
              <span class="name"><span>신세계백화점</span></span>
              <span class="arr">
                <span v-if="groupTab[5].tabOpen">약관 항목 닫기</span>
                <span v-else>약관 항목 보기</span>
              </span>
            </button>
            <!-- 가입 후 (링크) -->
            <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[5].complete">
              <span class="logo_img">
                <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="신세계백화점 logo">
              </span>
              <span class="name"><span>신세계백화점</span></span>
              <span class="mark">가입완료</span>
              <span class="txt_arr">바로가기</span>
            </a>
          </div>
          <!-- 가입 전 (약관) -->
          <div class="tab_cnt" v-if="!groupTab[5].complete" v-show="groupTab[5].tabOpen">
            <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
              <li class="agree_form">
                <div class="chk_box">
                  <input id="checkbox02" type="checkbox">
                  <label for="checkbox02"><span class="in_box">[필수] 신세계백화점 필수약관</span></label>
                </div>
                <button class="agree_show"><span>내용보기</span></button>
              </li>
            </ul>
            <div class="btn_box">
              <button class="btn2" @click="groupTab[5].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
            </div>  
          </div>
        </div>
        <!-- //신세계백화점 -->
        <!-- //슬라이드 테스트용 -->
      </div> 
    </div>
    <!-- //Mobile Tab -->

    <!-- PC Tab -->
    <div class="group_join_tab">
      <!-- 탭 슬라이드 -->
      <div class="group_join_swipe" v-if="!this.$root.isMobile">
        <div class="swipe" v-swiper:groupSwiper="groupSwiperOption" @ready="groupSlideGo">
          <div class="swiper-wrapper">
            <!--
              4개단위 슬라이드 / .swiper-slide 4개 단위로 생성 해야함
              예) 관계사 5개일 경우 빈 swiper-slide 3개 생성
            -->
            <!-- 이마트 -->
            <div class="swiper-slide">
              <div class="group_join_list gray_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#ffd040">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[0].tabOpen}" v-if="!groupTab[0].complete" @click="groupAccodian(0)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_emart.png" alt="logo">
                    </span>
                    <span class="name"><span>이마트</span></span>
                    <span class="arr">
                      <span v-if="groupTab[0].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[0].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_emart.png" alt="이마트 logo">
                    </span>
                    <span class="name"><span>이마트</span></span>
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[0].complete" v-show="groupTab[0].tabOpen">
                  <div class="txt_cnt">
                    <p class="txt1">㈜이마트 귀중</p><!-- b20210827문구 및 태그수정 -->
                  </div>
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox01" type="checkbox">
                        <label for="checkbox01"><span class="in_box">[필수] 이마트 필수약관</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[0].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //이마트 -->
            <!-- 신세계백화점 -->
            <div class="swiper-slide">
              <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#999999">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[1].tabOpen}" v-if="!groupTab[1].complete" @click="groupAccodian(1)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="logo">
                    </span>
                    <span class="name"><span>신세계백화점</span></span>
                    <span class="arr">
                      <span v-if="groupTab[1].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[1].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="신세계백화점 logo">
                    </span>
                    <span class="name"><span>신세계백화점</span></span>
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[1].complete" v-show="groupTab[1].tabOpen">
                  <div class="txt_cnt">
                    <p class="txt1">㈜신세계백화점 귀중</p><!-- b20210827문구 및 태그수정 -->
                  </div>
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox02" type="checkbox">
                        <label for="checkbox02"><span class="in_box">[필수] 신세계백화점 필수약관</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[1].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //신세계백화점 -->
            <!-- 신세계아울렛아울렛 -->
            <div class="swiper-slide">
              <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#a1005b">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[2].tabOpen}" v-if="!groupTab[2].complete" @click="groupAccodian(2)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_premiumoutlets.png" alt="신세계아울렛 logo"><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                    </span>  
                    <span class="name"><span>신세계아울렛</span></span><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                    <span class="arr">
                      <span v-if="groupTab[2].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[2].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_premiumoutlets.png" alt="신세계아울렛 logo"><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                    </span>  
                    <span class="name"><span>신세계아울렛</span></span><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[2].complete" v-show="groupTab[2].tabOpen">
                  <div class="txt_cnt">
                    <!--b20210906문구수정 프리미엄삭제-->
                    <p class="txt0">신세계아울렛 이용약관 및 개인정보 수집·이용 동의 내용을 확인하였으며, 아래 내용에 동의합니다.</p><!--b20210827 띄어쓰기수정,20210901 문구수정 -->
                    <p class="txt1">㈜신세계사이먼 귀중</p><!-- Y20210801 문구 수정 b20210827문구수정 -->
                  </div>
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox031" type="checkbox">
                        <label for="checkbox031"><span class="in_box">[필수] 신세계아울렛 필수약관</span></label><!--b20210825 신세계아울렛으로 띄어쓰기 수정-->
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox032" type="checkbox">
                        <label for="checkbox032"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox033" type="checkbox">
                        <label for="checkbox033"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 문구 띄어쓰기 수정-->
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="add_info_agree_cnt chk_bg_type2">
                    <p class="add_info_agree_tit">신세계아울렛 광고정보 수신동의</p><!--b20210825 신세계아울렛으로 띄어쓰기 수정,b20210902 문구수정 -->
                    <div class="chk_box">
                      <input id="receveAll" type="checkbox">
                      <label for="receveAll">전체동의</label>
                    </div>
                    <div class="chk_group_box col_f">
                      <div class="chk_box">
                        <input id="receve00" type="checkbox">
                        <label for="receve00">이메일</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve01" type="checkbox">
                        <label for="receve01">문자</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve02" type="checkbox">
                        <label for="receve02">DM</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve03" type="checkbox">
                        <label for="receve03">TM</label>
                      </div>
                    </div>
                  </div>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[2].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //신세계아울렛아울렛 -->
            <!-- 시코르 -->
            <div class="swiper-slide">
              <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#000000">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[3].tabOpen}" v-if="!groupTab[3].complete" @click="groupAccodian(3)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_chicor.png" alt="logo">
                    </span>
                    <span class="name"><span>시코르</span></span>
                    <span class="arr">
                      <span v-if="groupTab[3].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[3].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_chicor.png" alt="logo">
                    </span>
                    <span class="name"><span>시코르</span></span>
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[3].complete" v-show="groupTab[3].tabOpen">
                  <div class="txt_cnt">
                    <p class="txt0">시코르 이용약관 및 개인정보 수집·이용 동의 내용을 확인하였으며, 아래 내용에 동의합니다.</p><!--b20210827 띄어쓰기수정 -->
                    <p class="txt1">㈜신세계 귀중</p><!-- Y20210801 문구 수정 b20210827문구수정 ,b20210901 문구수정-->
                  </div>
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox041" type="checkbox">
                        <label for="checkbox041"><span class="in_box">[필수] 시코르 필수약관</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox042" type="checkbox">
                        <label for="checkbox042"><span class="in_box">[필수] 개인정보 수집 및 이용동의</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox043" type="checkbox">
                        <label for="checkbox043"><span class="in_box">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</span></label><!--b20210827 문구 수정-->
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="add_info_agree_cnt chk_bg_type2">
                    <p class="add_info_agree_tit">시코르 광고정보 수신동의</p><!--b20210902 문구수정 -->
                    <div class="chk_box">
                      <input id="receveAll2" type="checkbox">
                      <label for="receveAll2">전체동의</label>
                    </div>
                    <div class="chk_group_box col_f">
                      <div class="chk_box">
                        <input id="receve10" type="checkbox">
                        <label for="receve10">이메일</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve11" type="checkbox">
                        <label for="receve11">문자</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve12" type="checkbox">
                        <label for="receve12">DM</label>
                      </div>
                      <div class="chk_box">
                        <input id="receve13" type="checkbox">
                        <label for="receve13">TM</label>
                      </div>
                    </div>
                  </div>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[3].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //시코르 -->

            <!-- 슬라이드 테스트용 -->
            <!-- 이마트 -->
            <div class="swiper-slide">
              <div class="group_join_list gray_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#ffd040">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[4].tabOpen}" v-if="!groupTab[4].complete" @click="groupAccodian(4)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_emart.png" alt="logo">
                    </span>
                    <span class="name"><span>이마트</span></span>
                    <span class="arr">
                      <span v-if="groupTab[4].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[4].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_emart.png" alt="이마트 logo">
                    </span>
                    <span class="name"><span>이마트</span></span>
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[4].complete" v-show="groupTab[4].tabOpen">
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox01" type="checkbox">
                        <label for="checkbox01"><span class="in_box">[필수] 이마트 필수약관</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[4].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //이마트 -->
            <!-- 신세계백화점 -->
            <div class="swiper-slide">
              <div class="group_join_list white_type"><!--.group_join_list 안 소스 PC/Mobile 동일-->
                <div class="tab" style="background-color:#999999">
                  <!-- 가입 전 (탭 버튼) -->
                  <button class="link_box" :class="{on:groupTab[5].tabOpen}" v-if="!groupTab[5].complete" @click="groupAccodian(5)">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="logo">
                    </span>
                    <span class="name"><span>신세계백화점</span></span>
                    <span class="arr">
                      <span v-if="groupTab[5].tabOpen">약관 항목 닫기</span>
                      <span v-else>약관 항목 보기</span>
                    </span>
                  </button>
                  <!-- 가입 후 (링크) -->
                  <a href="javascript:void(0)" target="_blank" title="새창 열림" class="link_box" v-if="groupTab[5].complete">
                    <span class="logo_img">
                      <img src="~@/assets/images/dummy/logo_shinsegae.png" alt="신세계백화점 logo">
                    </span>
                    <span class="name"><span>신세계백화점</span></span>
                    <span class="mark">가입완료</span>
                    <span class="txt_arr">바로가기</span>
                  </a>
                </div>
                <!-- 가입 전 (약관) -->
                <div class="tab_cnt" v-if="!groupTab[5].complete" v-show="groupTab[5].tabOpen">
                  <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                    <li class="agree_form">
                      <div class="chk_box">
                        <input id="checkbox02" type="checkbox">
                        <label for="checkbox02"><span class="in_box">[필수] 신세계백화점 필수약관</span></label>
                      </div>
                      <button class="agree_show"><span>내용보기</span></button>
                    </li>
                  </ul>
                  <div class="btn_box">
                    <button class="btn2" @click="groupTab[5].complete=true">동의하기</button><!-- click이벤트 퍼블 화면 확인 용 -->
                  </div>  
                </div>
              </div>
            </div>
            <!-- //신세계백화점 -->
            <div class="swiper-slide"></div><!-- 빈 공간 처리용 -->
            <div class="swiper-slide"></div><!-- 빈 공간 처리용 -->
            <!-- //슬라이드 테스트용 -->
          </div>
        </div>
        <button class="swiper-button-prev">이전</button>
        <button class="swiper-button-next">다음</button>
      </div>
      <!-- //탭 슬라이드 -->
    </div>
    <!-- //PC Tab -->
  </div>
</template>

<script>

export default {
  props:{
      
  },
  data() {
    return {
      groupTabIdx : 0,
      groupTab : [
        {
          tabOpen : true,
          complete : false//퍼블 화면 확인 용
        },
        {
          tabOpen : false,
          complete : false//퍼블 화면 확인 용
        },
        {
          tabOpen : false,
          complete : false//퍼블 화면 확인 용
        },
        {
          tabOpen : false,
          complete : false//퍼블 화면 확인 용
        },
        {
          tabOpen : false,
          complete : false//퍼블 화면 확인 용
        },
        {
          tabOpen : false,
          complete : false//퍼블 화면 확인 용
        }
      ],
      groupSwiperOption : {
        autoHeight:true,
        /*grabCursor:true,*/
        slidesPerView: 4,
        slidesPerGroup : 4,
        spaceBetween: 0,
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }
      }
    }
  },
  created() {
    
  },
  mounted() {
    
  },
  methods: {
    groupAccodian:function(idx){
      this.groupTabIdx = idx;
      if(this.groupTab[idx].tabOpen){
        this.groupTab[idx].tabOpen = false;
      }else{
        for(var i=0 ; i < this.groupTab.length ; i++){
          if(i==idx) this.groupTab[i].tabOpen = true;
          else this.groupTab[i].tabOpen = false;
        }
      }
    },
    groupSlideGo(){
      this.groupSwiper.slideTo(this.groupTabIdx, 0, false)
    }
  }

}
</script>