<template>
  <div class="auth_tab" :class="[{tab0:authTabIdx === 0},{tab1:authTabIdx === 1},{tab2:authTabIdx === 2}]">
    <!-- 탭메뉴 -->
    <ul class="auth_tab_menu">
      <li :class="{on: authTabIdx === 0}">
        <a href="javascript:void(0)" class="phone" @click="authTabIdx = 0">휴대폰인증<span class="blind" v-if="authTabIdx == 0">휴대폰인증 선택됨</span></a><!--접근성관련 수정-->
      </li>
      <li :class="{on: authTabIdx === 1}">
        <a href="javascript:void(0)" class="card" @click="authTabIdx = 1">카드인증<span class="blind" v-if="authTabIdx == 1">카드인증 선택됨</span></a><!--접근성관련 수정-->
      </li>
      <li :class="{on: authTabIdx === 2}">
        <a href="javascript:void(0)" class="ipin" @click="authTabIdx = 2">아이핀인증<span class="blind" v-if="authTabIdx == 2">아이핀인증 선택됨</span></a><!--접근성관련 수정-->
      </li>
    </ul>
    <!-- 탭 컨텐츠 -->
    <div class="auth_tab_content">
      <div v-show="authTabIdx == 0" class="tab_cnt">
        <find-phone-tab :id-input-show="idInputShow" />
      </div>
      <div v-show="authTabIdx == 1" class="tab_cnt">
        <find-card-tab :id-input-show="idInputShow" />
      </div>
      <div v-show="authTabIdx == 2" class="tab_cnt">
        <find-ipin-tab :id-input-show="idInputShow" />
      </div>
    </div>
  </div>
</template>

<script>
import FindPhoneTab  from "@/components/member/FindPhoneTab.vue"
import FindCardTab  from "@/components/member/FindCardTab.vue"
import FindIpinTab  from "@/components/member/FindIpinTab.vue"

export default {
  components: {
    FindPhoneTab,
    FindCardTab,
    FindIpinTab
  },
    props:{
        idInputShow :{//화면 확인 용
          type : Boolean
        }
    },
  data(){
    return {
      authTabIdx : 0
    }
  },
  created() {
  },
  mounted() {

  },
  methods: {
    
  }

}
</script>