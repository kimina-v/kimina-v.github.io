<template>
  <div class="find_pw_btn_box">
    <p class="sp_txt0">
      <!--b20210901 문구 수정-->
      <strong>비밀번호가 기억나지 않으시나요?</strong><br>
      본인인증 후 비밀번호를 변경하실 수 있습니다.
    </p>
    <div class="btn_box">
      <a href="javascript:void(0)" class="btn2 large">비밀번호 찾기</a>
    </div>
  </div>
</template>

<script>

export default {
  components: {
    
  },
  props:{
    
  },
  data(){
    return {
      
    }
  },
  created() {
  },
  mounted() {

  },
  methods: {
    
  }

}
</script>