<template>
  <div class="login_input_area">
    <div class="input_box">
      <label for="id00"><span class="in_box">아이디</span></label>
      <input id="id00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
    </div>
    <div class="input_box">
      <label for="pw00"><span class="in_box">비밀번호<!--<em class="wp">(숫자,영문,특수문자 조합 8~20자리)</em>--></span></label><!-- Y20210801 문구수정 -->
      <input id="pw00" type="password" value="" @input="$commonLib.inputLabelSet($event)">
    </div>
    <!-- 캡챠  -->
    <div v-if="captchaShow"><!-- captchaShow : 퍼블 확인 용 -->
      <div class="captcha_box">
        <img v-if="this.$root.isMobile" src="~@/assets/images/dummy/captcha_img.png" alt=""><!--더미 이미지-->
        <img v-else src="~@/assets/images/dummy/captcha_img_pc.png" alt=""><!--더미 이미지-->
        <div class="btn_box">
          <button class="btn1 small">새로고침</button>
          <button class="btn1 small">음성듣기</button>
        </div>
      </div>
      <div class="input_box">
        <label for="captcha00"><span class="in_box">보안문자 입력</span></label>
        <input id="captcha00" type="text" value="" @input="$commonLib.inputLabelSet($event)">
      </div>
    </div>
    <!-- //캡챠  -->
    <div v-if="loginSaveAuto" class="chk_group_box"><!-- loginSaveAuto 퍼블 확인용 -->
      <div class="chk_box">
        <input id="checkbox01" type="checkbox">
        <label for="checkbox01">아이디 저장</label>
      </div>
    </div>

    <div class="btn_box space0">
      <a href="javascript:void(0)" class="btn0 big sdw">로그인</a>
    </div>

    <ul class="btn_list_box">
      <li><a href="javascript:void(0)" class="btn">아이디 찾기</a></li>
      <li><a href="javascript:void(0)" class="btn">비밀번호 찾기</a></li>
      <li><a href="javascript:void(0)" class="btn">회원가입</a></li>
    </ul>
  </div>
</template>

<script>

export default {
  props:{
      captchaShow : {
        type : Boolean
      },
      loginSaveAuto : {
        type : Boolean
      }
  },
  data() {
    return {
      
    }
  },
  created() {
  },
  mounted() {
    
  },
  methods: {
    
  }

}
</script>