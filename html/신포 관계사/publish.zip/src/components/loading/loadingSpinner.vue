<template>
   <transition name="loading-box">
    <div class="loading_box">
      <div class="loading_img">
      </div>
    </div>
  </transition>
</template>

<script>
export default {
    mounted() {
        this.loadingTest()
    },
    methods: {
        loadingTest() {
            setTimeout(()=>{
                this.$store.state.loading=false
            },3000)
        }
    },
}
</script>

<style>

</style>