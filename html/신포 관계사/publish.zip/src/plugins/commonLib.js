import store from '@/store'
import commonLib from '@/plugins/commonLib'

export default {
    inputLabelSet: function (ta) {
        var _leng = ta.length;
        if (_leng == 0) return false;
        var _el;
        if (_leng > 0) {
            _el  = ta
        } else if (_leng == 'undefined' || _leng == null || _leng == '') {
            _el = $(ta.currentTarget);
        }
        var _inputBox = _el.closest('.input_box');
        var _input = _inputBox.find('input');
        var _label = _inputBox.find('label');
        var _val = _input.val();
        if (_val.length > 0) _label.addClass('hide');
        else _label.removeClass('hide');
    },
    focusTrap: function (ta) {
        $(document).on({
            "keydown" : function(event){
                var keycode = event.keyCode || event.which;
                var currEl = event.target || event.srcElement;
                var shiftKey = event.shiftKey;
                var firstEl = ta.find("a, button, input, div[tabindex='0'],iframe[tabindex='0'] a").first()[0];
                var lastEl = ta.find("a, button, input, div[tabindex='0'],iframe[tabindex='0']").last()[0];
  
                switch(keycode){
                    case 9 : 
                        if(currEl === lastEl && !shiftKey){
                            event.preventDefault();
                            firstEl.focus();
                        }
  
                        if(currEl === firstEl && shiftKey){
                            event.preventDefault();
                            lastEl.focus();
                        }
                    break;
                    default:
                    break;
                }
            }
        });
    },
    bodyScroll: {
        hide: function () {
            $('body').addClass('scroll_hidden');
        },
        show: function () {
            $('body').removeClass('scroll_hidden');
         }
    },
    layerFocus: {
        in: function (el) {
            el.attr('tabindex', 0).focus();
        },
        out: function (el) {
            el.removeAttr('tabindex');
        }
    },
    layerOpen: {
        show: function (ta, id) {
            store.state.layerInfo.count++;//layer on 개수 체크용 count
            var _count = store.state.layerInfo.count - 1;
            var _el, _layer;
            var _id = id;
            if (typeof (ta) == 'string') {
                _el = $('#' + ta);
            } else {
                if (ta == null || ta == 'undefined' || ta == '') {
                    _el = $('.wrap');
                    _el.attr('tabindex', 0);
                } else {
                    _el = $(ta.currentTarget);
                }
            }
            _layer = $('#' + _id);

            if (_count == 0) commonLib.bodyScroll.hide();//body 스크롤 숨김
            if (_count > 0) _layer.css({ zIndex: 500 + _count });//팝업 중첩으로 열릴 시 z-index값 세팅
            if (_id == 'lnb') {//lnb 슬라이드일경우
                _layer.addClass('on');
                setTimeout(function () {_layer.addClass('slide') }, 1);
            } else {//그 외 팝업
                _layer.addClass('on');//레이어 열기
            }
            commonLib.layerFocus.in(_layer);//레이어 포커스
            commonLib.focusTrap(_layer);//레이어 포커스 이탈 방지
            
            store.state.layerInfo.lastFocus[_count] = _el;//레이어 오픈 전 마지막 엘리먼트 담기
            store.state.layerInfo.layerId[_count] = _id;//아이디 담기
            //console.log(store.state.layerInfo);
        },
        hide: function (focusEl) {
            //console.log(focusEl);
            store.state.layerInfo.count--;//layer on 개수 체크용 count
            var _count = store.state.layerInfo.count;
            var _id = store.state.layerInfo.layerId[_count];
            var _layer = $('#' + _id);
        
            if (_count == 0) commonLib.bodyScroll.show();//body 스크롤 보여짐
            if (_id == 'lnb') {//lnb 슬라이드 일 경우
                _layer.removeClass('slide');
                setTimeout(function () {_layer.removeClass('on') }, 200);//200 > css transiton 속도
            } else {//그 외 팝업
                _layer.removeClass('on');//레이어 닫힘    
            }
        
            if (_count > 0) _layer.removeAttr('style');//중첩 레이어 z-index 세팅값 삭제
            commonLib.layerFocus.out(_layer);//레이어 포커스 tabindex 속성 삭제
            if (focusEl == 'undefined' || focusEl == null || focusEl == '') {
                store.state.layerInfo.lastFocus[_count].focus();//레이어 오픈 전 마지막 엘리먼트 포커스
            } else {
                $('#'+ focusEl).focus();//포커스 대상 지정 했을 경우
            }
            if (store.state.layerInfo.lastFocus[_count].hasClass('wrap')) store.state.layerInfo.lastFocus[_count].removeAttr('tabindex');//마지막 엘리먼트 포커스가 .wrap일 경우 tabindex 0값 삭제
        
            store.state.layerInfo.lastFocus.splice(_count,1);//배열에서 닫힌 레이어 마지막 포커스 엘리먼트 삭제
            store.state.layerInfo.layerId.splice(_count,1);//배열에서 닫힌 레이어 id 삭제
            //console.log(store.state.layerInfo);
        },
        reset: function () {
            if (store.state.layerInfo.layerId.length > 0) {
                for (let i = 0; i < store.state.layerInfo.layerId.length; i++) {
                    let _layer = $('#' + store.state.layerInfo.layerId[i]);
                    if(_layer.length) _layer.removeClass('on').removeAttr('style');
                }
            }
            store.state.layerInfo.count = 0;
            store.state.layerInfo.lastFocus = [];
            store.state.layerInfo.layerId = [];
            commonLib.bodyScroll.show();
        },
    },
    scrollUpTo(id) {//b20210917 추가
        if (store.state.browser == 'IE') {
            const inputEl = document.querySelector(`#${id}`)
            const elH = inputEl.getBoundingClientRect().top
            window.scrollTo(0, elH)
        }
    }
}