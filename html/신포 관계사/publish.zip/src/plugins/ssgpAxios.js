import axios from 'axios'

axios.defaults.timeout = 300 *1000;

// 20201125 ie 에서 캐시에서 읽어 오는 케이스 막기 위해 추가함 
axios.defaults.headers['Pragma'] = 'no-cache';

axios.interceptors.request.use(config => {
	config.headers['x-lang-cd'] = "ko-KR";
	config.headers['x-device-id'] = "SVCWEB";
    //TODO : 변경
	if(true) {
		// 로컬 개발용 설정 값
		config.headers['x-partner-id'] = "C0000003";
		config.headers['x-api-key'] = "5JQxejr5amtGTgAJOpp9OizSG-388LQOk2zdZyBU0Kc";
		config.headers['x-service-id'] = "APPLICATION";
	}

  if (false) {
		config.headers['x-login-id'] = "";//store.state.loginUser.loginId;
		config.headers['x-mber-no'] = "";//store.state.loginUser.mberNo;	
	} 
  return config;
}, error => {
	//foUtils.$log(error)
	if (error.status === 403) {
		// alert('로그인이 필요합니다.')
		mainThis.$router.push('/')
	} else {
		return Promise.reject(error);
	}
});


export default axios;