<template>
  <div id="app" :class="[{ie_browser:$store.state.browser==='IE'},{ios:$store.state.agent==='iOS'},{android:$store.state.agent==='ANDROID'}]"><!-- 20210726 : 브라우저, 모바일 agent 클래스 추가 -->
    <router-view/>
  </div>
</template>

<script>

</script>
<style src="@/assets/css/common.css"></style>

