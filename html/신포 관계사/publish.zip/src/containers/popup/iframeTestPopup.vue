<template>
  <div id="mobileCertAgreePopup" class="layer_popup">
    <!-- 공통 약관 -->
    <div class="layer iframe_layer">
      <div class="pop_header">
        <h2 class="tit">휴대전화 인증 서비스 이용약관</h2><!--b20210826문구수정-->
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <iframe width="100%" height="100%" title="agreeTerms" id="agreeTerms" src="https://safe.ok-name.co.kr/eterms/kcb_agrmt_hs_tos.jsp"></iframe>
      </div>
    </div>


    <div>
    </div>
    <div class="dimed"></div>
  </div>	
</template>

<script>


export default {
	components: {
	},
	data() {
		return {

		};
	},
  props: {
    // agmtType: {
    //   type: String
    // }
  },
  mounted(){
    
  },
  methods:{
     
  }
};
</script>

<style>

</style>
