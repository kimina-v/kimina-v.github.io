<template>
  <div id="findPostalCodeNonPopup" class="layer_popup find_postal_code_popup">
    <div class="layer" :class="{result:resultsContents>=0}"><!-- 검색 후 result 클래스 추가 -->
      <div class="pop_header">
        <h2 class="tit">우편번호 찾기</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <!-- 상단 검색영역 고정 -->
      <div class="address_pop_top">
        <div class="input_box" :class="{size2:this.$root.isMobile}">
          <input id="id00" type="text" vlaue="" @input="$commonLib.inputLabelSet($event)">
          <label for="id00"><span class="in_box">도로명+건물명, 도로명, 지번, 건물명</span></label>
        </div>
        <div class="btn_box">
          <button class="btn2" @click="submitForm">검색</button>
        </div>
      </div>
      <div class="pop_content">        
        <!-- 본문 -->
        <div class="address_pop_cnt">
          <!-- 검색후 -->
          <template>
            <!-- 검색후 결과 타이틀 -->
            <div class="result_count_txt">
              <p class="txt">검색한 결과 총 {{ resultsContents }}건 입니다.</p>
            </div>
            <!-- 검색결과 없을시 본문 -->
            <div v-if="resultsContents==0" class="result_list">
              <p class="no_result">검색된 결과가 없습니다.</p>
            </div>
          </template>
        </div>

        <!-- 하단 페이징네이션 -->
        <div class="joinmember_pagination"> 
          <!-- 
            Y20210623
            버튼 .prev_btn, .next_btn 텍스트 수정
            버튼 .prev_btn2, .next_btn2 추가
           -->
          <button class="prev_btn2"><span> 첫 페이지 이동</span></button>
          <button class="prev_btn"><span> 이전 페이지 이동</span></button>
          <ul>
            <li><button><span>1</span></button></li>
          </ul>
          <button class="next_btn"><span> 다음 페이지 이동</span></button>
          <button class="next_btn2"><span> 마지막 페이지 이동</span></button>
        </div>
      </div>
    </div>
    <div class="dimed"></div>
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			resultsContents:0, //default:시작, 0:검색결과없음, 1이상:검색결과있음
		};
	},
	computed: {
		
	},
	methods: {
		submitForm(){//퍼블 화면 확인 용
			this.resultsContents = 0
		}
	},
};
</script>

<style>

</style>
