<template>
  <div id="findPostalCodePopup" class="layer_popup find_postal_code_popup">
    <div class="layer" :class="{result:resultsContents>=0}"><!-- 검색 후 result 클래스 추가 -->
      <div class="pop_header">
        <h2 class="tit">우편번호 찾기</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <!-- 상단 검색영역 고정 -->
      <div class="address_pop_top">
        <div class="input_box" :class="{size2:this.$root.isMobile}">
          <input id="id00" type="text" vlaue="" @input="$commonLib.inputLabelSet($event)">
          <label for="id00"><span class="in_box">도로명+건물명, 도로명, 지번, 건물명</span></label>
        </div>
        <div class="btn_box">
          <button class="btn2" @click="submitForm">검색</button>
        </div>
      </div>
      <div class="pop_content">        
        <!-- 본문 -->
        <div class="address_pop_cnt">
          <!-- 검색 전 -->
          <template v-if="resultsContents=='default'">          
            <div class="guidance_txt">
              <div class="tip_tool">TIP <span>!</span></div>
              <p class="txt">아래와 같은 조합으로 검색을 하시면 <br v-if="this.$root.isMobile">더욱 정확한 결과가 검색됩니다.</p>
            </div>
            <div class="example_list">
              <ul>
                <li>도로명 자동완성<br>예) 판교역로 235, 제주 첨단로 242</li>
                <li>도로명 + 건물번호<br>예) 성수동2가 333-16</li>
                <li>지역명(동/리) + 번지<br>예) 성수동 이마트 성수점</li>
                <li>지역명(동/리) + 건물명(아파트명)<br>예) 성수동 이마트 성수점</li>
                <li>법정동/행정동 사용<br>예) 성수동1가(O), 성수1가제1동(O)</li>
              </ul>
            </div>
          </template>
          <!-- //검색 전 -->

          <!-- 검색후 -->
          <template v-else>
            <!-- 검색후 결과 타이틀 -->
            <div class="result_count_txt">
              <p class="txt">검색한 결과 총 {{ resultsContents }}건 입니다.</p>
            </div>
            <!-- 검색결과 있을시 본문 -->
            <div v-if="resultsContents>0" class="result_list">
              <ul>
                <li tabindex="0">
                  <h5>13494</h5>
                  <dl>
                    <dt>도로명</dt>
                    <dd>경기 성남시 분당구 판교역로 235 <br v-if="this.$root.isMobile">(삼평동, 에이치스퀘어)</dd>
                  </dl>
                  <dl>
                    <dt>지번</dt>
                    <dd>경기 성남시 분당구 삼평동 681</dd>
                  </dl>
                </li>
                <li tabindex="0">	
                  <h5>13494</h5>
                  <dl>
                    <dt>도로명</dt>
                    <dd>경기 성남시 분당구 판교역로 235 <br v-if="this.$root.isMobile">(삼평동, 에이치스퀘어)</dd>
                  </dl>
                  <dl>
                    <dt>지번</dt>
                    <dd>경기 성남시 분당구 삼평동 681</dd>
                  </dl>
                </li>
                <li tabindex="0">	
                  <h5>13494</h5>
                  <dl>
                    <dt>도로명</dt>
                    <dd>경기 성남시 분당구 판교역로 235 <br v-if="this.$root.isMobile">(삼평동, 에이치스퀘어)</dd>
                  </dl>
                  <dl>
                    <dt>지번</dt>
                    <dd>경기 성남시 분당구 삼평동 681</dd>
                  </dl>
                </li>
                <li tabindex="0">	
                  <h5>13494</h5>
                  <dl>
                    <dt>도로명</dt>
                    <dd>경기 성남시 분당구 판교역로 235 <br v-if="this.$root.isMobile">(삼평동, 에이치스퀘어)</dd>
                  </dl>
                  <dl>
                    <dt>지번</dt>
                    <dd>경기 성남시 분당구 삼평동 681</dd>
                  </dl>
                </li>
                <li tabindex="0">	
                  <h5>13494</h5>
                  <dl>
                    <dt>도로명</dt>
                    <dd>경기 성남시 분당구 판교역로 235 <br v-if="this.$root.isMobile">(삼평동, 에이치스퀘어)</dd>
                  </dl>
                  <dl>
                    <dt>지번</dt>
                    <dd>경기 성남시 분당구 삼평동 681</dd>
                  </dl>
                </li>
              </ul>
            </div>
            <!-- 검색결과 없을시 본문 -->
            <div v-if="resultsContents==0" class="result_list">
              <p class="no_result">검색된 결과가 없습니다.</p>
            </div>
          </template>
        </div>

        <!-- 하단 페이징네이션 -->
        <div v-if="resultsContents!=='default'" class="joinmember_pagination">
          <!-- 
            Y20210623
            버튼 .prev_btn, .next_btn 텍스트 수정
            버튼 .prev_btn2, .next_btn2 추가
            페이징 노출 개수 수정 (5개 -> 4개)
           -->
          <button class="prev_btn2"><span> 첫 페이지 이동</span></button>
          <button class="prev_btn"><span> 이전 페이지 이동</span></button>
          <ul>
            <li class="on"><button><span>1</span></button></li>
            <li><button><span>2</span></button></li>
            <li><button><span>3</span></button></li>
            <li><button><span>4</span></button></li>
          </ul>
          <button class="next_btn"><span> 다음 페이지 이동</span></button>
          <button class="next_btn2"><span> 마지막 페이지 이동</span></button>
        </div>
      </div>
    </div>
    <div class="dimed"></div>
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			resultsContents:'default', //default:시작, 0:검색결과없음, 1이상:검색결과있음
		};
	},
	computed: {
		
	},
	methods: {
		submitForm(){//퍼블 화면 확인 용
			this.resultsContents = 5
		}
	},
};
</script>

<style>

</style>
