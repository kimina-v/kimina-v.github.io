<template>
  <div>
    <form
      action="https://ipin.ok-name.co.kr/CommonSvl"
      ref="form"
      method="POST">
      <input type="hidden" name="tc" value="kcb.tis.ti.cmd.LoginRPCert3Cmd" />
      <input type="hidden" ref="cp_cd" name="cpCd" value="" />
      <input type="hidden" ref="mdl_tkn" name="mdlTkn" value="" />
      <input type="hidden" ref="target_id" name="target_id" value="" />
    </form>
  </div>
</template>

<script>
export default {
  name: "CertIpinHtmlPopup",
  metaInfo: {
    title: "인증 팝업",
  },
  data() {
    return {};
  },
  mounted() {
    setTimeout(() => {
      this.goCert()
    },300)
  },
  methods: {
    getContextPath() {
        return location.href.substr(0, location.href.indexOf(location.host) + location.host.length);
    },
    goCert() {
      this.$axios.get("/api/v1.0.0/webapp/commonCert/ipin?returnUrl=" + encodeURIComponent(this.getContextPath())).then((response) => {
        const data = response.data.data.body.data;
        if (data.RSLT_CD == "B000" || data.RSLT_CD == "T300") {
          this.$refs.mdl_tkn.value = data.MDL_TKN;
          this.$refs.cp_cd.value = data.CP_CD;
          this.$refs.form.submit();
        } else {
          this.$foUtils.$alert(this.$t("message.WEB0040"));
        }
      });
    },
  },
};
</script>
