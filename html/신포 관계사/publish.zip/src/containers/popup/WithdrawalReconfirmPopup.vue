<template>
  <div id="withdrawalReconfirmPopup" class="layer_popup" :class="{full:this.$root.isMobile}">
    <div class="layer withdrawal_reconfirm_pop_layer" >
      <div class="pop_header">
        <h2 class="tit">회원 탈퇴</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content" >
        <div class="withdrawal_pop_cnt" >
          <p class="sp_tit2">
            안녕하세요. <strong class="txt_line0">신세계</strong>님
          </p>
          <!-- Y20210801 문구 수정 -->
          <ul class="list_cnt2" tabindex="0">
            <li class="str none">이마트<!--관계사명--> 정책에 따라 회원탈퇴 후 5일<!--관계사별 날짜--> 동안 재가입이 불가합니다.</li>
            <li class="str">주문 및 배송 진행건이 있는 경우 회원 탈퇴 불가능합니다.</li><!-- (시코르만 노출) -->
            <li>회원 탈퇴 시 보유하고 계신 포인트, 쿠폰, 적립금 등 모든 혜택은 자동 소멸되며 복구 불가합니다.</li>
            <li>회원 탈퇴 시 신세계 아카데미 및 이마트 문화센터 수강 신청 및 변경이 불가할 수 있습니다.</li><!-- (이마트, 신세계만 노출) -->
            <li>회원 탈퇴 후 재가입 시 신규 회원으로 가입되며, 탈퇴 전의 회원정보 및 혜택은 복원되지 않습니다.</li>
            <li>회원 탈퇴 전 예약 발송된 광고 메시지가 있는 경우 약 1-2일 동안 발송될 수 있습니다.</li>
            <li>회원 탈퇴 시 이마트<!--관계사명--> 회원 탈퇴가 되며, 신세계포인트 오프라인 및 통합ID 서비스는 계속 이용 가능합니다.</li>
          </ul>
          <!-- //Y20210801 문구 수정 -->
        </div>
        <div class="btn_box">
          <button class="btn1" @click="$commonLib.layerOpen.hide()">취소하기</button>
          <button class="btn0">회원 탈퇴하기</button>
        </div>
      </div>
      
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>

export default {
  props: {
    
  },
  data() {
    return {  
      onlyOnline:true  
    };
  },
  mounted() {
    
  },
};
</script>
