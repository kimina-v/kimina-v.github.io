<template>
  <div id="personalizedBenefitsPopup" class="layer_popup full personalized_benefits_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">신세계포인트 맞춤혜택 서비스</h2><!--b20210825 신세계포인트로 띄어쓰기수정-->
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>      
      <div class="pop_content">
        <div class="w_cnt_full bg0">
          <div class="w_cnt_box">
            <!-- 맞춤혜택 서비스 상단 -->
            <div class="benefit_agree_cnt">
              <div class="txt_cnt">
                <p class="tit"><strong class="txt_line1">신세계</strong> 님, 더 많은 혜택이 남아있어요!</p>
                <p class="txt">신세계포인트 맞춤혜택 서비스 이용 동의 하신 후<br v-if="this.$root.isMobile"> 원하시는 혜택을 받아보세요!</p><!--b20210827 띄어쓰기수정 -->
              </div>
              <div class="agree_cnt">
                <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                  <li class="agree_form">
                    <div class="chk_box">
                      <input id="agree00" type="checkbox">
                      <label for="agree00"><span class="in_box">[선택] 맞춤혜택 부가정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                    </div>
                    <button class="agree_show"><span>내용보기</span></button>
                  </li>
                  <li class="agree_form">
                    <div class="chk_box">
                      <input id="agree01" type="checkbox">
                      <label for="agree01"><span class="in_box">[선택] 이마트/신세계 공동 부가정보 수집 및 이용 동의</span></label><!--b20210827 띄어쓰기수정 -->
                    </div>
                    <button class="agree_show"><span>내용보기</span></button>
                  </li>
                </ul> 
                <!-- Y20210801 추가 -->
                <ul class="list_cnt">
                  <li>선택항목 수집 및 이용 동의를 거부하시더라도 기본 서비스는 이용하실 수 있습니다.</li><!--b20210827 띄어쓰기수정 -->
                </ul>
                <!-- //Y20210801 추가 -->
              </div>
            </div>
            <!-- //맞춤혜택 서비스 상단 -->
            <!-- 혜택 1 클럽서비스 -->
            <div class="benefit_box">
              <h3 class="box_tit"><span class="bg_tit">혜택 하나. <strong>클럽서비스</strong></span></h3>
              <div class="sdw_box"><!--pc 그림자-->
                <div class="benefit_cnt">
                  <!--맘키즈 상단(배너)-->
                  <div class="banner_cnt mom_kids">
                    <div class="txt_cnt">
                      <div class="chk_box">
                        <input id="agree10" type="checkbox">
                        <label for="agree10">맘키즈 클럽</label>
                      </div>
                      <p class="txt0">우리 아이를 위한 <br v-if="this.$root.isMobile">맘키즈 클럽 혜택</p>
                      <p class="txt1">* 매월 맘키즈 쿠폰북 증정</p>
                    </div>
                    <img src="@/assets/images/member/benefits_club_momkids.png" alt="맘키즈 클럽 이미지" class="img0">
                  </div>
                  <!--//맘키즈 상단(배너)-->
                  <!-- 맘키즈 정보입력 -->
                  <div class="info_cnt">
                    <div class="form_box" :class="{l_tit:this.$root.isMobile}">
                      <p class="tit">자녀1</p>
                      <div class="radio_group_box col2">
                        <div class="radio_box" :class="{size2:this.$root.isMobile}">
                          <input id="radio00" type="radio" name="radioName00">
                          <label for="radio00">남자</label>
                        </div>
                        <div class="radio_box" :class="{size2:this.$root.isMobile}">
                          <input id="radio01" type="radio" name="radioName00">
                          <label for="radio01">여자</label>
                        </div>
                      </div>
                      <div class="input_box" :class="{size2:this.$root.isMobile}">
                        <input id="name00" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
                        <label for="name00"><span class="in_box">생년월일 <em>ex)20170201</em></span></label>
                      </div>
                    </div>
                    <div class="form_box" :class="[{l_tit:this.$root.isMobile},{pd_b30:!this.$root.isMobile}]">
                      <p class="tit">자녀2</p>
                      <div class="radio_group_box col2">
                        <div class="radio_box" :class="{size2:this.$root.isMobile}">
                          <input id="radio02" type="radio" name="radioName01">
                          <label for="radio02">남자</label>
                        </div>
                        <div class="radio_box" :class="{size2:this.$root.isMobile}">
                          <input id="radio03" type="radio" name="radioName01">
                          <label for="radio03">여자</label>
                        </div>
                      </div>
                      <div class="input_box" :class="{size2:this.$root.isMobile}">
                        <input id="name01" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
                        <label for="name01"><span class="in_box">생년월일 <em>ex)20170201</em></span></label>
                      </div>
                    </div>
                    <!-- b20210813 수정 -->
                    <ul class="list_cnt">
                      <li>맘키즈 클럽 혜택은 이마트에서 이용가능합니다. <br>(※ 온↔오프라인 옴니동의 시 SSG.COM 이용 가능)</li><!--b20210827문구수정 -->
                      <li>자녀 정보는 최대 2명까지 입력이 가능합니다.</li>
                    </ul>
                    <!-- //b20210813 수정 -->
                  </div>
                  <!-- //맘키즈 정보입력 -->
                </div>
                <div class="benefit_cnt">
                  <!-- 주차 자동정산 상단(배너) Y20210801 문구수정 Start -->
                  <div class="banner_cnt parking_autopay">
                    <div class="txt_cnt">
                      <div class="chk_box">
                        <input id="agree11" type="checkbox">
                        <label for="agree11">주차 클럽</label>
                      </div>
                      <p class="txt0">편리하게 <br v-if="this.$root.isMobile">주차비 자동정산</p>
                      <p class="txt1">* 주차비는 구매내역에 따라 자동정산</p>
                    </div>
                    <img src="@/assets/images/member/benefits_club_parking.png" alt="주차클럽 이미지" class="img0">
                  </div>
                  <!-- //주차 자동정산 상단(배너) Y20210801 문구수정 End -->
                  <!-- 주차 자동정산 정보입력 -->
                  <div class="info_cnt" :class="{pd_b0:this.$root.isMobile}">
                    <div class="input_car_number_box">
                      <div class="select_box" :class="{size3:this.$root.isMobile}">
                        <select id="" title="지역번호 선택">
                          <option val="">지역번호없음</option>
                        </select>
                      </div>
                      <div class="input_boxs">
                        <div class="input_box" :class="{size2:this.$root.isMobile}">
                          <input id="name04" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
                          <label for="name04"><span class="in_box">01</span></label>
                        </div>
                        <div class="input_box" :class="{size2:this.$root.isMobile}">
                          <input id="name05" type="text" value="" @input="$commonLib.inputLabelSet($event)">
                          <label for="name05"><span class="in_box">가</span></label>
                        </div>
                        <div class="input_box" :class="{size2:this.$root.isMobile}">
                          <input id="name06" type="tel" value="" @input="$commonLib.inputLabelSet($event)">
                          <label for="name06"><span class="in_box">1234</span></label>
                        </div>
                      </div>
                    </div>
                    <!-- Y20210801 수정 -->
                    <ul class="list_cnt">
                      <li>이마트, 신세계백화점 방문 시 구매 내역에 따라 해당 차량의 주차비가 자동 정산됩니다.
                        <ul class="list_cnt dash">
                          <li>이마트 : 일부 점포 제외 (이마트앱 &gt; 주차 &gt; 무료주차 가능점포)</li>
                          <li>백화점 : 타임스퀘어점 제외</li>
                        </ul>
                      </li>
                      <li class="str">차량번호는 최대 1대까지 입력이 가능하며, 임시번호 및 외교차량 등 일부 차량번호는 등록이 불가합니다.</li>
                    </ul>
                    <!-- //Y20210801 수정 -->
                  </div>
                  <!-- //주차 자동정산 정보입력 -->
                </div>
              </div>
              <div class="btn_box">
                <button class="btn0 big sdw" @click="$commonLib.layerOpen.hide()">저장하기</button>
              </div>
            </div>
            <!-- //혜택 1 클럽서비스 -->
          </div>
        </div>

        <div class="w_cnt_full bg1">
          <div class="w_cnt_box">
            <!-- 혜택 2 옴니서비스 -->
            <div class="benefit_box space2">
              <h3 class="box_tit"><span class="bg_tit">혜택 둘.<strong> 온<span class="omni_arr arr2">↔</span>오프라인 옴니서비스</strong></span></h3>
              <div class="sdw_box"><!-- pc그림자 -->
                  <div class="benefit_cnt">
                    <div class="banner_cnt img_none omni">
                      <div class="txt_cnt">
                        <p class="txt0">온<span class="omni_arr arr1">↔</span>오프라인 서비스와 혜택을 한번에!</p>
                        <!--b20210902 문구수정 -->
                        <p class="txt2">신세계포인트 옴니서비스 이용 동의하신 후 <br v-if="this.$root.isMobile">온 - 오프라인 혜택을 함께 즐겨보세요!!</p>
                      </div>
                    </div>
                    <div class="info_cnt" :class="{pd_b0:this.$root.isMobile}">
                      <div class="omniservice_list">
                        <ul>
                          <li class="list0">
                            <!--b20210902 문구수정 -->
                            <span class="tit">온<span class="omni_arr">↔</span>오프라인<br v-if="!this.$root.isMobile"> 구매내역 확인</span>
                            <span class="txt">자주 구매하는 상품 한번에 확인하고<br> 맞춤형 상품 추천 정보 확인</span>
                          </li>
                          <li class="list1">
                            <span class="tit">신세계백화점<br v-if="!this.$root.isMobile"> VIP 혜택</span>
                            <!--b20210902 문구수정 -->
                            <span class="txt">무료주차, 할인, MEMBERS BAR 이용까지<br> SSG.COM VIP 등급 그대로 이용 가능</span>
                          </li>
                        </ul>
                      </div>
                      <ul class="agree_list btn_type0" :class="{txt_type0:this.$root.isMobile}">
                        <li class="agree_form">
                          <div class="chk_box">
                            <input id="agree02" type="checkbox">
                            <label for="agree02"><span class="in_box">[선택] 신세계포인트 ↔ SSG.COM 개인정보  제공 동의</span></label>
                          </div>
                          <button class="agree_show"><span>내용보기</span></button>
                        </li>          
                      </ul>
                      <!-- Y20210801 추가 b20210826 문구수정 -->
                      <ul class="list_cnt" :class="[{pd_t20:this.$root.isMobile},{pd_t30:!this.$root.isMobile}]">
                        <li>개인정보 제3자 제공 동의를 거부하시더라도 기본 서비스는 이용하실 수 있습니다.</li>
                      </ul>
                      <!-- //Y20210801 추가 -->
                    </div>
                  </div>
              </div>
              <div class="btn_box">
                <button class="btn0 big sdw" @click="$commonLib.layerOpen.hide()">동의하기</button>
              </div>
            </div>
            <!-- //혜택 2 옴니서비스 -->
          </div>
        </div>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>

export default {
  props: {
    
  },
  data() {
    return {  
      
    };
  },
  mounted() {
    
  },
};
</script>
