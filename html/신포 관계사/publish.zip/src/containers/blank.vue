<template>
  <div id="blank">
    <router-view></router-view>
  </div>
</template>