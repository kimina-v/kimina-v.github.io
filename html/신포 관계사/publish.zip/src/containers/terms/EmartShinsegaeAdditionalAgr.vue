<template>
  <div id="emartShinsegaeAdditionalAgr" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">이마트/신세계 공동 부가정보 수집 및 이용동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">목적</h4>
                <p class="sub_txt"><span class="underline">주차비 자동 정산 및 혜택 제공<br>
                  클럽 회원에 대한 추가 혜택 제공</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">항목</h4>
                <!--b20210909 sm class추가-->                
                <p class="sub_txt sm">차량번호(주차비 자동정산 및  혜택 제공 서비스 신청시), 클럽정보, 자녀 생년월일, 자녀 성별(맘키즈 클럽 가입시)</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유기간</h4>
                <p class="sub_txt"><span class="underline">관계 법령의 규정에 따라 귀하의 개인정보를 보존할 의무가 있는 경우가 아닌 한, 동의일로부터 신세계포인트 가입 해지(탈퇴 확정)시까지 보유합니다.</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">동의를 거부할 권리 및 동의 거부에 따른 불이익 안내</h4>
                <p class="fist sub_txt sm">고객님께서는 선택항목 수집ᆞ이용에 대한 동의를 거부할 권리가 있습니다. 단, 해당 항목 동의 거부 시에는 상기 이용목적에 명시된 서비스는 받으실 수 없습니다.(선택항목 동의여부와 관계없이 필수항목 동의에 의거한 기본 서비스는 이용하실 수 있습니다.)</p>
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
