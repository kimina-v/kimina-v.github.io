<template>
  <div id="OutletsRequired02" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">개인정보 수집 및 이용에 대한 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 목적 및 수집 항목</h4>
                <div class="policy_table">
                  <table>
                    <caption>개인정보 수집 목적 및 수집 항목</caption>
                    <thead>
                      <tr>
                        <th>목적</th>
                        <th>항목</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><span class="accent">이용자 식별 및 본인확인, 멤버십 서비스 및 혜택 제공, 부정이용 확인 및 방지 등 회원관리</span></td>
                        <td>통합ID, 비밀번호, 성명, 생년월일, 성별, 본인확인정보(CI), 신세계포인트 회원번호 및 카드번호</td>
                      </tr>
                      <tr>
                        <td><span class="accent">문의 응대 및 민원처리, 서비스 이용에 관한 통지</span></td>
                        <td>휴대폰번호, 이메일</td>
                      </tr>
                    </tbody>
                  </table>
                </div>               
              </div>             
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">회원 탈퇴 시까지 (단, 법령에 따라 보존 의무가 있는 경우 해당 법령에 정해진 기간에 따름)</span></p>
              </div>
              <div class="policy_cnt">
                <p class="sub_txt">※고객님은 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. 단, 거부시 상기 목적에 명시된 서비스를 받을 수 없습니다.</p>
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
