<template>
  <div id="ChicorRequired02" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">개인정보 수집 및 이용동의</h2><!--b20210827 띄어쓰기수정 -->
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">목적</h4>
                <p class="sub_txt">
                  <span class="spacing">시코르닷컴 회원 서비스 제공 및 본인확인 절차에 활용</span>
                  <span class="spacing">시코르포인트 적립 및 사용 등의 운영</span>
                  <span class="spacing">멤버십서비스 및 회원에 대한 각종 편의 서비스 및 혜택 제공</span>
                  <span class="spacing">상품 및 서비스에 대한 주문 및 접수확인, 대금결제확인, 주문상품 및 경품 배송을 위한 정확한 배송지 확보, 고객센터 운영, 공지사항 전달 및 본인의사 확인, 민원처리, 사고조사 등을 위한 원활한 의사소통 경로 확보</span>                 
                </p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">항목</h4>                
                <p class="sub_txt">성명, 생년월일, 성별, 전화번호(일반/휴대전화: 최소 1개 이상 입력필요), 만 14세 이상여부, 이메일, 본인확인정보 인증결과값(CI/DI), 서비스이용과정 및 사업 처리과정에서 수집되는 개인정보</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">관계 법령의 규정에 따라 보존할 의무가 있는 경우가 아닌 한, 회원 탈퇴 요청시부터 30일 내 파기(재가입 방지, 회원의 요구사항 처리, 포인트 소멸 일시보류 등의 목적으로 유예기간을 둠)</span></p>
              </div>
              <div class="policy_cnt">
                <p class="sub_txt">※ 서비스 이용과정 및 사업 처리과정에서 수집되는 개인 정보 : 홈페이지 내 개인정보 처리방침 참조</p><!--b20210826문구수정-->
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
