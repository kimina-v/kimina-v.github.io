<template>
  <div id="ShinsegaePointRequired03" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">이마트/신세계 공동 개인정보 수집 및 이용 동의</h2><!--b20210827 띄어쓰기수정 -->
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">목적</h4>
                <p class="sub_txt"><span class="underline">신세계포인트 회원 서비스 제공 및 본인확인 절차에 활용<br>
                   신세계포인트 카드발급 및 관리, 포인트 적립•사용 정산, 제휴가맹점과의 각종 포인트 정산<br>
                   회원에 대한 각종 편의 서비스 및 혜택 제공, 상품 및 서비스에 대한 주문 및 접수 확인, 대금 결제 확인, 주문상품 및 경품 배송을 위한 정확한 배송지 확보, 고객센터 운영, 공지사항 전달 및 본인의사 확인, 민원처리, 사고조사 등을 위한 원활한 의사소통 경로 확보</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">항목</h4>
                <!--b20210830 class수정-->                
                <p class="sub_txt sm">성명, 생년월일, 성별, 휴대전화번호, 이메일, 주소, (인증회원 가입시 본인확인 기관에서 제공하는) 본인확인 인증결과값(CI, DI), 아이핀번호(아이핀 본인인증시) , 포인트카드 번호, 아이디, 비밀번호, 서비스 이용과정 및 사업 처리과정에서 수집되는 개인정보</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유기간</h4>
                <p class="sub_txt"><span class="underline">관계 법령의 규정에 따라 귀하의 개인정보를 보존할 의무가 있는 경우가 아닌 한, 동의일로부터 신세계포인트 가입 해지(탈퇴 확정)시까지 보유합니다.</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">동의를 거부할 권리 및 동의 거부에 따른 불이익 안내</h4>
                <!--b20210830 class수정-->
                <p class="fist sub_txt sm">고객님께서는 필수항목 수집•이용에 대한 동의를 거부할 권리가 있습니다. 단, 필수항목 동의 거부 시에는 회원 가입이 불가하며, 상기 이용목적에 명시된 서비스는 받으실 수 없습니다.</p>
              </div>             
              <div class="policy_cnt">
                <!--b20210831 class,문구 수정-->
                <p class="sub_txt sm">※ 서비스 이용과정 및 사업 처리과정에서 수집되는 개인 정보 : 홈페이지 내 개인정보처리방침 참조</p>
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			address: '',
			resultsContents:'default',     
		};
	},
	computed: {
		isAddressValided() {
			return this.address != '';
		},
	},
	methods: {	
		submitForm(){
			this.resultsContents = 1
		}
	},
};
</script>

<style>

</style>
