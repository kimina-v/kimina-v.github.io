<template>
  <div id="OutletsSelection01" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">서비스·이벤트정보 제공을 위한 개인정보 수집 및 이용 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 목적 및 수집 항목</h4>
                <div class="policy_table">
                  <table>
                  <caption>개인정보 수집 목적 및 수집 항목</caption>
                <thead>
                  <tr>
                    <th>목적</th>
                    <th>항목</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><span class="accent">고객정보 분석을 통한 쿠폰 및 맞춤혜택 제공, 이벤트 및 행사 안내</span></td>
                    <td>성명, 생년월일, 성별, 휴대폰번호, 이메일, 주소, 구매 및 서비스 제공 이력</td>
                  </tr>
                </tbody>
                </table>
                </div>               
              </div>
             
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">회원 탈퇴 또는 마케팅 활용 동의 철회 시까지</span></p>
              </div>
              <div class="policy_cnt">
                <p class="sub_txt">※고객님은 개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. 단, 거부시 상기 목적에 명시된 서비스를 받을 수 없습니다.</p>
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
