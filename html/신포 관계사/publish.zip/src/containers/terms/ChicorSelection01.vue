<template>
  <div id="ChicorSelection01" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">[선택] 혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</h2><!--b20210827 띄어쓰기수정 -->
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">목적</h4>
                <p class="sub_txt"><span class="underline">상품 및 서비스 안내, 이벤트정보 제공 <br>
                  제휴행사 및 서비스홍보를 위한 마케팅 활용 <br>
                  마케팅을 위한 고객정보 분석 및 맞춤 서비스 제공 <br>
                  앱 설치 url 전송</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">항목</h4>                
                <p class="sub_txt">성명, 전화번호, 휴대전화번호, 이메일, 마케팅 수신동의 여부</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">관계 법령의 규정에 따라 보존할 의무가 있는 경우가 아닌 한, 회원 탈퇴 요청시부터 30일 내 파기(재가입 방지, 회원의 요구사항 처리, 포인트 소멸 일시보류 등의 목적으로 유예기간을 둠)</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">동의를 거부할 권리 및 동의 거부에 따른 불이익 안내</h4>
                <p class="sub_txt">고객님께서는 선택항목 수집ᆞ이용에 대한 동의를 거부할 권리가 있습니다. 단, 해당 항목 동의 거부 시에는 상기 이용목적에 명시된 서비스는 받으실 수 없습니다.</p>
              </div>             
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
