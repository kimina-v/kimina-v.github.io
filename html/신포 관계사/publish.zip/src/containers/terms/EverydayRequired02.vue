<template>
  <div id="everydayRequired02" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">개인정보 수집 및 이용 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 목적</h4>
                <p class="sub_txt sm">이용자 식별 및 본인확인, 회원 서비스 제공, 고객 상담, 고객 불만접수 및 처리, 상품 배송 및 배송지 관리, 포인트 적립/사용</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 항목</h4>                
                <p class="sub_txt sm">성명, 아이디, 비번, 주소, 생년월일, 성별, 휴대폰 번호, 이메일, 본인확인정보 인증 결과값(CI/DI)</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">회원 탈퇴 후 5일까지 또는 법정 의무 보유기간까지</span></p>
                <p class="fist sub_txt sm">개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. 
                  단, 동의를 거부 할 경우 당사의 서비스 이용을 위한 회원가입이 불가합니다.
                </p>
              </div>
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
