<template>
  <div id="ShinsegaePointRequired04" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">통합회원 서비스 제공 개인정보 제3자 제공 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <!--b20210830 class수정-->
                <p class="sub_txt sm">통합회원의 경우 통합ID를 활용하는 신세계 그룹사에 회원정보를 제공합니다.
                  <br>※신세계포인트 통합회원이란?
                  <br>신세계포인트 온라인 통합ID 하나로 다양한 신세계 그룹사의 사이트를 편리하게 이용할 수 있는 회원제도 입니다.
                  <br>(단, 신세계 그룹사 약관에 동의되지 않은 경우, 해당 그룹사에는 개인정보가 제공되지 않습니다.)
                  </p>                
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">제공자</h4>
                <!--b20210830 class수정-->
                <p class="sub_txt sm">㈜이마트, ㈜신세계, ㈜광주신세계, ㈜신세계동대구복합환승센터</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">제공 받는 자</h4>
                <!--b20210830 class수정-->
                <p class="sub_txt"><span class="underline2">㈜에스에스지닷컴, ㈜이마트에브리데이, ㈜스타필드하남/㈜신세계프라퍼티/㈜스타필드 고양/㈜스타필드 안성, ㈜신세계사이먼</span></p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">목적</h4>
                <p class="sub_txt"><span class="underline2">통합ID로 각 신세계그룹사 사이트 이용</span></p>
                <ul class="list0">
                   <li>- <span class="underline2">통합ID 서비스 제공(중복 확인, 사이트 로그인 등)</span></li>
                   <li>- <span class="underline2">회원 정보 동기화(신세계 그룹사 약관 가입 고객의 경우)</span></li>
                   <li>- <span class="underline2">민원처리, 사고조사 등을 위한 원활한 의사소통 경로 확보</span></li>
                </ul>
              </div>                          
              <div class="policy_cnt">
                <h4 class="sub_tit2">항목</h4>
                  <!--b20210830 class 와 문구 수정 -->
                  <ul class="list_cnt sm">
                    <li>회원번호/카드번호/성명/휴대전화번호/주소/이메일주소/생년월일/성별</li>
                    <li>통합ID/비밀번호/비밀번호 변경 일시/ 인증결과값(CI/DI) </li><!--b20210908문구수정-->
                    <li>서비스 이용 기록(접속IP 등)</li> <!--b20210908문구추가-->
                  </ul>               
              </div>                          
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유기간</h4>
                <p class="sub_txt"><span class="underline">관계 법령의 규정에 따라 귀하의 개인정보를 보존할 의무가 있는 경우가 아닌 한, 신세계 그룹사 사이트 탈퇴 시까지 또는 회원가입 동의일로부터 신세계포인트 가입 해지(탈퇴확정)시까지 보유합니다.</span></p>
              </div>
              <div class="policy_cnt">
                <!--b20210830 class수정-->
                <h4 class="sub_tit2">동의를 거부할 권리 및 동의 거부에 따른 불이익 안내</h4>
                <p class="fist sub_txt sm">고객님께서는 개인정보 제3자 제공동의를 거부할 권리가 있습니다. 단, 필수항목 동의 거부 시에는 회원 가입이 불가하며, 상기 이용목적에 명시된 서비스는 받으실 수 없습니다.</p>
              </div>             
              <div class="policy_cnt">
                <!--b20210830 class수정-->
                <p class="sub_txt sm">※ 서비스 이용과정 및 사업 처리과정에서 수집되는 개인 정보 : 홈페이지 내 개인정보처리방침 참조</p>
              </div>                           
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			address: '',
			resultsContents:'default',     
		};
	},
	computed: {
		isAddressValided() {
			return this.address != '';
		},
	},
	methods: {	
		submitForm(){
			this.resultsContents = 1
		}
	},
};
</script>

<style>

</style>
