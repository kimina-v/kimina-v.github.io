<template>
  <div id="privacyAgreeDetailPopup" class="layer_popup">
    <div class="layer">
      <div class="pop_header">
         <!--b20210910 class , 태그 추가수정-->
        <h2 class="tit">혜택제공 및 분석을 위한 개인정보 수집 및 이용 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <div id="termsArea0">
          <!-- 관리자 등록 Start -->
          <div class="policy_wrap bg_w">
            <div class="policy_cnt">
              <!--b20210910 class , 태그 추가수정-->
              <h3 class="sub_tit2">목적</h3>
              <p class="sub_txt"><span class="underline">
                당사/신세계 그룹사/신세계포인트 제휴사가 제공하는 상품 및 서비스 안내, 소식지 제공, 이벤트 정보 제공(문자, 이메일, DM, TM) 제휴행사 및 서비스 홍보를 위한</span> <span class="underline red">마케팅 활용, 마케팅을 위한 고객정보 분석 및 서비스 개발</span>
              </p>
            </div>
            <div class="policy_cnt">
              <!--b20210910 class , 태그 추가수정-->
              <h4 class="sub_tit2">항목</h4>
              <p class="sub_txt sm">
                성명, 생년월일, 성별, 휴대전화번호, 이메일, 주소, 당사/신세계 그룹사/신세계포인트 제휴사에서 신세계포인트 서비스 이용과정에서 발생한 상품 및 서비스 구매내역, 직장명, 주소, 연락처(직장정보 제공 시), 본인실제생일(별도 제공 시)
              </p>
            </div>
            <div class="policy_cnt">
              <h3 class="tit">보유기간</h3>
              <p class="line_txt0">
                <span>관계 법령의 규정에 따라 귀하의 개인정보를 보존할 의무가 있는 경우가 아닌 한, 동의일로부터 신세계포인트 가입 해지(탈퇴 확정)시까지 보유합니다.</span>
              </p>
            </div>  
            <div class="policy_cnt">
              <!--b20210910 class , 태그 추가수정-->
             <h4 class="sub_tit2">동의를 거부할 권리 및 동의 거부에 따른 불이익 안내</h4>
                <p class="fist sub_txt sm">고객님께서는 선택항목 수집ᆞ이용에 대한 동의를 거부할 권리가 있습니다. 단, 해당 항목 동의 거부 시에는 상기 이용목적에 명시된 서비스는 받으실 수 없습니다.(선택항목 동의여부와 관계없이 필수항목 동의에 의거한 기본 서비스는 이용하실 수 있습니다.)</p>
            </div>
            <!--b20210910 class , 태그 추가수정-->
          </div>
        </div>
          <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed"></div>
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			address: '',
			resultsContents:false
		};
	},
	computed: {
		isAddressValided() {
			return this.address != '';
		},
	},
	methods: {
		chageAddress(e) {
			this.address = e.target.value;
		},
		submitForm(){
			this.resultsContents = true
		}
	},
};
</script>

<style>

</style>
