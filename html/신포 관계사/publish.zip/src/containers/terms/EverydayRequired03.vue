<template>
  <div id="everydayRequired03" class="layer_popup terms_popup">
    <div class="layer">
      <div class="pop_header">
        <h2 class="tit">개인정보 수집 및 이용 동의</h2>
        <button class="close_btn" @click="$commonLib.layerOpen.hide()">닫기</button>
      </div>
      <div class="pop_content">
        <!-- 관리자 등록 Start -->   
          <div class="policy_wrap">          
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 목적</h4>
                <p class="sub_txt sm">상품 및 서비스 안내, 이벤트 정보 및 혜택 제공, 상품 검색 및 추천서비스 안내</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">개인정보 수집 항목</h4>                
                <p class="sub_txt sm">성명, 휴대폰 번호, 생년월일, 성별, 마케팅 수신동의 여부</p>
              </div>
              <div class="policy_cnt">
                <h4 class="sub_tit2">보유 및 이용기간</h4>
                <p class="sub_txt"><span class="underline">회원 탈퇴 또는 동의 철회 시</span></p>
                <p class="fist sub_txt sm">개인정보 수집 및 이용 동의를 거부할 권리가 있습니다. 
                    단, 동의를 거부 할 경우 상기 목적에 명시된 서비스를 받을 수 없습니다.
                </p>
              </div>
          </div>
        <!-- 관리자 등록 End -->
      </div>
    </div>
    <div class="dimmed" />
  </div>	
</template>

<script>

export default {
	components: {
	},
	data() {
		return {  
		};
	},

};
</script>
