<template>
  <div id="alertAgreeUncheck" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          <!--b20210907 문구수정,b20210909 동의를 철회 문구수정 -->
          선택약관 동의 철회시 맘키즈 클럽 및 주차요금 자동 정산 등 부가적인 맞춤혜택을 받으실 수 없습니다.<br>선택약관 동의를 철회 하시겠습니까?
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn1" @click="$commonLib.layerOpen.hide()">아니오</button>
        <button class="btn0">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
