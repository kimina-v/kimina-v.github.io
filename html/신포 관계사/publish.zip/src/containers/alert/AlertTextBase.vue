<template>
  <div id="alertTextBase" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt" v-html="alertText"></p>
      </div>
      <div class="btn_box">
        <button class="btn0" @click="$commonLib.layerOpen.hide()">확인</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  props:{
      alertText : {
        type : String
      }
  },
  mounted() {
    
  },
  methods: {

  },
};
</script>
