<template>
  <div id="alertOnlineSecession" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          신세계 님께서는 온라인 ID를 탈퇴하시면 신세계포인트 완전탈퇴가 되므로 서비스들을 더 이상 <span class="wp">사용할 수 없게 됩니다.</span>
        </p>        
      </div>
      <div class="btn_box">
        <a href="javascript:void(0);" class="btn2 mg_b10">고객센터</a>
        <button class="btn1" @click="$commonLib.layerOpen.hide()">다시 생각해보기</button>
        <button class="btn0">그래도 탈퇴하기</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
