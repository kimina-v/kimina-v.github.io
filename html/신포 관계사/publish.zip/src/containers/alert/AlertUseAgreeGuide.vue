<template>
  <div id="alertUseAgreeGuide" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          <!--b20210901 문구 수정,b20210909문구수정---->
          선택 및 공동 수집 선택 동의를 모두 동의해주셔야 서비스 이용이 가능합니다. <br>
          모두 동의하시겠습니까? 
        </p>
      </div>
      <div class="btn_box">
        <button class="btn1" @click="$commonLib.layerOpen.hide()">아니오</button>
        <button class="btn0">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  props:{
      
  },
  mounted() {
    
  },
  methods: {

  },
};
</script>
