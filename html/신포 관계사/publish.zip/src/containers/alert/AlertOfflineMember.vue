<template>
  <div id="alertOfflineMember" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          기존에 저장된 회원정보가 존재합니다.<br>기존 정보를 불러오시겠습니까?
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn1" @click="$commonLib.layerOpen.hide()">아니오</button>
        <button class="btn0">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
