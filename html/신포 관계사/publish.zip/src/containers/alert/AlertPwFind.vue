<template>
  <div id="alertPwFind" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <!--b20210903 문구수정-->
        <p class="alert_txt">비밀번호 입력 오류 횟수 초과로 <br>계정이 잠금되었습니다.<br>비밀번호 찾기를 통해 비밀번호를 <br>재설정 해주세요.</p>
      </div>
      <div class="btn_box">
        <button class="btn0" @click="$commonLib.layerOpen.hide()">비밀번호 찾기</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  props:{
      
  },
  mounted() {
    
  },
  methods: {

  },
};
</script>
