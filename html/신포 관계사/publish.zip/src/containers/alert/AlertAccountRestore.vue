<template>
  <div id="alertAccountRestore" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          신세계포인트 휴면회원 계정 복원이 완료되었습니다.
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn0" @click="$commonLib.layerOpen.hide()">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
