<template>
  <div id="alertCustomerTel" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          <!--b20210901 문구 수정 -->
          연결하시겠습니까?<br>운영시간 9시 ~ 18시
          <!--b20210910 class , 태그 추가수정-->
          <br>
          <span class="sm">
          (점심시간 12시 ~ 13시 / 주말, 공휴일 휴무)
          </span>
        </p>         
      </div>
      <div class="btn_box">
        <button class="btn1" @click="$commonLib.layerOpen.hide()">아니오</button>
        <a href="tel:1899-4349" class="btn0">예</a>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
