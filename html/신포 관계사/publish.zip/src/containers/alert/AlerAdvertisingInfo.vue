<template>
  <div id="alerAdvertisingInfo" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <!--b20210907 문구 및 태그 class 추가,수정 -->
        <p class="alert_txt tal mg_b10">
          신세계포인트 광고정보 수신동의 정보가 정상적으로 변경되었습니다.</p> 
          <p class="alert_txt tal mg_b10">
          변경일자: 0000년 00월00일<br>
          동의: 이메일, 문자<br>
          비동의: APP PUSH, DM, TM<br>
          </p>
          <ul class="list_cnt">
            <li>광고정보 수신거부와 관계없이 주문/배송안내, 회원 및  서비스 정책 변경, 법적 의무사항 등 고객 고지 내용은 정상 발송됩니다.</li>
            <li>광고정보 수집거부 전 예약 발송된 광고 메시지가 있는 경우 약 1~2일 동안 발송될 수 있습니다.</li>
          </ul>
          <!--//b20210907 문구 및 태그 추가,수정 -->       
      </div>
      <div class="btn_box">
        <!--b20210903 문구수정-->
        <button class="btn0" @click="$commonLib.layerOpen.hide()">확인</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
