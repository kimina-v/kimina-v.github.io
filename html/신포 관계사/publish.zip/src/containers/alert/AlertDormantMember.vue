<template>
  <div id="alertDormantMember" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          휴면회원입니다. 로그인을 위해서 정보복원이 필요합니다.
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn0" @click="$commonLib.layerOpen.hide()">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
