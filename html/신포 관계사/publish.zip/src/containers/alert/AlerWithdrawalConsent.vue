<template>
  <div id="alerWithdrawalConsent" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          <!--b20210903 ,b20210903 다시 철회로 문구수정-->
          선택약관에 동의하지 않으시면 문자/이메일 등 광고 채널에 대한 수신동의가 철회됩니다.<br>
          동의를 철회하시겠습니까?
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn1" @click="$commonLib.layerOpen.hide()">아니오</button>
        <button class="btn0">예</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
