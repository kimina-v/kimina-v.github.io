<template>
  <div id="alertAuthCount" class="alert_popup">
    <div class="layer">
      <div class="pop_contents">
        <p class="alert_txt">
          입력하신 인증번호가 정확하지 않습니다.<br>다시 시도해주세요.<br>(인증번호 재입력은 앞으로 00번만 가능합니다.)
        </p>        
      </div>
      <div class="btn_box">
        <button class="btn0" @click="$commonLib.layerOpen.hide()">확인</button>
      </div>
    </div>
    <div class="dimmed"></div>
  </div>
</template>

<script>
export default {
  prompt:{
    
  },
  mounted() {
    
  },
  methods: {
    
  },
};
</script>
