import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
    state: {
        device:'',
        agent: '',
        browser:'',
        loading:false,
        loginSuccess: false,//퍼블 로그인 화면 확인 용
        layerInfo: {
            count : 0,
            lastFocus: [],
            layerId : []
        },
        alertText:''
    },   
})
export default store;

