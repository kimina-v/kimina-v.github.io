const path = require('path')
var webpack = require('webpack')

module.exports = {
    publicPath: '/publish',
    chainWebpack: config => {
        // Add "node_modules" alias
        config.resolve.alias
            .set('node_modules', path.join(__dirname, './node_modules'))

        config.resolve.alias
            .set('@customAssets', path.join(__dirname, 'src/assets', process.env.VUE_APP_SITENAME))

        config
            .plugin('jquery')
            .use(webpack.ProvidePlugin, [{
                $: "jquery",
                jQuery: "jquery",
            }])

        // Disable "prefetch" plugin since it's not properly working in some browsers
        config.plugins
            .delete('prefetch')

        // Do not remove whitespaces
        config.module.rule('vue')
            .use('vue-loader')
            .loader('vue-loader')
            .tap(options => {
                options.compilerOptions.preserveWhitespace = true
                return options
            })


        config.module.rules.delete('eslint');

    },

    css: {
        loaderOptions: {
            sass: {
                prependData: ``
            }
        }
    },

    devServer: {
        proxy: {
            "/api": {
                //target: 'http://localhost:9000',
                target: 'https://svcweb.spharos-dev.mycloudmembership.com',
                //pathRewrite: {'^/api': ''},
            }
        },
        port: 8080
    },

    productionSourceMap: false,

}